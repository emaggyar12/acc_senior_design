/*
 * Code generation for system system '<S12>/ACC Lookup'
 * For more details, see corresponding source file HSC_Model_ACCLookup.c
 *
 */

#ifndef RTW_HEADER_HSC_Model_ACCLookup_h_
#define RTW_HEADER_HSC_Model_ACCLookup_h_
#include <math.h>
#include <string.h>
#ifndef HSC_Model_COMMON_INCLUDES_
# define HSC_Model_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* HSC_Model_COMMON_INCLUDES_ */

#include "HSC_Model_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"

/* Block signals for system '<S23>/DistanceRC' */
typedef struct {
  real_T StoplightValidity;            /* '<S23>/DistanceRC' */
} B_DistanceRC_HSC_Model_T;

/* Block states (default storage) for system '<S23>/DistanceRC' */
typedef struct {
  uint16_T temporalCounter_i1;         /* '<S23>/DistanceRC' */
  uint8_T is_active_c41_HSC_Model;     /* '<S23>/DistanceRC' */
  uint8_T is_c41_HSC_Model;            /* '<S23>/DistanceRC' */
  uint8_T RCLocal;                     /* '<S23>/DistanceRC' */
} DW_DistanceRC_HSC_Model_T;

/* Block signals for system '<S12>/ACC Lookup' */
typedef struct {
  real_T SetSpd;                       /* '<S23>/kph2m//s' */
  real_T EgoSpd;                       /* '<S23>/EgoSpd' */
  real_T SetSpeedAcccel2;              /* '<S23>/Switch' */
  real_T setSpdAccel;                  /* '<S23>/Saturation4' */
  real_T DistInfo[7];                  /* '<S23>/DistInfo' */
  real_T DelayOneStep1;                /* '<S23>/Delay One Step1' */
  real_T DistanceControllerAccel;      /* '<S23>/Multiport Switch' */
  real_T Switch14;                     /* '<S23>/Switch14' */
  real_T distanceAccel;                /* '<S23>/Saturation1' */
  real_T DelayOneStep;                 /* '<S23>/Delay One Step' */
  real_T Divide4;                      /* '<S23>/Divide4' */
  real_T StopLightAccel;               /* '<S23>/Switch4' */
  real_T TotalACCAccel;                /* '<S23>/Min' */
  real_T Saturation3;                  /* '<S23>/Saturation3' */
  real_T EBCM_Decel;                   /* '<S23>/Switch1' */
  real_T AccelCmd;                     /* '<S23>/Saturation2' */
  real_T m1;                           /* '<S91>/m1' */
  real_T UnitConversion;               /* '<S91>/Unit Conversion' */
  real_T TrigonometricFunction1_o1;    /* '<S91>/Trigonometric Function1' */
  real_T TrigonometricFunction1_o2;    /* '<S91>/Trigonometric Function1' */
  real_T m;                            /* '<S91>/m' */
  real_T Product5;                     /* '<S91>/Product5' */
  real_T um2;                          /* '<S91>/1//m2' */
  real_T TrigonometricFunction2;       /* '<S91>/Trigonometric Function2' */
  real_T Product7;                     /* '<S91>/Product7' */
  real_T Product6;                     /* '<S91>/Product6' */
  real_T c;                            /* '<S91>/c' */
  real_T b;                            /* '<S91>/b' */
  real_T Add1;                         /* '<S91>/Add1' */
  real_T TotalForce;                   /* '<S91>/Add2' */
  real_T ACCReqPwr;                    /* '<S23>/Switch3' */
  real_T DistErrFLipped;               /* '<S23>/Unary Minus' */
  real_T Gain;                         /* '<S23>/Gain' */
  real_T uDLookupTable1;               /* '<S23>/2-D Lookup Table1' */
  real_T uDLookupTable4;               /* '<S23>/2-D Lookup Table4' */
  real_T Product;                      /* '<S23>/Product' */
  real_T Square;                       /* '<S23>/Square' */
  real_T Product1;                     /* '<S23>/Product1' */
  real_T Gain7;                        /* '<S23>/Gain7' */
  real_T Product4;                     /* '<S23>/Product4' */
  real_T Add;                          /* '<S23>/Add' */
  real_T Constant2;                    /* '<S23>/Constant2' */
  real_T Constant21;                   /* '<S23>/Constant21' */
  real_T Constant22;                   /* '<S23>/Constant22' */
  real_T Constant23;                   /* '<S23>/Constant23' */
  real_T RateTransition;               /* '<S23>/Rate Transition' */
  real_T TSamp;                        /* '<S34>/TSamp' */
  real_T Uk1;                          /* '<S34>/UD' */
  real_T Diff;                         /* '<S34>/Diff' */
  real_T TSamp_l;                      /* '<S35>/TSamp' */
  real_T Uk1_c;                        /* '<S35>/UD' */
  real_T Diff_l;                       /* '<S35>/Diff' */
  real_T EgoPosition;                  /* '<S23>/Discrete-Time Integrator' */
  real_T xdotPosition;                 /* '<S23>/Discrete-Time Integrator1' */
  real_T DistanceKeepTrack;            /* '<S23>/Discrete-Time Integrator3' */
  real_T Divide1;                      /* '<S23>/Divide1' */
  real_T DiscreteTimeIntegrator;       /* '<S37>/Discrete-Time Integrator' */
  real_T Product_f;                    /* '<S37>/Product' */
  real_T UnitDelay[2];                 /* '<S37>/Unit Delay' */
  real_T VectorConcatenate1[2];        /* '<S37>/Vector Concatenate1' */
  real_T Switch[2];                    /* '<S37>/Switch' */
  real_T SetSpeedError;                /* '<S23>/Sum3' */
  real_T ProportionalGain;             /* '<S79>/Proportional Gain' */
  real_T DerivativeGain;               /* '<S66>/Derivative Gain' */
  real_T Tsamp;                        /* '<S69>/Tsamp' */
  real_T UD;                           /* '<S67>/UD' */
  real_T Diff_h;                       /* '<S67>/Diff' */
  real_T SumFdbk;                      /* '<S84>/Sum Fdbk' */
  real_T ZeroGain;                     /* '<S65>/ZeroGain' */
  real_T DeadZone;                     /* '<S65>/DeadZone' */
  real_T SignPreSat;                   /* '<S65>/SignPreSat' */
  real_T IntegralGain;                 /* '<S71>/Integral Gain' */
  real_T SignPreIntegrator;            /* '<S65>/SignPreIntegrator' */
  real_T Switch_a;                     /* '<S65>/Switch' */
  real_T Integrator;                   /* '<S74>/Integrator' */
  real_T Sum;                          /* '<S83>/Sum' */
  real_T Saturation;                   /* '<S81>/Saturation' */
  real_T Product5_i;                   /* '<S23>/Product5' */
  real_T Switch5;                      /* '<S23>/Switch5' */
  real_T Product6_m;                   /* '<S23>/Product6' */
  real_T RateTransition1;              /* '<S23>/Rate Transition1' */
  real_T RateTransition2;              /* '<S23>/Rate Transition2' */
  real_T Switch11;                     /* '<S23>/Switch11' */
  real_T Switch2;                      /* '<S23>/Switch2' */
  real_T TargetRelPos;                 /* '<S23>/TargetRelPos' */
  real_T Constant11;                   /* '<S100>/Constant11' */
  real_T x;                            /* '<S100>/Integrator3' */
  real_T VectorConcatenate2[3];        /* '<S91>/Vector Concatenate2' */
  real_T UnitConversion_e[3];          /* '<S100>/Unit Conversion' */
  real_T Constant14;                   /* '<S101>/Constant14' */
  real_T Constant5;                    /* '<S101>/Constant5' */
  real_T Constant7;                    /* '<S101>/Constant7' */
  real_T Add_h;                        /* '<S97>/Add' */
  real_T Constant1;                    /* '<S97>/Constant1' */
  real_T Constant10;                   /* '<S97>/Constant10' */
  real_T Y;                            /* '<S97>/Constant12' */
  real_T Constant2_i;                  /* '<S97>/Constant2' */
  real_T TmpSignalConversionAtsincosInport1[3];
  real_T sincos_o1[3];                 /* '<S104>/sincos' */
  real_T sincos_o2[3];                 /* '<S104>/sincos' */
  real_T VectorConcatenate[9];         /* '<S105>/Vector Concatenate' */
  real_T Reshape9to3x3columnmajor[9];
                                /* '<S105>/Reshape (9) to [3x3] column-major' */
  real_T Transpose[9];                 /* '<S103>/Transpose' */
  real_T VectorConcatenate1_i[3];      /* '<S91>/Vector Concatenate1' */
  real_T TmpSignalConversionAtProductInport2[3];
  real_T Product_h[3];                 /* '<S103>/Product' */
  real_T Product_d;                    /* '<S106>/Product' */
  real_T UnitConversion_l;             /* '<S106>/Unit Conversion' */
  real_T Product1_n;                   /* '<S106>/Product1' */
  real_T VectorConcatenate4[3];        /* '<S91>/Vector Concatenate4' */
  real_T Product8;                     /* '<S106>/Product8' */
  real_T Product9;                     /* '<S106>/Product9' */
  real_T UnaryMinus;                   /* '<S106>/Unary Minus' */
  real_T UnaryMinus1;                  /* '<S106>/Unary Minus1' */
  real_T TmpSignalConversionAtsincosInport1_a[3];
  real_T sincos_o1_h[3];               /* '<S111>/sincos' */
  real_T sincos_o2_n[3];               /* '<S111>/sincos' */
  real_T VectorConcatenate_b[9];       /* '<S112>/Vector Concatenate' */
  real_T Reshape9to3x3columnmajor_c[9];
                                /* '<S112>/Reshape (9) to [3x3] column-major' */
  real_T Transpose_d[9];               /* '<S93>/Transpose' */
  real_T VectorConcatenate3[2];        /* '<S91>/Vector Concatenate3' */
  real_T TmpSignalConversionAtProductInport2_p[3];
  real_T Product_c[3];                 /* '<S93>/Product' */
  real_T VectorConcatenate_k[2];       /* '<S91>/Vector Concatenate' */
  real_T VectorConcatenate5[3];        /* '<S91>/Vector Concatenate5' */
  real_T VectorConcatenate6[3];        /* '<S91>/Vector Concatenate6' */
  real_T Decel;                        /* '<S23>/Chart5' */
  real_T BrakeHold;                    /* '<S23>/Chart5' */
  real_T DecelOut;                     /* '<S23>/Chart4' */
  real_T DistanceMustStop;             /* '<S23>/Chart4' */
  real_T BrakeHold_f;                  /* '<S23>/Chart4' */
  real_T DistanceState;                /* '<S23>/Chart4' */
  real_T DecelOut_d;                   /* '<S23>/Chart3' */
  real_T LastDistance;                 /* '<S23>/Chart2' */
  real_T Switch_d;                     /* '<S23>/Chart' */
  real_T Gain2;                        /* '<S23>/Gain2' */
  real_T NearConstant;                 /* '<S23>/Near Constant' */
  real_T Gain8;                        /* '<S23>/Gain8' */
  real_T MediumConstant;               /* '<S23>/Medium Constant' */
  real_T SpdMPH;                       /* '<S23>/Gain3' */
  real_T Accel;                        /* '<S23>/Far Constant' */
  real_T SetSpeedV2;                   /* '<S23>/Set Speed V2' */
  real_T SetSpeedV1;                   /* '<S23>/Set Speed V1' */
  real_T Product2;                     /* '<S23>/Product2' */
  real_T ACCReqPwr_m;                  /* '<S23>/Product3' */
  real_T Saturation_e;                 /* '<S23>/Saturation' */
  real_T Gain1;                        /* '<S23>/Gain1' */
  real_T Multiply;                     /* '<S23>/Multiply' */
  real_T Divide;                       /* '<S23>/Divide' */
  real_T uDLookupTable;                /* '<S23>/2-D Lookup Table' */
  real_T Saturation5;                  /* '<S23>/Saturation5' */
  real_T Divide2;                      /* '<S23>/Divide2' */
  int8_T DataTypeConv1;                /* '<S65>/DataTypeConv1' */
  int8_T DataTypeConv2;                /* '<S65>/DataTypeConv2' */
  boolean_T AND4;                      /* '<S23>/AND4' */
  boolean_T CastToBoolean1;            /* '<S23>/Cast To Boolean1' */
  boolean_T AND3;                      /* '<S23>/AND3' */
  boolean_T Compare;                   /* '<S30>/Compare' */
  boolean_T Compare_k;                 /* '<S31>/Compare' */
  boolean_T CastToBoolean;             /* '<S23>/Cast To Boolean' */
  boolean_T AND1;                      /* '<S23>/AND1' */
  boolean_T AND2;                      /* '<S23>/AND2' */
  boolean_T OR2;                       /* '<S23>/OR2' */
  boolean_T Compare_a;                 /* '<S29>/Compare' */
  boolean_T AND5;                      /* '<S23>/AND5' */
  boolean_T OR1;                       /* '<S23>/OR1' */
  boolean_T NOT2;                      /* '<S23>/NOT2' */
  boolean_T AND;                       /* '<S23>/AND' */
  boolean_T OR;                        /* '<S23>/OR' */
  boolean_T Compare_e;                 /* '<S33>/Compare' */
  boolean_T BrakeHoldActive;           /* '<S23>/AND6' */
  boolean_T Compare_h;                 /* '<S32>/Compare' */
  boolean_T VectorConcatenate_e[2];    /* '<S37>/Vector Concatenate' */
  boolean_T NotEqual;                  /* '<S65>/NotEqual' */
  boolean_T Equal1;                    /* '<S65>/Equal1' */
  boolean_T AND3_e;                    /* '<S65>/AND3' */
  B_DistanceRC_HSC_Model_T sf_StopLightRC;/* '<S23>/StopLightRC' */
  B_DistanceRC_HSC_Model_T sf_DistanceRC;/* '<S23>/DistanceRC' */
} B_ACCLookup_HSC_Model_T;

/* Block states (default storage) for system '<S12>/ACC Lookup' */
typedef struct {
  real_T DelayOneStep1_DSTATE;         /* '<S23>/Delay One Step1' */
  real_T DelayOneStep_DSTATE;          /* '<S23>/Delay One Step' */
  real_T UD_DSTATE;                    /* '<S34>/UD' */
  real_T UD_DSTATE_i;                  /* '<S35>/UD' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S23>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTATE;/* '<S23>/Discrete-Time Integrator1' */
  real_T DiscreteTimeIntegrator3_DSTATE;/* '<S23>/Discrete-Time Integrator3' */
  real_T DiscreteTimeIntegrator_DSTATE_m;/* '<S37>/Discrete-Time Integrator' */
  real_T UnitDelay_DSTATE[2];          /* '<S37>/Unit Delay' */
  real_T UD_DSTATE_d;                  /* '<S67>/UD' */
  real_T Integrator_DSTATE;            /* '<S74>/Integrator' */
  real_T RateTransition_Buffer;        /* '<S23>/Rate Transition' */
  real_T RateTransition1_Buffer;       /* '<S23>/Rate Transition1' */
  real_T RateTransition2_Buffer;       /* '<S23>/Rate Transition2' */
  real_T TimeNewObject;                /* '<S23>/Chart4' */
  real_T RelVelLocal;                  /* '<S23>/Chart4' */
  real_T JustSwitchOnce;               /* '<S23>/Chart4' */
  real_T DistanceTravelled;            /* '<S23>/Chart' */
  real_T DistanceTraveling;            /* '<S23>/Chart' */
  real_T SetSpeedLatch;                /* '<S23>/Chart' */
  uint32_T temporalCounter_i1;         /* '<S23>/Chart4' */
  uint16_T temporalCounter_i1_p;       /* '<S23>/Chart5' */
  uint16_T temporalCounter_i1_pa;      /* '<S23>/Chart2' */
  int8_T DiscreteTimeIntegrator3_PrevResetState;/* '<S23>/Discrete-Time Integrator3' */
  uint8_T is_active_c38_HSC_Model;     /* '<S23>/Chart5' */
  uint8_T is_c38_HSC_Model;            /* '<S23>/Chart5' */
  uint8_T is_active_c37_HSC_Model;     /* '<S23>/Chart4' */
  uint8_T is_c37_HSC_Model;            /* '<S23>/Chart4' */
  uint8_T is_active_c36_HSC_Model;     /* '<S23>/Chart3' */
  uint8_T is_c36_HSC_Model;            /* '<S23>/Chart3' */
  uint8_T is_active_c23_HSC_Model;     /* '<S23>/Chart2' */
  uint8_T is_c23_HSC_Model;            /* '<S23>/Chart2' */
  uint8_T is_active_c7_HSC_Model;      /* '<S23>/Chart' */
  uint8_T is_c7_HSC_Model;             /* '<S23>/Chart' */
  DW_DistanceRC_HSC_Model_T sf_StopLightRC;/* '<S23>/StopLightRC' */
  DW_DistanceRC_HSC_Model_T sf_DistanceRC;/* '<S23>/DistanceRC' */
} DW_ACCLookup_HSC_Model_T;

/* Continuous states for system '<S12>/ACC Lookup' */
typedef struct {
  real_T Integrator3_CSTATE;           /* '<S100>/Integrator3' */
  real_T Integrator1_CSTATE;           /* '<S91>/Integrator1' */
} X_ACCLookup_HSC_Model_T;

/* State derivatives for system '<S12>/ACC Lookup' */
typedef struct {
  real_T Integrator3_CSTATE;           /* '<S100>/Integrator3' */
  real_T Integrator1_CSTATE;           /* '<S91>/Integrator1' */
} XDot_ACCLookup_HSC_Model_T;

/* State Disabled for system '<S12>/ACC Lookup' */
typedef struct {
  boolean_T Integrator3_CSTATE;        /* '<S100>/Integrator3' */
  boolean_T Integrator1_CSTATE;        /* '<S91>/Integrator1' */
} XDis_ACCLookup_HSC_Model_T;

/* Parameters for system: '<S12>/ACC Lookup' */
struct P_ACCLookup_HSC_Model_T_ {
  real_T PIDController1_D;             /* Mask Parameter: PIDController1_D
                                        * Referenced by: '<S66>/Derivative Gain'
                                        */
  real_T PIDController1_DifferentiatorICPrevScaledInput;
               /* Mask Parameter: PIDController1_DifferentiatorICPrevScaledInput
                * Referenced by: '<S67>/UD'
                */
  real_T PIDController1_I;             /* Mask Parameter: PIDController1_I
                                        * Referenced by: '<S71>/Integral Gain'
                                        */
  real_T DiscreteDerivative_ICPrevScaledInput;
                         /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput
                          * Referenced by: '<S34>/UD'
                          */
  real_T DiscreteDerivative1_ICPrevScaledInput;
                        /* Mask Parameter: DiscreteDerivative1_ICPrevScaledInput
                         * Referenced by: '<S35>/UD'
                         */
  real_T PIDController1_InitialConditionForIntegrator;
                 /* Mask Parameter: PIDController1_InitialConditionForIntegrator
                  * Referenced by: '<S74>/Integrator'
                  */
  real_T PIDController1_LowerSaturationLimit;
                          /* Mask Parameter: PIDController1_LowerSaturationLimit
                           * Referenced by:
                           *   '<S65>/DeadZone'
                           *   '<S81>/Saturation'
                           */
  real_T PIDController1_P;             /* Mask Parameter: PIDController1_P
                                        * Referenced by: '<S79>/Proportional Gain'
                                        */
  real_T PIDController1_UpperSaturationLimit;
                          /* Mask Parameter: PIDController1_UpperSaturationLimit
                           * Referenced by:
                           *   '<S65>/DeadZone'
                           *   '<S81>/Saturation'
                           */
  real_T VehicleBodyTotalRoadLoad_a;
                                   /* Mask Parameter: VehicleBodyTotalRoadLoad_a
                                    * Referenced by: '<S91>/Constant3'
                                    */
  real_T VehicleBodyTotalRoadLoad_b;
                                   /* Mask Parameter: VehicleBodyTotalRoadLoad_b
                                    * Referenced by: '<S91>/b'
                                    */
  real_T VehicleBodyTotalRoadLoad_c;
                                   /* Mask Parameter: VehicleBodyTotalRoadLoad_c
                                    * Referenced by: '<S91>/c'
                                    */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S30>/Constant'
                                      */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S31>/Constant'
                                      */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S29>/Constant'
                                       */
  real_T CompareToConstant4_const;   /* Mask Parameter: CompareToConstant4_const
                                      * Referenced by: '<S33>/Constant'
                                      */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S32>/Constant'
                                      */
  real_T VehicleBodyTotalRoadLoad_g;
                                   /* Mask Parameter: VehicleBodyTotalRoadLoad_g
                                    * Referenced by:
                                    *   '<S91>/Constant4'
                                    *   '<S106>/Constant'
                                    */
  real_T VehicleBodyTotalRoadLoad_m;
                                   /* Mask Parameter: VehicleBodyTotalRoadLoad_m
                                    * Referenced by:
                                    *   '<S91>/m'
                                    *   '<S91>/m1'
                                    *   '<S106>/Constant'
                                    *   '<S106>/Constant1'
                                    */
  real_T VehicleBodyTotalRoadLoad_x_o;
                                 /* Mask Parameter: VehicleBodyTotalRoadLoad_x_o
                                  * Referenced by: '<S91>/Integrator1'
                                  */
  real_T VehicleBodyTotalRoadLoad_xdot_o;
                              /* Mask Parameter: VehicleBodyTotalRoadLoad_xdot_o
                               * Referenced by: '<S100>/Integrator3'
                               */
  real_T Gain1_Gain;                   /* Expression: 1.60934
                                        * Referenced by: '<S23>/Gain1'
                                        */
  real_T uDLookupTable_bp01Data[50];   /* Expression: [-298
                                          -107.877551
                                          82.24489796
                                          272.3673469
                                          462.4897959
                                          652.6122449
                                          842.7346939
                                          1032.857143
                                          1222.979592
                                          1413.102041
                                          1603.22449
                                          1793.346939
                                          1983.469388
                                          2173.591837
                                          2363.714286
                                          2553.836735
                                          2743.959184
                                          2934.081633
                                          3124.204082
                                          3314.326531
                                          3504.44898
                                          3694.571429
                                          3884.693878
                                          4074.816327
                                          4264.938776
                                          4455.061224
                                          4645.183673
                                          4835.306122
                                          5025.428571
                                          5215.55102
                                          5405.673469
                                          5595.795918
                                          5785.918367
                                          5976.040816
                                          6166.163265
                                          6356.285714
                                          6546.408163
                                          6736.530612
                                          6926.653061
                                          7116.77551
                                          7306.897959
                                          7497.020408
                                          7687.142857
                                          7877.265306
                                          8067.387755
                                          8257.510204
                                          8447.632653
                                          8637.755102
                                          8827.877551
                                          9018
                                          ]
                                        * Referenced by: '<S23>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp02Data[17];
              /* Expression: [0	2	4	6	10	20	30	40	50	60	70	80	90	100	120	140	180
                 ]
               * Referenced by: '<S23>/2-D Lookup Table'
               */
  real_T Saturation5_UpperSat;         /* Expression: 100
                                        * Referenced by: '<S23>/Saturation5'
                                        */
  real_T Saturation5_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S23>/Saturation5'
                                        */
  real_T Constant10_Value;             /* Expression: 3
                                        * Referenced by: '<S23>/Constant10'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 0
                                        * Referenced by: '<S23>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: -4.5
                                        * Referenced by: '<S23>/Saturation'
                                        */
  real_T SetSpeedV1_bp01Data[19];      /* Expression: [0:2:36]
                                        * Referenced by: '<S23>/Set Speed V1'
                                        */
  real_T SetSpeedV1_bp02Data[19];      /* Expression: [0:2:36]
                                        * Referenced by: '<S23>/Set Speed V1'
                                        */
  real_T SetSpeedV2_bp01Data[19];      /* Expression: [0:2:36]
                                        * Referenced by: '<S23>/Set Speed V2'
                                        */
  real_T SetSpeedV2_bp02Data[19];      /* Expression: [0:2:36]
                                        * Referenced by: '<S23>/Set Speed V2'
                                        */
  real_T Gain3_Gain;                   /* Expression: 2.23694
                                        * Referenced by: '<S23>/Gain3'
                                        */
  real_T FarConstant_bp01Data[20];     /* Expression: [0
                                          12.5
                                          15
                                          20
                                          25
                                          30
                                          35
                                          40
                                          45
                                          50
                                          55
                                          60
                                          65
                                          70
                                          75
                                          80
                                          85
                                          90
                                          95
                                          100
                                          ]
                                        * Referenced by: '<S23>/Far Constant'
                                        */
  real_T FarConstant_bp02Data[17];     /* Expression: [0:5:80]
                                        * Referenced by: '<S23>/Far Constant'
                                        */
  real_T Gain8_Gain;                   /* Expression: 2.23694
                                        * Referenced by: '<S23>/Gain8'
                                        */
  real_T MediumConstant_bp01Data[20];  /* Expression: [0
                                          12.5
                                          15
                                          20
                                          25
                                          30
                                          35
                                          40
                                          45
                                          50
                                          55
                                          60
                                          65
                                          70
                                          75
                                          80
                                          85
                                          90
                                          95
                                          100
                                          ]
                                        * Referenced by: '<S23>/Medium Constant'
                                        */
  real_T MediumConstant_bp02Data[17];  /* Expression: [0:5:80]
                                        * Referenced by: '<S23>/Medium Constant'
                                        */
  real_T Gain2_Gain;                   /* Expression: 2.23694
                                        * Referenced by: '<S23>/Gain2'
                                        */
  real_T NearConstant_bp01Data[20];    /* Expression: [0
                                          12.5
                                          15
                                          20
                                          25
                                          30
                                          35
                                          40
                                          45
                                          50
                                          55
                                          60
                                          65
                                          70
                                          75
                                          80
                                          85
                                          90
                                          95
                                          100
                                          ]
                                        * Referenced by: '<S23>/Near Constant'
                                        */
  real_T NearConstant_bp02Data[17];    /* Expression: [0:5:80]
                                        * Referenced by: '<S23>/Near Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S65>/Constant1'
                                        */
  real_T Constant1_Value_b;            /* Expression: 0
                                        * Referenced by: '<S23>/Constant1'
                                        */
  real_T kph2ms_Gain;                  /* Expression: 0.277778
                                        * Referenced by: '<S23>/kph2m//s'
                                        */
  real_T Saturation4_UpperSat;         /* Expression: 5
                                        * Referenced by: '<S23>/Saturation4'
                                        */
  real_T Saturation4_LowerSat;         /* Expression: -5
                                        * Referenced by: '<S23>/Saturation4'
                                        */
  real_T DelayOneStep1_InitialCondition;/* Expression: 0.0
                                         * Referenced by: '<S23>/Delay One Step1'
                                         */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/Constant5'
                                        */
  real_T Constant26_Value;             /* Expression: 3
                                        * Referenced by: '<S23>/Constant26'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 4
                                        * Referenced by: '<S23>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -4
                                        * Referenced by: '<S23>/Saturation1'
                                        */
  real_T DelayOneStep_InitialCondition;/* Expression: 0.0
                                        * Referenced by: '<S23>/Delay One Step'
                                        */
  real_T deceleration_Value;           /* Expression: 2
                                        * Referenced by: '<S23>/deceleration'
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 0
                                        * Referenced by: '<S23>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: -10
                                        * Referenced by: '<S23>/Saturation3'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: 10
                                        * Referenced by: '<S23>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S23>/Saturation2'
                                        */
  real_T um2_Gain;                     /* Expression: 4
                                        * Referenced by: '<S91>/1//m2'
                                        */
  real_T Gain_Gain;                    /* Expression: 2.23694
                                        * Referenced by: '<S23>/Gain'
                                        */
  real_T uDLookupTable1_bp01Data[17];  /* Expression: [-75:10:-5,0,5:10:75]
                                        * Referenced by: '<S23>/2-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp02Data[17];  /* Expression: [0:5:80]
                                        * Referenced by: '<S23>/2-D Lookup Table1'
                                        */
  real_T uDLookupTable4_bp01Data[21];  /* Expression: [0:5:100]
                                        * Referenced by: '<S23>/2-D Lookup Table4'
                                        */
  real_T uDLookupTable4_bp02Data[16];  /* Expression: [0:2:30]
                                        * Referenced by: '<S23>/2-D Lookup Table4'
                                        */
  real_T a_Value;                      /* Expression: 118.55
                                        * Referenced by: '<S23>/a'
                                        */
  real_T b_Value;                      /* Expression: 3.535790981
                                        * Referenced by: '<S23>/b'
                                        */
  real_T c_Value;                      /* Expression: 0.550001906
                                        * Referenced by: '<S23>/c'
                                        */
  real_T Gain7_Gain;                   /* Expression: 1/100
                                        * Referenced by: '<S23>/Gain7'
                                        */
  real_T Constant_Value;               /* Expression: 2220
                                        * Referenced by: '<S23>/Constant'
                                        */
  real_T Constant4_Value;              /* Expression: 9.81
                                        * Referenced by: '<S23>/Constant4'
                                        */
  real_T Constant11_Value;             /* Expression: 0
                                        * Referenced by: '<S23>/Constant11'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/Constant2'
                                        */
  real_T Constant21_Value;             /* Expression: 0
                                        * Referenced by: '<S23>/Constant21'
                                        */
  real_T Constant22_Value;             /* Expression: 0
                                        * Referenced by: '<S23>/Constant22'
                                        */
  real_T Constant23_Value;             /* Expression: 0
                                        * Referenced by: '<S23>/Constant23'
                                        */
  real_T Constant24_Value;             /* Expression: -3
                                        * Referenced by: '<S23>/Constant24'
                                        */
  real_T Constant25_Value;             /* Expression: 0
                                        * Referenced by: '<S23>/Constant25'
                                        */
  real_T Constant3_Value;              /* Expression: 100
                                        * Referenced by: '<S23>/Constant3'
                                        */
  real_T Constant6_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/Constant6'
                                        */
  real_T DiscreteTimeIntegrator_gainval;
                           /* Computed Parameter: DiscreteTimeIntegrator_gainval
                            * Referenced by: '<S23>/Discrete-Time Integrator'
                            */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S23>/Discrete-Time Integrator'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator1_gainval
                           * Referenced by: '<S23>/Discrete-Time Integrator1'
                           */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S23>/Discrete-Time Integrator1'
                                        */
  real_T DiscreteTimeIntegrator3_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator3_gainval
                           * Referenced by: '<S23>/Discrete-Time Integrator3'
                           */
  real_T DiscreteTimeIntegrator3_IC;   /* Expression: 0
                                        * Referenced by: '<S23>/Discrete-Time Integrator3'
                                        */
  real_T DiscreteTimeIntegrator_gainval_e;
                         /* Computed Parameter: DiscreteTimeIntegrator_gainval_e
                          * Referenced by: '<S37>/Discrete-Time Integrator'
                          */
  real_T DiscreteTimeIntegrator_IC_d;  /* Expression: 0
                                        * Referenced by: '<S37>/Discrete-Time Integrator'
                                        */
  real_T UnitDelay_InitialCondition[2];/* Expression: [0,0]
                                        * Referenced by: '<S37>/Unit Delay'
                                        */
  real_T Tsamp_WtEt;                   /* Computed Parameter: Tsamp_WtEt
                                        * Referenced by: '<S69>/Tsamp'
                                        */
  real_T ZeroGain_Gain;                /* Expression: 0
                                        * Referenced by: '<S65>/ZeroGain'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S74>/Integrator'
                                        */
  real_T Constant11_Value_m;           /* Expression: 0
                                        * Referenced by: '<S100>/Constant11'
                                        */
  real_T Constant14_Value;             /* Expression: 0
                                        * Referenced by: '<S101>/Constant14'
                                        */
  real_T Constant5_Value_a;            /* Expression: 0
                                        * Referenced by: '<S101>/Constant5'
                                        */
  real_T Constant7_Value;              /* Expression: 0
                                        * Referenced by: '<S101>/Constant7'
                                        */
  real_T Constant1_Value_i;            /* Expression: 0
                                        * Referenced by: '<S97>/Constant1'
                                        */
  real_T Constant10_Value_l;           /* Expression: 0
                                        * Referenced by: '<S97>/Constant10'
                                        */
  real_T Constant12_Value;             /* Expression: 0
                                        * Referenced by: '<S97>/Constant12'
                                        */
  real_T Constant2_Value_d;            /* Expression: 0
                                        * Referenced by: '<S97>/Constant2'
                                        */
  real_T Constant_Value_k;             /* Expression: 0
                                        * Referenced by: '<S103>/Constant'
                                        */
  real_T Constant_Value_b;             /* Expression: 0
                                        * Referenced by: '<S93>/Constant'
                                        */
  uint32_T uDLookupTable_maxIndex[2];
                                   /* Computed Parameter: uDLookupTable_maxIndex
                                    * Referenced by: '<S23>/2-D Lookup Table'
                                    */
  uint32_T SetSpeedV1_maxIndex[2];    /* Computed Parameter: SetSpeedV1_maxIndex
                                       * Referenced by: '<S23>/Set Speed V1'
                                       */
  uint32_T SetSpeedV2_maxIndex[2];    /* Computed Parameter: SetSpeedV2_maxIndex
                                       * Referenced by: '<S23>/Set Speed V2'
                                       */
  uint32_T FarConstant_maxIndex[2];  /* Computed Parameter: FarConstant_maxIndex
                                      * Referenced by: '<S23>/Far Constant'
                                      */
  uint32_T MediumConstant_maxIndex[2];
                                  /* Computed Parameter: MediumConstant_maxIndex
                                   * Referenced by: '<S23>/Medium Constant'
                                   */
  uint32_T NearConstant_maxIndex[2];/* Computed Parameter: NearConstant_maxIndex
                                     * Referenced by: '<S23>/Near Constant'
                                     */
  uint32_T uDLookupTable1_maxIndex[2];
                                  /* Computed Parameter: uDLookupTable1_maxIndex
                                   * Referenced by: '<S23>/2-D Lookup Table1'
                                   */
  uint32_T uDLookupTable4_maxIndex[2];
                                  /* Computed Parameter: uDLookupTable4_maxIndex
                                   * Referenced by: '<S23>/2-D Lookup Table4'
                                   */
};

extern void HSC_Model_DistanceRC_Init(DW_DistanceRC_HSC_Model_T *localDW);
extern void HSC_Model_DistanceRC_Reset(DW_DistanceRC_HSC_Model_T *localDW);
extern void HSC_Model_DistanceRC(const uint8_T *rtu_RollingCount,
  B_DistanceRC_HSC_Model_T *localB, DW_DistanceRC_HSC_Model_T *localDW);
extern void HSC_Model_ACCLookup_Init(DW_ACCLookup_HSC_Model_T *localDW,
  P_ACCLookup_HSC_Model_T *localP, X_ACCLookup_HSC_Model_T *localX);
extern void HSC_Model_ACCLookup_Reset(DW_ACCLookup_HSC_Model_T *localDW,
  P_ACCLookup_HSC_Model_T *localP, X_ACCLookup_HSC_Model_T *localX);
extern void HSC_Model_ACCLookup_Deriv(B_ACCLookup_HSC_Model_T *localB,
  XDot_ACCLookup_HSC_Model_T *localXdot);
extern void HSC_Model_ACCLookup_Update(RT_MODEL_HSC_Model_T * const HSC_Model_M,
  real_T rtu_StopLightInfo_k, boolean_T rtu_StopLightInfo_n,
  B_ACCLookup_HSC_Model_T *localB, DW_ACCLookup_HSC_Model_T *localDW,
  P_ACCLookup_HSC_Model_T *localP);
extern void HSC_Model_ACCLookup(RT_MODEL_HSC_Model_T * const HSC_Model_M, real_T
  rtu_EgoSpd, real_T rtu_TargetRelPos, real_T rtu_TargetRelSpd, real_T rtu_Info,
  boolean_T rtu_Info_h, real_T rtu_Info_e, real_T rtu_Info_p, real_T
  rtu_DistInfo, real_T rtu_DistInfo_k, real_T rtu_DistInfo_j, real_T
  rtu_DistInfo_kj, real_T rtu_DistInfo_o, real_T rtu_DistInfo_c, real_T
  rtu_DistInfo_i, const boolean_T *rtu_StopLightInfo, real_T rtu_StopLightInfo_b,
  real_T rtu_StopLightInfo_i, boolean_T rtu_StopLightInfo_p, boolean_T
  rtu_StopLightInfo_n, boolean_T rtu_StopLightInfo_l, real_T rtu_StopLightInfo_a,
  real_T rtu_StopLightInfo_ih, const uint8_T *rtu_StopLightInfo_nd, const
  uint8_T *rtu_StopLightInfo_nc, B_ACCLookup_HSC_Model_T *localB,
  DW_ACCLookup_HSC_Model_T *localDW, P_ACCLookup_HSC_Model_T *localP,
  X_ACCLookup_HSC_Model_T *localX);

#endif                                 /* RTW_HEADER_HSC_Model_ACCLookup_h_ */
