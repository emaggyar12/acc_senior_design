/*
 * Code generation for system system '<S12>/ACC Lookup'
 *
 * Model                      : HSC_Model
 * Model version              : 1.270
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 00:10:45 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "HSC_Model_ACCLookup.h"

/* Include model header file for global data */
#include "HSC_Model.h"
#include "HSC_Model_private.h"
#include "look2_binlc.h"
#include "look2_binlg.h"
#include "look2_binlx.h"

/* Named constants for Chart: '<S23>/DistanceRC' */
#define HSC_Model_IN_Enter             ((uint8_T)1U)
#define HSC_Model_IN_NO_ACTIVE_CHILD   ((uint8_T)0U)
#define HSC_Model_IN_Valid1            ((uint8_T)2U)
#define HSC_Model_IN_Validity2         ((uint8_T)3U)

/* Named constants for Chart: '<S23>/Chart' */
#define HSC_Model_IN_Enter_d           ((uint8_T)1U)
#define HSC_Model_IN_NO_ACTIVE_CHILD_i ((uint8_T)0U)
#define HSC_Model_IN_Stop              ((uint8_T)2U)

/* Named constants for Chart: '<S23>/Chart2' */
#define HSC_Model_IN_DistanceIsLive    ((uint8_T)1U)
#define HSC_Model_IN_Enter_k           ((uint8_T)2U)
#define HSC_Model_IN_TakeLatestDistance ((uint8_T)3U)

/* Named constants for Chart: '<S23>/Chart3' */
#define HSC_Model_IN_Exit              ((uint8_T)2U)

/* Named constants for Chart: '<S23>/Chart4' */
#define HSC_Model_IN_HoldBrake         ((uint8_T)1U)
#define HSC_Model_IN_KeepTrackRelVel   ((uint8_T)2U)
#define HSC_Model_IN_LessDecel         ((uint8_T)3U)
#define HSC_Model_IN_LockDecel         ((uint8_T)4U)
#define HSC_Model_IN_NewObject         ((uint8_T)5U)
#define HSC_Model_IN_PossiblyStopping  ((uint8_T)6U)
#define HSC_Model_IN_ResumeNormality   ((uint8_T)7U)

/* Named constants for Chart: '<S23>/Chart5' */
#define HSC_Model_IN_HoldBrake_o       ((uint8_T)3U)
#define HSC_Model_IN_LatchDecel        ((uint8_T)4U)

/* Forward declaration for local functions */
static void HSC_Model_ResumeNormality(boolean_T rtu_Info_h,
  B_ACCLookup_HSC_Model_T *localB, DW_ACCLookup_HSC_Model_T *localDW);

/*
 * System initialize for atomic system:
 *    '<S23>/DistanceRC'
 *    '<S23>/StopLightRC'
 */
void HSC_Model_DistanceRC_Init(DW_DistanceRC_HSC_Model_T *localDW)
{
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c41_HSC_Model = 0U;
  localDW->is_c41_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD;
}

/*
 * System reset for atomic system:
 *    '<S23>/DistanceRC'
 *    '<S23>/StopLightRC'
 */
void HSC_Model_DistanceRC_Reset(DW_DistanceRC_HSC_Model_T *localDW)
{
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c41_HSC_Model = 0U;
  localDW->is_c41_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD;
}

/*
 * Output and update for atomic system:
 *    '<S23>/DistanceRC'
 *    '<S23>/StopLightRC'
 */
void HSC_Model_DistanceRC(const uint8_T *rtu_RollingCount,
  B_DistanceRC_HSC_Model_T *localB, DW_DistanceRC_HSC_Model_T *localDW)
{
  boolean_T sf_internal_predicateOutput;
  if (localDW->temporalCounter_i1 < 16383U) {
    localDW->temporalCounter_i1++;
  }

  /* Chart: '<S23>/DistanceRC' */
  /* Gateway: ACC Controller/ACC Classical/ACC Lookup/DistanceRC */
  /* During: ACC Controller/ACC Classical/ACC Lookup/DistanceRC */
  if (localDW->is_active_c41_HSC_Model == 0U) {
    /* Entry: ACC Controller/ACC Classical/ACC Lookup/DistanceRC */
    localDW->is_active_c41_HSC_Model = 1U;

    /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/DistanceRC */
    /* Transition: '<S36>:3' */
    localDW->is_c41_HSC_Model = HSC_Model_IN_Enter;

    /* Entry 'Enter': '<S36>:2' */
    /* '<S36>:2:3' StoplightValidity=0; */
    localB->StoplightValidity = 0.0;

    /* '<S36>:2:4' RCLocal=RollingCount; */
    localDW->RCLocal = *rtu_RollingCount;
  } else {
    switch (localDW->is_c41_HSC_Model) {
     case HSC_Model_IN_Enter:
      localB->StoplightValidity = 0.0;

      /* During 'Enter': '<S36>:2' */
      /* '<S36>:6:1' sf_internal_predicateOutput = RollingCount~=RCLocal; */
      if (*rtu_RollingCount != localDW->RCLocal) {
        /* Transition: '<S36>:6' */
        localDW->is_c41_HSC_Model = HSC_Model_IN_Valid1;
        localDW->temporalCounter_i1 = 0U;

        /* Entry 'Valid1': '<S36>:5' */
        /* '<S36>:5:3' StoplightValidity=1; */
        localB->StoplightValidity = 1.0;

        /* '<S36>:5:4' RCLocal=RollingCount; */
        localDW->RCLocal = *rtu_RollingCount;
      }
      break;

     case HSC_Model_IN_Valid1:
      localB->StoplightValidity = 1.0;

      /* During 'Valid1': '<S36>:5' */
      /* '<S36>:11:1' sf_internal_predicateOutput = RollingCount~=RCLocal; */
      if (*rtu_RollingCount != localDW->RCLocal) {
        /* Transition: '<S36>:11' */
        localDW->is_c41_HSC_Model = HSC_Model_IN_Validity2;
        localDW->temporalCounter_i1 = 0U;

        /* Entry 'Validity2': '<S36>:10' */
        /* '<S36>:10:3' StoplightValidity=1; */
        localB->StoplightValidity = 1.0;

        /* '<S36>:10:4' RCLocal=RollingCount; */
        localDW->RCLocal = *rtu_RollingCount;
      } else {
        /* '<S36>:13:1' sf_internal_predicateOutput = (after(5,sec)) && (RollingCount==RCLocal); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1 >= 10000U) &&
          (*rtu_RollingCount == localDW->RCLocal));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S36>:13' */
          localDW->is_c41_HSC_Model = HSC_Model_IN_Enter;

          /* Entry 'Enter': '<S36>:2' */
          /* '<S36>:2:3' StoplightValidity=0; */
          localB->StoplightValidity = 0.0;

          /* '<S36>:2:4' RCLocal=RollingCount; */
          localDW->RCLocal = *rtu_RollingCount;
        }
      }
      break;

     default:
      localB->StoplightValidity = 1.0;

      /* During 'Validity2': '<S36>:10' */
      /* '<S36>:12:1' sf_internal_predicateOutput = RollingCount~=RCLocal; */
      if (*rtu_RollingCount != localDW->RCLocal) {
        /* Transition: '<S36>:12' */
        localDW->is_c41_HSC_Model = HSC_Model_IN_Valid1;
        localDW->temporalCounter_i1 = 0U;

        /* Entry 'Valid1': '<S36>:5' */
        /* '<S36>:5:3' StoplightValidity=1; */
        localB->StoplightValidity = 1.0;

        /* '<S36>:5:4' RCLocal=RollingCount; */
        localDW->RCLocal = *rtu_RollingCount;
      } else {
        /* '<S36>:14:1' sf_internal_predicateOutput = (after(5,sec)) && (RollingCount==RCLocal); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1 >= 10000U) &&
          (*rtu_RollingCount == localDW->RCLocal));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S36>:14' */
          localDW->is_c41_HSC_Model = HSC_Model_IN_Enter;

          /* Entry 'Enter': '<S36>:2' */
          /* '<S36>:2:3' StoplightValidity=0; */
          localB->StoplightValidity = 0.0;

          /* '<S36>:2:4' RCLocal=RollingCount; */
          localDW->RCLocal = *rtu_RollingCount;
        }
      }
      break;
    }
  }

  /* End of Chart: '<S23>/DistanceRC' */
}

/* Function for Chart: '<S23>/Chart4' */
static void HSC_Model_ResumeNormality(boolean_T rtu_Info_h,
  B_ACCLookup_HSC_Model_T *localB, DW_ACCLookup_HSC_Model_T *localDW)
{
  boolean_T sf_internal_predicateOutput;
  real_T a;

  /* Chart: '<S23>/Chart4' */
  /* During 'ResumeNormality': '<S27>:40' */
  /* '<S27>:50:1' sf_internal_predicateOutput = ((DistanceOneStepDelay-LiveTargetDistance)>5 || (LiveTargetDistance-DistanceOneStepDelay)>5) && LiveTargetDistance>5 && LiveTargetDistance<=35  && LiveTargetDistance~=0 && RelVel>-3 && RelVel<0 && ACC_Active==1; */
  sf_internal_predicateOutput = (((localB->DelayOneStep1 - localB->DistInfo[5] >
    5.0) || (localB->DistInfo[5] - localB->DelayOneStep1 > 5.0)) &&
    (localB->DistInfo[5] > 5.0) && (localB->DistInfo[5] <= 35.0) &&
    (localB->DistInfo[5] != 0.0) && (localB->DistInfo[6] > -3.0) &&
    (localB->DistInfo[6] < 0.0) && rtu_Info_h);
  if (sf_internal_predicateOutput) {
    /* Transition: '<S27>:50' */
    /* '<S27>:50:1' DecelOut=0 */
    localB->DecelOut = 0.0;

    /* '<S27>:50:1' JustSwitchOnce=1 */
    localDW->JustSwitchOnce = 1.0;
    localDW->is_c37_HSC_Model = HSC_Model_IN_NewObject;
    localDW->temporalCounter_i1 = 0U;

    /* Entry 'NewObject': '<S27>:6' */
    /* '<S27>:6:3' DecelOut=DecelOut-0.5; */
    localB->DecelOut -= 0.5;

    /* '<S27>:6:4' RelVelLocal=RelVel */
    localDW->RelVelLocal = localB->DistInfo[6];
  } else {
    /* Chart: '<S23>/Chart4' */
    /* '<S27>:54:1' sf_internal_predicateOutput = DistanceValidity==1 && LiveTargetDistance>20 && LiveTargetDistance<75 && LiveTargetDistance~=0 && ( (RelVel<-5 && EgoSpeed<30) || (EgoSpeed<8 && RelVel<-1.5)) && DistanceRCValidity==1 && ACC_Active==1; */
    sf_internal_predicateOutput = ((localB->DistInfo[4] == 1.0) &&
      (localB->DistInfo[5] > 20.0) && (localB->DistInfo[5] < 75.0) &&
      (localB->DistInfo[5] != 0.0) && (((localB->DistInfo[6] < -5.0) &&
      (localB->EgoSpd < 30.0)) || ((localB->EgoSpd < 8.0) && (localB->DistInfo[6]
      < -1.5))) && (localB->sf_DistanceRC.StoplightValidity == 1.0) &&
      rtu_Info_h);
    if (sf_internal_predicateOutput) {
      /* Transition: '<S27>:54' */
      localDW->is_c37_HSC_Model = HSC_Model_IN_PossiblyStopping;

      /* Entry 'PossiblyStopping': '<S27>:53' */
      /* '<S27>:53:2' DistanceMustStop=1; */
      localB->DistanceMustStop = 1.0;

      /* '<S27>:53:3' DistanceTravelTarget=(0-(RelVel+EgoSpeed)^2)/(2*(-3)); */
      a = localB->DistInfo[6] + localB->EgoSpd;

      /* '<S27>:53:4' TotalStopDistance=DistanceTravelTarget+LiveTargetDistance-17; */
      /* '<S27>:53:5' DecelOut=(0-(EgoSpeed)^2)/(2*TotalStopDistance); */
      localB->DecelOut = (0.0 - localB->EgoSpd * localB->EgoSpd) / ((((0.0 - a *
        a) / -6.0 + localB->DistInfo[5]) - 17.0) * 2.0);

      /* '<S27>:53:6' BrakeHold=0; */
      localB->BrakeHold_f = 0.0;

      /* '<S27>:53:7' DistanceState=3; */
      localB->DistanceState = 3.0;
    } else {
      /* '<S27>:40:2' DecelOut=DistanceDecel; */
      localB->DecelOut = localB->DistanceControllerAccel;

      /* '<S27>:40:3' RelVelLocal=0; */
      localDW->RelVelLocal = 0.0;

      /* '<S27>:40:4' TimeNewObject=0; */
      localDW->TimeNewObject = 0.0;

      /* '<S27>:40:5' DistanceState=1; */
      localB->DistanceState = 1.0;

      /* '<S27>:40:6' BrakeHold=0; */
      localB->BrakeHold_f = 0.0;

      /* '<S27>:40:7' DistanceMustStop=0; */
      localB->DistanceMustStop = 0.0;
    }
  }
}

/* System initialize for atomic system: '<S12>/ACC Lookup' */
void HSC_Model_ACCLookup_Init(DW_ACCLookup_HSC_Model_T *localDW,
  P_ACCLookup_HSC_Model_T *localP, X_ACCLookup_HSC_Model_T *localX)
{
  /* InitializeConditions for Delay: '<S23>/Delay One Step1' */
  localDW->DelayOneStep1_DSTATE = localP->DelayOneStep1_InitialCondition;

  /* InitializeConditions for Delay: '<S23>/Delay One Step' */
  localDW->DelayOneStep_DSTATE = localP->DelayOneStep_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S34>/UD' */
  localDW->UD_DSTATE = localP->DiscreteDerivative_ICPrevScaledInput;

  /* InitializeConditions for UnitDelay: '<S35>/UD' */
  localDW->UD_DSTATE_i = localP->DiscreteDerivative1_ICPrevScaledInput;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE = localP->DiscreteTimeIntegrator_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = localP->DiscreteTimeIntegrator1_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator3' */
  localDW->DiscreteTimeIntegrator3_DSTATE = localP->DiscreteTimeIntegrator3_IC;
  localDW->DiscreteTimeIntegrator3_PrevResetState = 2;

  /* InitializeConditions for DiscreteIntegrator: '<S37>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE_m = localP->DiscreteTimeIntegrator_IC_d;

  /* InitializeConditions for UnitDelay: '<S37>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition[0];
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition[1];

  /* InitializeConditions for Delay: '<S67>/UD' */
  localDW->UD_DSTATE_d = localP->PIDController1_DifferentiatorICPrevScaledInput;

  /* InitializeConditions for DiscreteIntegrator: '<S74>/Integrator' */
  localDW->Integrator_DSTATE =
    localP->PIDController1_InitialConditionForIntegrator;

  /* InitializeConditions for Integrator: '<S100>/Integrator3' */
  localX->Integrator3_CSTATE = localP->VehicleBodyTotalRoadLoad_xdot_o;

  /* InitializeConditions for Integrator: '<S91>/Integrator1' */
  localX->Integrator1_CSTATE = localP->VehicleBodyTotalRoadLoad_x_o;

  /* SystemInitialize for Chart: '<S23>/DistanceRC' */
  HSC_Model_DistanceRC_Init(&localDW->sf_DistanceRC);

  /* SystemInitialize for Chart: '<S23>/Chart4' */
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c37_HSC_Model = 0U;
  localDW->is_c37_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemInitialize for Chart: '<S23>/Chart2' */
  localDW->temporalCounter_i1_pa = 0U;
  localDW->is_active_c23_HSC_Model = 0U;
  localDW->is_c23_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemInitialize for Chart: '<S23>/StopLightRC' */
  HSC_Model_DistanceRC_Init(&localDW->sf_StopLightRC);

  /* SystemInitialize for Chart: '<S23>/Chart' */
  localDW->is_active_c7_HSC_Model = 0U;
  localDW->is_c7_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemInitialize for Chart: '<S23>/Chart5' */
  localDW->temporalCounter_i1_p = 0U;
  localDW->is_active_c38_HSC_Model = 0U;
  localDW->is_c38_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemInitialize for Chart: '<S23>/Chart3' */
  localDW->is_active_c36_HSC_Model = 0U;
  localDW->is_c36_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;
}

/* System reset for atomic system: '<S12>/ACC Lookup' */
void HSC_Model_ACCLookup_Reset(DW_ACCLookup_HSC_Model_T *localDW,
  P_ACCLookup_HSC_Model_T *localP, X_ACCLookup_HSC_Model_T *localX)
{
  /* InitializeConditions for Delay: '<S23>/Delay One Step1' */
  localDW->DelayOneStep1_DSTATE = localP->DelayOneStep1_InitialCondition;

  /* InitializeConditions for Delay: '<S23>/Delay One Step' */
  localDW->DelayOneStep_DSTATE = localP->DelayOneStep_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S34>/UD' */
  localDW->UD_DSTATE = localP->DiscreteDerivative_ICPrevScaledInput;

  /* InitializeConditions for UnitDelay: '<S35>/UD' */
  localDW->UD_DSTATE_i = localP->DiscreteDerivative1_ICPrevScaledInput;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE = localP->DiscreteTimeIntegrator_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = localP->DiscreteTimeIntegrator1_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator3' */
  localDW->DiscreteTimeIntegrator3_DSTATE = localP->DiscreteTimeIntegrator3_IC;
  localDW->DiscreteTimeIntegrator3_PrevResetState = 2;

  /* InitializeConditions for DiscreteIntegrator: '<S37>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE_m = localP->DiscreteTimeIntegrator_IC_d;

  /* InitializeConditions for UnitDelay: '<S37>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition[0];
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition[1];

  /* InitializeConditions for Delay: '<S67>/UD' */
  localDW->UD_DSTATE_d = localP->PIDController1_DifferentiatorICPrevScaledInput;

  /* InitializeConditions for DiscreteIntegrator: '<S74>/Integrator' */
  localDW->Integrator_DSTATE =
    localP->PIDController1_InitialConditionForIntegrator;

  /* InitializeConditions for Integrator: '<S100>/Integrator3' */
  localX->Integrator3_CSTATE = localP->VehicleBodyTotalRoadLoad_xdot_o;

  /* InitializeConditions for Integrator: '<S91>/Integrator1' */
  localX->Integrator1_CSTATE = localP->VehicleBodyTotalRoadLoad_x_o;

  /* SystemReset for Chart: '<S23>/DistanceRC' */
  HSC_Model_DistanceRC_Reset(&localDW->sf_DistanceRC);

  /* SystemReset for Chart: '<S23>/Chart4' */
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c37_HSC_Model = 0U;
  localDW->is_c37_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemReset for Chart: '<S23>/Chart2' */
  localDW->temporalCounter_i1_pa = 0U;
  localDW->is_active_c23_HSC_Model = 0U;
  localDW->is_c23_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemReset for Chart: '<S23>/StopLightRC' */
  HSC_Model_DistanceRC_Reset(&localDW->sf_StopLightRC);

  /* SystemReset for Chart: '<S23>/Chart' */
  localDW->is_active_c7_HSC_Model = 0U;
  localDW->is_c7_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemReset for Chart: '<S23>/Chart5' */
  localDW->temporalCounter_i1_p = 0U;
  localDW->is_active_c38_HSC_Model = 0U;
  localDW->is_c38_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;

  /* SystemReset for Chart: '<S23>/Chart3' */
  localDW->is_active_c36_HSC_Model = 0U;
  localDW->is_c36_HSC_Model = HSC_Model_IN_NO_ACTIVE_CHILD_i;
}

/* Outputs for atomic system: '<S12>/ACC Lookup' */
void HSC_Model_ACCLookup(RT_MODEL_HSC_Model_T * const HSC_Model_M, real_T
  rtu_EgoSpd, real_T rtu_TargetRelPos, real_T rtu_TargetRelSpd, real_T rtu_Info,
  boolean_T rtu_Info_h, real_T rtu_Info_e, real_T rtu_Info_p, real_T
  rtu_DistInfo, real_T rtu_DistInfo_k, real_T rtu_DistInfo_j, real_T
  rtu_DistInfo_kj, real_T rtu_DistInfo_o, real_T rtu_DistInfo_c, real_T
  rtu_DistInfo_i, const boolean_T *rtu_StopLightInfo, real_T rtu_StopLightInfo_b,
  real_T rtu_StopLightInfo_i, boolean_T rtu_StopLightInfo_p, boolean_T
  rtu_StopLightInfo_n, boolean_T rtu_StopLightInfo_l, real_T rtu_StopLightInfo_a,
  real_T rtu_StopLightInfo_ih, const uint8_T *rtu_StopLightInfo_nd, const
  uint8_T *rtu_StopLightInfo_nc, B_ACCLookup_HSC_Model_T *localB,
  DW_ACCLookup_HSC_Model_T *localDW, P_ACCLookup_HSC_Model_T *localP,
  X_ACCLookup_HSC_Model_T *localX)
{
  boolean_T sf_internal_predicateOutput;
  real_T a;
  real_T u;
  int32_T i;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Gain: '<S23>/kph2m//s' */
    localB->SetSpd = localP->kph2ms_Gain * rtu_Info;
  }

  /* Inport: '<S23>/EgoSpd' */
  localB->EgoSpd = rtu_EgoSpd;

  /* Switch: '<S23>/Switch' */
  if (*rtu_StopLightInfo) {
    /* Lookup_n-D: '<S23>/Set Speed V2' */
    localB->SetSpeedV2 = look2_binlx(localB->SetSpd, localB->EgoSpd,
      localP->SetSpeedV2_bp01Data, localP->SetSpeedV2_bp02Data,
      HSC_Model_P.ACC_Setspeed_Lookup_V2, localP->SetSpeedV2_maxIndex, 19U);

    /* Saturate: '<S23>/Saturation4' */
    localB->SetSpeedAcccel2 = localB->SetSpeedV2;
  } else {
    /* Lookup_n-D: '<S23>/Set Speed V1' */
    localB->SetSpeedV1 = look2_binlc(localB->SetSpd, localB->EgoSpd,
      localP->SetSpeedV1_bp01Data, localP->SetSpeedV1_bp02Data,
      HSC_Model_P.ACC_Setspeed_Lookup, localP->SetSpeedV1_maxIndex, 19U);

    /* Saturate: '<S23>/Saturation4' */
    localB->SetSpeedAcccel2 = localB->SetSpeedV1;
  }

  /* End of Switch: '<S23>/Switch' */

  /* Saturate: '<S23>/Saturation4' */
  if (localB->SetSpeedAcccel2 > localP->Saturation4_UpperSat) {
    localB->setSpdAccel = localP->Saturation4_UpperSat;
  } else if (localB->SetSpeedAcccel2 < localP->Saturation4_LowerSat) {
    localB->setSpdAccel = localP->Saturation4_LowerSat;
  } else {
    localB->setSpdAccel = localB->SetSpeedAcccel2;
  }

  /* Inport: '<S23>/DistInfo' */
  localB->DistInfo[0] = rtu_DistInfo;
  localB->DistInfo[1] = rtu_DistInfo_k;
  localB->DistInfo[2] = rtu_DistInfo_j;
  localB->DistInfo[3] = rtu_DistInfo_kj;
  localB->DistInfo[4] = rtu_DistInfo_o;
  localB->DistInfo[5] = rtu_DistInfo_c;
  localB->DistInfo[6] = rtu_DistInfo_i;

  /* MultiPortSwitch: '<S23>/Multiport Switch' */
  switch ((int32_T)rtu_StopLightInfo_b) {
   case 1:
    /* Gain: '<S23>/Gain2' */
    localB->Gain2 = localP->Gain2_Gain * localB->EgoSpd;

    /* Lookup_n-D: '<S23>/Near Constant' */
    localB->NearConstant = look2_binlx(localB->DistInfo[5], localB->Gain2,
      localP->NearConstant_bp01Data, localP->NearConstant_bp02Data,
      HSC_Model_P.ACC_Distance_Lookup_Near_Constant_Method,
      localP->NearConstant_maxIndex, 20U);
    localB->DistanceControllerAccel = localB->NearConstant;
    break;

   case 2:
    /* Gain: '<S23>/Gain8' */
    localB->Gain8 = localP->Gain8_Gain * localB->EgoSpd;

    /* Lookup_n-D: '<S23>/Medium Constant' */
    localB->MediumConstant = look2_binlx(localB->DistInfo[5], localB->Gain8,
      localP->MediumConstant_bp01Data, localP->MediumConstant_bp02Data,
      HSC_Model_P.ACC_Distance_Lookup_Constant_Method,
      localP->MediumConstant_maxIndex, 20U);
    localB->DistanceControllerAccel = localB->MediumConstant;
    break;

   default:
    /* Gain: '<S23>/Gain3' */
    localB->SpdMPH = localP->Gain3_Gain * localB->EgoSpd;

    /* Lookup_n-D: '<S23>/Far Constant' */
    localB->Accel = look2_binlx(localB->DistInfo[5], localB->SpdMPH,
      localP->FarConstant_bp01Data, localP->FarConstant_bp02Data,
      HSC_Model_P.ACC_Distance_Lookup_Far_Constant_Method,
      localP->FarConstant_maxIndex, 20U);
    localB->DistanceControllerAccel = localB->Accel;
    break;
  }

  /* End of MultiPortSwitch: '<S23>/Multiport Switch' */
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Delay: '<S23>/Delay One Step1' */
    localB->DelayOneStep1 = localDW->DelayOneStep1_DSTATE;

    /* Chart: '<S23>/DistanceRC' */
    HSC_Model_DistanceRC(rtu_StopLightInfo_nd, &localB->sf_DistanceRC,
                         &localDW->sf_DistanceRC);

    /* Chart: '<S23>/Chart4' incorporates:
     *  Constant: '<S23>/Constant5'
     */
    if (localDW->temporalCounter_i1 < MAX_uint32_T) {
      localDW->temporalCounter_i1++;
    }

    /* Gateway: ACC Controller/ACC Classical/ACC Lookup/Chart4 */
    /* During: ACC Controller/ACC Classical/ACC Lookup/Chart4 */
    if (localDW->is_active_c37_HSC_Model == 0U) {
      /* Entry: ACC Controller/ACC Classical/ACC Lookup/Chart4 */
      localDW->is_active_c37_HSC_Model = 1U;

      /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/Chart4 */
      /* Transition: '<S27>:5' */
      localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

      /* Entry 'ResumeNormality': '<S27>:40' */
      /* '<S27>:40:2' DecelOut=DistanceDecel; */
      localB->DecelOut = localB->DistanceControllerAccel;

      /* '<S27>:40:3' RelVelLocal=0; */
      localDW->RelVelLocal = 0.0;

      /* '<S27>:40:4' TimeNewObject=0; */
      localDW->TimeNewObject = 0.0;

      /* '<S27>:40:5' DistanceState=1; */
      localB->DistanceState = 1.0;

      /* '<S27>:40:6' BrakeHold=0; */
      localB->BrakeHold_f = 0.0;

      /* '<S27>:40:7' DistanceMustStop=0; */
      localB->DistanceMustStop = 0.0;
    } else {
      switch (localDW->is_c37_HSC_Model) {
       case HSC_Model_IN_HoldBrake:
        /* During 'HoldBrake': '<S27>:76' */
        /* '<S27>:78:1' sf_internal_predicateOutput = (after(2,sec)) && (RelVel>3 || DistanceValidity==0 || (LiveTargetDistance>(SafeDistance+2)) || LiveTargetDistance==0 || ACC_Active==0 || APP>5); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1 >= 4000U) &&
          ((localB->DistInfo[6] > 3.0) || (localB->DistInfo[4] == 0.0) ||
           (localB->DistInfo[5] > localB->DistInfo[1] + 2.0) ||
           (localB->DistInfo[5] == 0.0) || (!rtu_Info_h) ||
           (localP->Constant5_Value > 5.0)));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S27>:78' */
          /* '<S27>:78:1' BrakeHold=0 */
          localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

          /* Entry 'ResumeNormality': '<S27>:40' */
          /* '<S27>:40:2' DecelOut=DistanceDecel; */
          localB->DecelOut = localB->DistanceControllerAccel;

          /* '<S27>:40:3' RelVelLocal=0; */
          localDW->RelVelLocal = 0.0;

          /* '<S27>:40:4' TimeNewObject=0; */
          localDW->TimeNewObject = 0.0;

          /* '<S27>:40:5' DistanceState=1; */
          localB->DistanceState = 1.0;

          /* '<S27>:40:6' BrakeHold=0; */
          localB->BrakeHold_f = 0.0;

          /* '<S27>:40:7' DistanceMustStop=0; */
          localB->DistanceMustStop = 0.0;
        } else {
          /* '<S27>:76:2' BrakeHold=1; */
          localB->BrakeHold_f = 1.0;

          /* '<S27>:76:3' DistanceState=6; */
          localB->DistanceState = 6.0;
        }
        break;

       case HSC_Model_IN_KeepTrackRelVel:
        /* During 'KeepTrackRelVel': '<S27>:29' */
        /* Transition: '<S27>:32' */
        localDW->is_c37_HSC_Model = HSC_Model_IN_NewObject;
        localDW->temporalCounter_i1 = 0U;

        /* Entry 'NewObject': '<S27>:6' */
        /* '<S27>:6:3' DecelOut=DecelOut-0.5; */
        localB->DecelOut -= 0.5;

        /* '<S27>:6:4' RelVelLocal=RelVel */
        localDW->RelVelLocal = localB->DistInfo[6];
        break;

       case HSC_Model_IN_LessDecel:
        /* During 'LessDecel': '<S27>:71' */
        /* '<S27>:74:1' sf_internal_predicateOutput = (after(2,sec)) && (RelVel>3 || DistanceValidity==0 || (LiveTargetDistance>(SafeDistance+2)) || LiveTargetDistance==0 || ACC_Active==0 || APP>5); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1 >= 4000U) &&
          ((localB->DistInfo[6] > 3.0) || (localB->DistInfo[4] == 0.0) ||
           (localB->DistInfo[5] > localB->DistInfo[1] + 2.0) ||
           (localB->DistInfo[5] == 0.0) || (!rtu_Info_h) ||
           (localP->Constant5_Value > 5.0)));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S27>:74' */
          localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

          /* Entry 'ResumeNormality': '<S27>:40' */
          /* '<S27>:40:2' DecelOut=DistanceDecel; */
          localB->DecelOut = localB->DistanceControllerAccel;

          /* '<S27>:40:3' RelVelLocal=0; */
          localDW->RelVelLocal = 0.0;

          /* '<S27>:40:4' TimeNewObject=0; */
          localDW->TimeNewObject = 0.0;

          /* '<S27>:40:5' DistanceState=1; */
          localB->DistanceState = 1.0;

          /* '<S27>:40:6' BrakeHold=0; */
          localB->BrakeHold_f = 0.0;

          /* '<S27>:40:7' DistanceMustStop=0; */
          localB->DistanceMustStop = 0.0;
        } else {
          /* '<S27>:77:1' sf_internal_predicateOutput = EgoSpeed==0; */
          if (localB->EgoSpd == 0.0) {
            /* Transition: '<S27>:77' */
            localDW->is_c37_HSC_Model = HSC_Model_IN_HoldBrake;
            localDW->temporalCounter_i1 = 0U;

            /* Entry 'HoldBrake': '<S27>:76' */
            /* '<S27>:76:2' BrakeHold=1; */
            localB->BrakeHold_f = 1.0;

            /* '<S27>:76:3' DistanceState=6; */
            localB->DistanceState = 6.0;
          } else {
            /* '<S27>:71:2' DecelOut=-0.4; */
            localB->DecelOut = -0.4;

            /* '<S27>:71:3' DistanceMustStop=1; */
            localB->DistanceMustStop = 1.0;

            /* '<S27>:71:4' DistanceState=5; */
            localB->DistanceState = 5.0;
          }
        }
        break;

       case HSC_Model_IN_LockDecel:
        /* During 'LockDecel': '<S27>:66' */
        /* '<S27>:84:1' sf_internal_predicateOutput = (after(2,sec)) && (RelVel>3 || DistanceValidity==0 || (LiveTargetDistance>(SafeDistance+5)) || LiveTargetDistance==0 || ACC_Active==0 || APP>5); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1 >= 4000U) &&
          ((localB->DistInfo[6] > 3.0) || (localB->DistInfo[4] == 0.0) ||
           (localB->DistInfo[5] > localB->DistInfo[1] + 5.0) ||
           (localB->DistInfo[5] == 0.0) || (!rtu_Info_h) ||
           (localP->Constant5_Value > 5.0)));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S27>:84' */
          localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

          /* Entry 'ResumeNormality': '<S27>:40' */
          /* '<S27>:40:2' DecelOut=DistanceDecel; */
          localB->DecelOut = localB->DistanceControllerAccel;

          /* '<S27>:40:3' RelVelLocal=0; */
          localDW->RelVelLocal = 0.0;

          /* '<S27>:40:4' TimeNewObject=0; */
          localDW->TimeNewObject = 0.0;

          /* '<S27>:40:5' DistanceState=1; */
          localB->DistanceState = 1.0;

          /* '<S27>:40:6' BrakeHold=0; */
          localB->BrakeHold_f = 0.0;

          /* '<S27>:40:7' DistanceMustStop=0; */
          localB->DistanceMustStop = 0.0;
        } else {
          /* '<S27>:73:1' sf_internal_predicateOutput = EgoSpeed<0.25; */
          if (localB->EgoSpd < 0.25) {
            /* Transition: '<S27>:73' */
            localDW->is_c37_HSC_Model = HSC_Model_IN_LessDecel;
            localDW->temporalCounter_i1 = 0U;

            /* Entry 'LessDecel': '<S27>:71' */
            /* '<S27>:71:2' DecelOut=-0.4; */
            localB->DecelOut = -0.4;

            /* '<S27>:71:3' DistanceMustStop=1; */
            localB->DistanceMustStop = 1.0;

            /* '<S27>:71:4' DistanceState=5; */
            localB->DistanceState = 5.0;
          } else {
            /* '<S27>:66:6' DistanceState=4; */
            localB->DistanceState = 4.0;
          }
        }
        break;

       case HSC_Model_IN_NewObject:
        /* During 'NewObject': '<S27>:6' */
        /* '<S27>:41:1' sf_internal_predicateOutput = LiveTargetDistance>=35 || DecelOut<=DistanceDecel|| LiveTargetDistance==0 || DistanceValidity==0 || DistanceRCValidity==0 || ACC_Active==0; */
        sf_internal_predicateOutput = ((localB->DistInfo[5] >= 35.0) ||
          (localB->DecelOut <= localB->DistanceControllerAccel) ||
          (localB->DistInfo[5] == 0.0) || (localB->DistInfo[4] == 0.0) ||
          (localB->sf_DistanceRC.StoplightValidity == 0.0) || (!rtu_Info_h));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S27>:41' */
          /* '<S27>:41:1' TimeNewObject=0 */
          /* '<S27>:41:1' JustSwitchOnce=1 */
          localDW->JustSwitchOnce = 1.0;
          localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

          /* Entry 'ResumeNormality': '<S27>:40' */
          /* '<S27>:40:2' DecelOut=DistanceDecel; */
          localB->DecelOut = localB->DistanceControllerAccel;

          /* '<S27>:40:3' RelVelLocal=0; */
          localDW->RelVelLocal = 0.0;

          /* '<S27>:40:4' TimeNewObject=0; */
          localDW->TimeNewObject = 0.0;

          /* '<S27>:40:5' DistanceState=1; */
          localB->DistanceState = 1.0;

          /* '<S27>:40:6' BrakeHold=0; */
          localB->BrakeHold_f = 0.0;

          /* '<S27>:40:7' DistanceMustStop=0; */
          localB->DistanceMustStop = 0.0;
        } else {
          /* '<S27>:30:1' sf_internal_predicateOutput = TimeNewObject>=0.5 && JustSwitchOnce==1; */
          sf_internal_predicateOutput = ((localDW->TimeNewObject >= 0.5) &&
            (localDW->JustSwitchOnce == 1.0));
          if (sf_internal_predicateOutput) {
            /* Transition: '<S27>:30' */
            localDW->is_c37_HSC_Model = HSC_Model_IN_KeepTrackRelVel;

            /* Entry 'KeepTrackRelVel': '<S27>:29' */
            /* '<S27>:29:3' RelVelLocal=RelVel; */
            localDW->RelVelLocal = localB->DistInfo[6];

            /* '<S27>:29:4' JustSwitchOnce=2; */
            localDW->JustSwitchOnce = 2.0;
          } else {
            /* '<S27>:36:1' sf_internal_predicateOutput = TimeNewObject>=0.5 && RelVel<RelVelLocal && JustSwitchOnce==2; */
            sf_internal_predicateOutput = ((localDW->TimeNewObject >= 0.5) &&
              (localB->DistInfo[6] < localDW->RelVelLocal) &&
              (localDW->JustSwitchOnce == 2.0));
            if (sf_internal_predicateOutput) {
              /* Transition: '<S27>:36' */
              /* '<S27>:36:1' TimeNewObject=0 */
              localDW->TimeNewObject = 0.0;

              /* Transition: '<S27>:49' */
              localDW->is_c37_HSC_Model = HSC_Model_IN_NewObject;
              localDW->temporalCounter_i1 = 0U;

              /* Entry 'NewObject': '<S27>:6' */
              /* '<S27>:6:3' DecelOut=DecelOut-0.5; */
              localB->DecelOut -= 0.5;

              /* '<S27>:6:4' RelVelLocal=RelVel */
              localDW->RelVelLocal = localB->DistInfo[6];
            } else {
              /* '<S27>:6:6' TimeNewObject=elapsed(sec); */
              localDW->TimeNewObject = (real_T)localDW->temporalCounter_i1 *
                0.0005;

              /* '<S27>:6:7' DistanceState=2; */
              localB->DistanceState = 2.0;
            }
          }
        }
        break;

       case HSC_Model_IN_PossiblyStopping:
        /* During 'PossiblyStopping': '<S27>:53' */
        /* '<S27>:56:1' sf_internal_predicateOutput = (RelVel>2 && (LiveTargetDistance>SafeDistance+5)) || LiveTargetDistance==0 || DistanceRCValidity==0 || DistanceValidity==0 || ACC_Active==0 || APP>5; */
        sf_internal_predicateOutput = (((localB->DistInfo[6] > 2.0) &&
          (localB->DistInfo[5] > localB->DistInfo[1] + 5.0)) ||
          (localB->DistInfo[5] == 0.0) ||
          (localB->sf_DistanceRC.StoplightValidity == 0.0) || (localB->DistInfo
          [4] == 0.0) || (!rtu_Info_h) || (localP->Constant5_Value > 5.0));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S27>:56' */
          /* '<S27>:56:1' DistanceMustStop=0 */
          localDW->is_c37_HSC_Model = HSC_Model_IN_ResumeNormality;

          /* Entry 'ResumeNormality': '<S27>:40' */
          /* '<S27>:40:2' DecelOut=DistanceDecel; */
          localB->DecelOut = localB->DistanceControllerAccel;

          /* '<S27>:40:3' RelVelLocal=0; */
          localDW->RelVelLocal = 0.0;

          /* '<S27>:40:4' TimeNewObject=0; */
          localDW->TimeNewObject = 0.0;

          /* '<S27>:40:5' DistanceState=1; */
          localB->DistanceState = 1.0;

          /* '<S27>:40:6' BrakeHold=0; */
          localB->BrakeHold_f = 0.0;

          /* '<S27>:40:7' DistanceMustStop=0; */
          localB->DistanceMustStop = 0.0;
        } else {
          /* '<S27>:67:1' sf_internal_predicateOutput = (EgoSpeed<2 && LiveTargetDistance<30 && RelVel<0) || LiveTargetDistance<20; */
          sf_internal_predicateOutput = (((localB->EgoSpd < 2.0) &&
            (localB->DistInfo[5] < 30.0) && (localB->DistInfo[6] < 0.0)) ||
            (localB->DistInfo[5] < 20.0));
          if (sf_internal_predicateOutput) {
            /* Transition: '<S27>:67' */
            localDW->is_c37_HSC_Model = HSC_Model_IN_LockDecel;
            localDW->temporalCounter_i1 = 0U;

            /* Entry 'LockDecel': '<S27>:66' */
            /* '<S27>:66:3' DecelOut=(0-(EgoSpeed)^2)/(2*(5)); */
            localB->DecelOut = (0.0 - localB->EgoSpd * localB->EgoSpd) / 10.0;

            /* '<S27>:66:4' DistanceMustStop=1; */
            localB->DistanceMustStop = 1.0;
          } else {
            /* '<S27>:53:2' DistanceMustStop=1; */
            localB->DistanceMustStop = 1.0;

            /* '<S27>:53:3' DistanceTravelTarget=(0-(RelVel+EgoSpeed)^2)/(2*(-3)); */
            a = localB->DistInfo[6] + localB->EgoSpd;

            /* '<S27>:53:4' TotalStopDistance=DistanceTravelTarget+LiveTargetDistance-17; */
            /* '<S27>:53:5' DecelOut=(0-(EgoSpeed)^2)/(2*TotalStopDistance); */
            localB->DecelOut = (0.0 - localB->EgoSpd * localB->EgoSpd) / ((((0.0
              - a * a) / -6.0 + localB->DistInfo[5]) - 17.0) * 2.0);

            /* '<S27>:53:6' BrakeHold=0; */
            localB->BrakeHold_f = 0.0;

            /* '<S27>:53:7' DistanceState=3; */
            localB->DistanceState = 3.0;
          }
        }
        break;

       default:
        HSC_Model_ResumeNormality(rtu_Info_h, localB, localDW);
        break;
      }
    }

    /* End of Chart: '<S23>/Chart4' */
  }

  /* Logic: '<S23>/AND4' */
  localB->AND4 = ((localB->DistInfo[4] != 0.0) &&
                  (localB->sf_DistanceRC.StoplightValidity != 0.0));

  /* Switch: '<S23>/Switch14' */
  if (localB->AND4) {
    /* Saturate: '<S23>/Saturation1' */
    localB->Switch14 = localB->DecelOut;
  } else {
    /* Saturate: '<S23>/Saturation1' incorporates:
     *  Constant: '<S23>/Constant26'
     */
    localB->Switch14 = localP->Constant26_Value;
  }

  /* End of Switch: '<S23>/Switch14' */

  /* Saturate: '<S23>/Saturation1' */
  if (localB->Switch14 > localP->Saturation1_UpperSat) {
    localB->distanceAccel = localP->Saturation1_UpperSat;
  } else if (localB->Switch14 < localP->Saturation1_LowerSat) {
    localB->distanceAccel = localP->Saturation1_LowerSat;
  } else {
    localB->distanceAccel = localB->Switch14;
  }

  /* Product: '<S23>/Divide4' incorporates:
   *  Constant: '<S23>/deceleration'
   */
  localB->Divide4 = localB->EgoSpd / localP->deceleration_Value;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Delay: '<S23>/Delay One Step' */
    localB->DelayOneStep = localDW->DelayOneStep_DSTATE;

    /* Chart: '<S23>/Chart2' */
    if (localDW->temporalCounter_i1_pa < 1023U) {
      localDW->temporalCounter_i1_pa++;
    }

    /* Gateway: ACC Controller/ACC Classical/ACC Lookup/Chart2 */
    /* During: ACC Controller/ACC Classical/ACC Lookup/Chart2 */
    if (localDW->is_active_c23_HSC_Model == 0U) {
      /* Entry: ACC Controller/ACC Classical/ACC Lookup/Chart2 */
      localDW->is_active_c23_HSC_Model = 1U;

      /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/Chart2 */
      /* Transition: '<S25>:5' */
      localDW->is_c23_HSC_Model = HSC_Model_IN_Enter_k;

      /* Entry 'Enter': '<S25>:4' */
    } else {
      switch (localDW->is_c23_HSC_Model) {
       case HSC_Model_IN_DistanceIsLive:
        /* During 'DistanceIsLive': '<S25>:9' */
        /* '<S25>:13:1' sf_internal_predicateOutput = CavDistanceValid==0; */
        if (!rtu_StopLightInfo_n) {
          /* Transition: '<S25>:13' */
          localDW->is_c23_HSC_Model = HSC_Model_IN_TakeLatestDistance;
          localDW->temporalCounter_i1_pa = 0U;

          /* Entry 'TakeLatestDistance': '<S25>:12' */
          /* '<S25>:12:3' LastDistance=CAVDistancetoIntersection; */
          localB->LastDistance = localB->DelayOneStep;
        } else {
          /* '<S25>:9:2' LastDistance=CAVDistancetoIntersection; */
          localB->LastDistance = localB->DelayOneStep;
        }
        break;

       case HSC_Model_IN_Enter_k:
        /* During 'Enter': '<S25>:4' */
        /* '<S25>:7:1' sf_internal_predicateOutput = CavDistanceValid==1 && TrafficLightPresent==1; */
        sf_internal_predicateOutput = (rtu_StopLightInfo_n &&
          rtu_StopLightInfo_l);
        if (sf_internal_predicateOutput) {
          /* Transition: '<S25>:7' */
          localDW->is_c23_HSC_Model = HSC_Model_IN_DistanceIsLive;

          /* Entry 'DistanceIsLive': '<S25>:9' */
          /* '<S25>:9:2' LastDistance=CAVDistancetoIntersection; */
          localB->LastDistance = localB->DelayOneStep;
        }
        break;

       default:
        /* During 'TakeLatestDistance': '<S25>:12' */
        /* '<S25>:14:1' sf_internal_predicateOutput = (after(0.5,sec)) && (TrafficLightPresent==0); */
        sf_internal_predicateOutput = ((localDW->temporalCounter_i1_pa >= 1000U)
          && (!rtu_StopLightInfo_l));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S25>:14' */
          localDW->is_c23_HSC_Model = HSC_Model_IN_Enter_k;

          /* Entry 'Enter': '<S25>:4' */
        } else {
          /* '<S25>:15:1' sf_internal_predicateOutput = CavDistanceValid==1; */
          if (rtu_StopLightInfo_n) {
            /* Transition: '<S25>:15' */
            localDW->is_c23_HSC_Model = HSC_Model_IN_DistanceIsLive;

            /* Entry 'DistanceIsLive': '<S25>:9' */
            /* '<S25>:9:2' LastDistance=CAVDistancetoIntersection; */
            localB->LastDistance = localB->DelayOneStep;
          }
        }
        break;
      }
    }

    /* End of Chart: '<S23>/Chart2' */

    /* Chart: '<S23>/StopLightRC' */
    HSC_Model_DistanceRC(rtu_StopLightInfo_nc, &localB->sf_StopLightRC,
                         &localDW->sf_StopLightRC);

    /* Chart: '<S23>/Chart' */
    /* Gateway: ACC Controller/ACC Classical/ACC Lookup/Chart */
    /* During: ACC Controller/ACC Classical/ACC Lookup/Chart */
    if (localDW->is_active_c7_HSC_Model == 0U) {
      /* Entry: ACC Controller/ACC Classical/ACC Lookup/Chart */
      localDW->is_active_c7_HSC_Model = 1U;

      /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/Chart */
      /* Transition: '<S24>:2' */
      localDW->is_c7_HSC_Model = HSC_Model_IN_Enter_d;

      /* Entry 'Enter': '<S24>:1' */
      /* '<S24>:1:2' Switch=0; */
      localB->Switch_d = 0.0;

      /* '<S24>:1:5' DistanceTravelled=(EgoSpd)*(TimeToNextState-1.5); */
      localDW->DistanceTravelled = (rtu_StopLightInfo_ih - 1.5) * localB->EgoSpd;

      /* '<S24>:1:8' DistanceTraveling=(EgoSpd)*(TimeToNextState); */
      localDW->DistanceTraveling = localB->EgoSpd * rtu_StopLightInfo_ih;
    } else if (localDW->is_c7_HSC_Model == 1) {
      /* During 'Enter': '<S24>:1' */
      /* '<S24>:8:1' sf_internal_predicateOutput = ((IsValid==1 && CurrentState==1 && DistanceTravelled<DistanceToIntersection && DistanceToIntersection>=0 && SetSpeedMs>1)... */
      /* '<S24>:8:2'  || (IsValid==1 && CurrentState==0 && DistanceTraveling>DistanceToIntersection && DistanceToIntersection>=0)) && StoplightRCValidity==1; */
      sf_internal_predicateOutput = (((rtu_StopLightInfo_l &&
        (rtu_StopLightInfo_a == 1.0) && (localDW->DistanceTravelled <
        localB->LastDistance) && (localB->LastDistance >= 0.0) &&
        (localB->SetSpd > 1.0)) || (rtu_StopLightInfo_l && (rtu_StopLightInfo_a ==
        0.0) && (localDW->DistanceTraveling > localB->LastDistance) &&
        (localB->LastDistance >= 0.0))) &&
        (localB->sf_StopLightRC.StoplightValidity == 1.0));
      if (sf_internal_predicateOutput) {
        /* Transition: '<S24>:8' */
        localDW->is_c7_HSC_Model = HSC_Model_IN_Stop;

        /* Entry 'Stop': '<S24>:7' */
        /* '<S24>:7:3' SetSpeedLatch=SetSpeedMs; */
        localDW->SetSpeedLatch = localB->SetSpd;
      } else {
        /* '<S24>:1:2' Switch=0; */
        localB->Switch_d = 0.0;

        /* '<S24>:1:5' DistanceTravelled=(EgoSpd)*(TimeToNextState-1.5); */
        localDW->DistanceTravelled = (rtu_StopLightInfo_ih - 1.5) *
          localB->EgoSpd;

        /* '<S24>:1:8' DistanceTraveling=(EgoSpd)*(TimeToNextState); */
        localDW->DistanceTraveling = localB->EgoSpd * rtu_StopLightInfo_ih;
      }
    } else {
      /* During 'Stop': '<S24>:7' */
      /* '<S24>:28:1' sf_internal_predicateOutput = (IsValid==1 && CurrentState==2) || IsValid==0 || SetSpeedMs>(SetSpeedLatch+0.1) || StoplightRCValidity==0; */
      sf_internal_predicateOutput = ((!rtu_StopLightInfo_l) ||
        (rtu_StopLightInfo_a == 2.0) || (localB->SetSpd > localDW->SetSpeedLatch
        + 0.1) || (localB->sf_StopLightRC.StoplightValidity == 0.0));
      if (sf_internal_predicateOutput) {
        /* Transition: '<S24>:28' */
        localDW->is_c7_HSC_Model = HSC_Model_IN_Enter_d;

        /* Entry 'Enter': '<S24>:1' */
        /* '<S24>:1:2' Switch=0; */
        localB->Switch_d = 0.0;

        /* '<S24>:1:5' DistanceTravelled=(EgoSpd)*(TimeToNextState-1.5); */
        localDW->DistanceTravelled = (rtu_StopLightInfo_ih - 1.5) *
          localB->EgoSpd;

        /* '<S24>:1:8' DistanceTraveling=(EgoSpd)*(TimeToNextState); */
        localDW->DistanceTraveling = localB->EgoSpd * rtu_StopLightInfo_ih;
      } else {
        /* '<S24>:7:5' Switch=1; */
        localB->Switch_d = 1.0;
      }
    }

    /* End of Chart: '<S23>/Chart' */

    /* DataTypeConversion: '<S23>/Cast To Boolean1' */
    localB->CastToBoolean1 = (localB->Switch_d != 0.0);

    /* Chart: '<S23>/Chart5' */
    if (localDW->temporalCounter_i1_p < 1023U) {
      localDW->temporalCounter_i1_p++;
    }

    /* Gateway: ACC Controller/ACC Classical/ACC Lookup/Chart5 */
    /* During: ACC Controller/ACC Classical/ACC Lookup/Chart5 */
    if (localDW->is_active_c38_HSC_Model == 0U) {
      /* Entry: ACC Controller/ACC Classical/ACC Lookup/Chart5 */
      localDW->is_active_c38_HSC_Model = 1U;

      /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/Chart5 */
      /* Transition: '<S28>:4' */
      localDW->is_c38_HSC_Model = HSC_Model_IN_Enter_d;

      /* Saturate: '<S23>/Saturation' */
      /* Entry 'Enter': '<S28>:3' */
      /* '<S28>:3:2' Decel=0; */
      localB->Decel = 0.0;

      /* '<S28>:3:3' BrakeHold=0; */
      localB->BrakeHold = 0.0;
    } else {
      switch (localDW->is_c38_HSC_Model) {
       case HSC_Model_IN_Enter_d:
        /* During 'Enter': '<S28>:3' */
        /* '<S28>:6:1' sf_internal_predicateOutput = MustStop==1 && ((DistanceToIntersection<=50 && EgoSpeed<11.2) || (DistanceToIntersection<=100 && EgoSpeed>=11.2 && EgoSpeed<13.4)... */
        /* '<S28>:6:2'  || (DistanceToIntersection<=120 && EgoSpeed>=13.4 && EgoSpeed<15.6) || (DistanceToIntersection<150 && EgoSpeed>=15.6)); */
        sf_internal_predicateOutput = (localB->CastToBoolean1 &&
          (((localB->LastDistance <= 50.0) && (localB->EgoSpd < 11.2)) ||
           ((localB->LastDistance <= 100.0) && (localB->EgoSpd >= 11.2) &&
            (localB->EgoSpd < 13.4)) || ((localB->LastDistance <= 120.0) &&
          (localB->EgoSpd >= 13.4) && (localB->EgoSpd < 15.6)) ||
           ((localB->LastDistance < 150.0) && (localB->EgoSpd >= 15.6))));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S28>:6' */
          localDW->is_c38_HSC_Model = HSC_Model_IN_Exit;
          localDW->temporalCounter_i1_p = 0U;

          /* Saturate: '<S23>/Saturation' */
          /* Entry 'Exit': '<S28>:5' */
          /* '<S28>:5:3' Decel=(0-(EgoSpeed^2))/(2*DistanceToIntersection); */
          localB->Decel = (0.0 - localB->EgoSpd * localB->EgoSpd) / (2.0 *
            localB->LastDistance);
        } else {
          /* Saturate: '<S23>/Saturation' */
          /* '<S28>:3:2' Decel=0; */
          localB->Decel = 0.0;

          /* '<S28>:3:3' BrakeHold=0; */
          localB->BrakeHold = 0.0;
        }
        break;

       case HSC_Model_IN_Exit:
        /* During 'Exit': '<S28>:5' */
        /* '<S28>:9:1' sf_internal_predicateOutput = MustStop==0; */
        if (!localB->CastToBoolean1) {
          /* Transition: '<S28>:9' */
          localDW->is_c38_HSC_Model = HSC_Model_IN_Enter_d;

          /* Saturate: '<S23>/Saturation' */
          /* Entry 'Enter': '<S28>:3' */
          /* '<S28>:3:2' Decel=0; */
          localB->Decel = 0.0;

          /* '<S28>:3:3' BrakeHold=0; */
          localB->BrakeHold = 0.0;
        } else {
          /* '<S28>:18:1' sf_internal_predicateOutput = EgoSpeed<=1; */
          if (localB->EgoSpd <= 1.0) {
            /* Transition: '<S28>:18' */
            localDW->is_c38_HSC_Model = HSC_Model_IN_LatchDecel;

            /* Saturate: '<S23>/Saturation' */
            /* Entry 'LatchDecel': '<S28>:17' */
            /* '<S28>:17:3' Decel=(0-(EgoSpeed^2))/(2*DistanceToIntersection); */
            localB->Decel = (0.0 - localB->EgoSpd * localB->EgoSpd) / (2.0 *
              localB->LastDistance);
          } else {
            /* '<S28>:22:1' sf_internal_predicateOutput = after(0.5,sec); */
            if (localDW->temporalCounter_i1_p >= 1000U) {
              /* Transition: '<S28>:22' */
              /* Transition: '<S28>:23' */
              localDW->is_c38_HSC_Model = HSC_Model_IN_Exit;
              localDW->temporalCounter_i1_p = 0U;

              /* Saturate: '<S23>/Saturation' */
              /* Entry 'Exit': '<S28>:5' */
              /* '<S28>:5:3' Decel=(0-(EgoSpeed^2))/(2*DistanceToIntersection); */
              localB->Decel = (0.0 - localB->EgoSpd * localB->EgoSpd) / (2.0 *
                localB->LastDistance);
            }
          }
        }
        break;

       case HSC_Model_IN_HoldBrake_o:
        /* During 'HoldBrake': '<S28>:27' */
        /* '<S28>:29:1' sf_internal_predicateOutput = MustStop==0; */
        if (!localB->CastToBoolean1) {
          /* Transition: '<S28>:29' */
          localDW->is_c38_HSC_Model = HSC_Model_IN_Enter_d;

          /* Saturate: '<S23>/Saturation' */
          /* Entry 'Enter': '<S28>:3' */
          /* '<S28>:3:2' Decel=0; */
          localB->Decel = 0.0;

          /* '<S28>:3:3' BrakeHold=0; */
          localB->BrakeHold = 0.0;
        } else {
          /* '<S28>:27:2' BrakeHold=1; */
          localB->BrakeHold = 1.0;
        }
        break;

       default:
        /* During 'LatchDecel': '<S28>:17' */
        /* '<S28>:24:1' sf_internal_predicateOutput = MustStop==0; */
        if (!localB->CastToBoolean1) {
          /* Transition: '<S28>:24' */
          localDW->is_c38_HSC_Model = HSC_Model_IN_Enter_d;

          /* Saturate: '<S23>/Saturation' */
          /* Entry 'Enter': '<S28>:3' */
          /* '<S28>:3:2' Decel=0; */
          localB->Decel = 0.0;

          /* '<S28>:3:3' BrakeHold=0; */
          localB->BrakeHold = 0.0;
        } else {
          /* '<S28>:28:1' sf_internal_predicateOutput = EgoSpeed==0; */
          if (localB->EgoSpd == 0.0) {
            /* Transition: '<S28>:28' */
            localDW->is_c38_HSC_Model = HSC_Model_IN_HoldBrake_o;

            /* Entry 'HoldBrake': '<S28>:27' */
            /* '<S28>:27:2' BrakeHold=1; */
            localB->BrakeHold = 1.0;
          }
        }
        break;
      }
    }

    /* End of Chart: '<S23>/Chart5' */

    /* Logic: '<S23>/AND3' */
    localB->AND3 = (localB->CastToBoolean1 &&
                    (localB->sf_StopLightRC.StoplightValidity != 0.0));

    /* Switch: '<S23>/Switch4' incorporates:
     *  Constant: '<S23>/Constant10'
     */
    if (localB->AND3) {
      /* Saturate: '<S23>/Saturation' */
      if (localB->Decel > localP->Saturation_UpperSat) {
        localB->Saturation_e = localP->Saturation_UpperSat;
      } else if (localB->Decel < localP->Saturation_LowerSat) {
        localB->Saturation_e = localP->Saturation_LowerSat;
      } else {
        localB->Saturation_e = localB->Decel;
      }

      localB->StopLightAccel = localB->Saturation_e;
    } else {
      localB->StopLightAccel = localP->Constant10_Value;
    }

    /* End of Switch: '<S23>/Switch4' */
  }

  /* MinMax: '<S23>/Min' */
  a = fmin(localB->setSpdAccel, localB->distanceAccel);
  a = fmin(a, localB->StopLightAccel);
  localB->TotalACCAccel = a;

  /* Saturate: '<S23>/Saturation3' */
  localB->Saturation3 = localB->TotalACCAccel;
  if (localB->Saturation3 > localP->Saturation3_UpperSat) {
    localB->Saturation3 = localP->Saturation3_UpperSat;
  } else {
    if (localB->Saturation3 < localP->Saturation3_LowerSat) {
      localB->Saturation3 = localP->Saturation3_LowerSat;
    }
  }

  /* End of Saturate: '<S23>/Saturation3' */
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Chart: '<S23>/Chart3' */
    /* Gateway: ACC Controller/ACC Classical/ACC Lookup/Chart3 */
    /* During: ACC Controller/ACC Classical/ACC Lookup/Chart3 */
    if (localDW->is_active_c36_HSC_Model == 0U) {
      /* Entry: ACC Controller/ACC Classical/ACC Lookup/Chart3 */
      localDW->is_active_c36_HSC_Model = 1U;

      /* Entry Internal: ACC Controller/ACC Classical/ACC Lookup/Chart3 */
      /* Transition: '<S26>:4' */
      localDW->is_c36_HSC_Model = HSC_Model_IN_Enter_d;

      /* Entry 'Enter': '<S26>:3' */
      /* '<S26>:3:2' DecelOut=0; */
      localB->DecelOut_d = 0.0;
    } else if (localDW->is_c36_HSC_Model == 1) {
      /* During 'Enter': '<S26>:3' */
      /* '<S26>:6:1' sf_internal_predicateOutput = DecelIn<-0.1; */
      if (localB->Saturation3 < -0.1) {
        /* Transition: '<S26>:6' */
        localDW->is_c36_HSC_Model = HSC_Model_IN_Exit;

        /* Entry 'Exit': '<S26>:5' */
        /* '<S26>:5:2' DecelOut=DecelIn; */
        localB->DecelOut_d = localB->Saturation3;
      } else {
        /* '<S26>:3:2' DecelOut=0; */
        localB->DecelOut_d = 0.0;
      }
    } else {
      /* During 'Exit': '<S26>:5' */
      /* '<S26>:7:1' sf_internal_predicateOutput = DecelIn>=-0.01; */
      if (localB->Saturation3 >= -0.01) {
        /* Transition: '<S26>:7' */
        localDW->is_c36_HSC_Model = HSC_Model_IN_Enter_d;

        /* Entry 'Enter': '<S26>:3' */
        /* '<S26>:3:2' DecelOut=0; */
        localB->DecelOut_d = 0.0;
      } else {
        /* '<S26>:5:2' DecelOut=DecelIn; */
        localB->DecelOut_d = localB->Saturation3;
      }
    }

    /* End of Chart: '<S23>/Chart3' */

    /* RelationalOperator: '<S30>/Compare' incorporates:
     *  Constant: '<S23>/Constant5'
     *  Constant: '<S30>/Constant'
     */
    localB->Compare = (localP->Constant5_Value <
                       localP->CompareToConstant1_const);
  }

  /* Switch: '<S23>/Switch1' */
  if (rtu_StopLightInfo_p) {
    localB->EBCM_Decel = rtu_StopLightInfo_i;
  } else {
    /* Product: '<S23>/Product2' */
    localB->Product2 = localB->DecelOut_d * (real_T)rtu_Info_h * (real_T)
      localB->Compare;
    localB->EBCM_Decel = localB->Product2;
  }

  /* End of Switch: '<S23>/Switch1' */

  /* RelationalOperator: '<S31>/Compare' incorporates:
   *  Constant: '<S31>/Constant'
   */
  localB->Compare_k = (localB->EBCM_Decel != localP->CompareToConstant2_const);
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* DataTypeConversion: '<S23>/Cast To Boolean' */
    localB->CastToBoolean = (localB->DistanceMustStop != 0.0);

    /* RelationalOperator: '<S29>/Compare' incorporates:
     *  Constant: '<S23>/Constant5'
     *  Constant: '<S29>/Constant'
     */
    localB->Compare_a = (localP->Constant5_Value <
                         localP->CompareToConstant_const);
  }

  /* Logic: '<S23>/AND1' */
  localB->AND1 = ((localB->sf_DistanceRC.StoplightValidity != 0.0) &&
                  localB->CastToBoolean && rtu_Info_h);

  /* Logic: '<S23>/AND2' */
  localB->AND2 = (rtu_Info_h && (localB->sf_StopLightRC.StoplightValidity != 0.0)
                  && localB->CastToBoolean1);

  /* Logic: '<S23>/OR2' */
  localB->OR2 = (localB->AND1 || localB->AND2);

  /* Logic: '<S23>/AND5' */
  localB->AND5 = (localB->OR2 && localB->Compare_a);

  /* Logic: '<S23>/OR1' */
  localB->OR1 = (rtu_StopLightInfo_p || localB->Compare_k || localB->AND5);

  /* Saturate: '<S23>/Saturation2' */
  localB->AccelCmd = localB->TotalACCAccel;
  if (localB->AccelCmd > localP->Saturation2_UpperSat) {
    localB->AccelCmd = localP->Saturation2_UpperSat;
  } else {
    if (localB->AccelCmd < localP->Saturation2_LowerSat) {
      localB->AccelCmd = localP->Saturation2_LowerSat;
    }
  }

  /* End of Saturate: '<S23>/Saturation2' */

  /* Gain: '<S91>/m1' */
  localB->m1 = localP->VehicleBodyTotalRoadLoad_m * localB->AccelCmd;

  /* Trigonometry: '<S91>/Trigonometric Function1' incorporates:
   *  UnitConversion: '<S91>/Unit Conversion'
   */
  /* Unit Conversion - from: deg to: rad
     Expression: output = (0.0174533*input) + (0) */
  localB->UnitConversion = 0.017453292519943295 * rtu_Info_e;
  localB->TrigonometricFunction1_o1 = sin(localB->UnitConversion);
  localB->TrigonometricFunction1_o2 = cos(localB->UnitConversion);
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Gain: '<S91>/m' incorporates:
     *  Constant: '<S91>/Constant4'
     */
    localB->m = localP->VehicleBodyTotalRoadLoad_m *
      localP->VehicleBodyTotalRoadLoad_g;
  }

  /* Product: '<S91>/Product5' */
  localB->Product5 = localB->TrigonometricFunction1_o1 * localB->m;

  /* Gain: '<S91>/1//m2' */
  localB->um2 = localP->um2_Gain * localB->EgoSpd;

  /* Trigonometry: '<S91>/Trigonometric Function2' */
  localB->TrigonometricFunction2 = tanh(localB->um2);

  /* Product: '<S91>/Product7' incorporates:
   *  Constant: '<S91>/Constant3'
   */
  localB->Product7 = localP->VehicleBodyTotalRoadLoad_a *
    localB->TrigonometricFunction2;

  /* Product: '<S91>/Product6' */
  localB->Product6 = localB->EgoSpd * localB->EgoSpd *
    localB->TrigonometricFunction2;

  /* Gain: '<S91>/c' */
  localB->c = localP->VehicleBodyTotalRoadLoad_c * localB->Product6;

  /* Gain: '<S91>/b' */
  localB->b = localP->VehicleBodyTotalRoadLoad_b * localB->EgoSpd;

  /* Sum: '<S91>/Add1' */
  localB->Add1 = (localB->Product7 + localB->c) + localB->b;

  /* Sum: '<S91>/Add2' */
  localB->TotalForce = (localB->m1 + localB->Product5) + localB->Add1;

  /* Switch: '<S23>/Switch3' incorporates:
   *  Constant: '<S23>/Constant1'
   */
  if (localB->OR1) {
    localB->ACCReqPwr = localP->Constant1_Value_b;
  } else {
    /* Product: '<S23>/Product3' */
    localB->ACCReqPwr_m = localB->TotalForce * localB->EgoSpd;
    localB->ACCReqPwr = localB->ACCReqPwr_m;
  }

  /* End of Switch: '<S23>/Switch3' */

  /* UnaryMinus: '<S23>/Unary Minus' */
  localB->DistErrFLipped = -localB->DistInfo[2];

  /* Gain: '<S23>/Gain' */
  localB->Gain = localP->Gain_Gain * localB->EgoSpd;

  /* Lookup_n-D: '<S23>/2-D Lookup Table1' */
  localB->uDLookupTable1 = look2_binlg(localB->DistErrFLipped, localB->Gain,
    localP->uDLookupTable1_bp01Data, localP->uDLookupTable1_bp02Data,
    HSC_Model_P.ACC_Distance_Lookup, localP->uDLookupTable1_maxIndex, 17U);

  /* Lookup_n-D: '<S23>/2-D Lookup Table4' */
  localB->uDLookupTable4 = look2_binlx(localB->LastDistance, localB->EgoSpd,
    localP->uDLookupTable4_bp01Data, localP->uDLookupTable4_bp02Data,
    HSC_Model_P.Stoplight_distance_speed_only, localP->uDLookupTable4_maxIndex,
    21U);

  /* Logic: '<S23>/NOT2' */
  localB->NOT2 = !rtu_StopLightInfo_n;

  /* Logic: '<S23>/AND' */
  localB->AND = (localB->NOT2 && rtu_StopLightInfo_l);
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Logic: '<S23>/OR' */
    localB->OR = ((localB->BrakeHold_f != 0.0) || (localB->BrakeHold != 0.0));

    /* RelationalOperator: '<S33>/Compare' incorporates:
     *  Constant: '<S23>/Constant5'
     *  Constant: '<S33>/Constant'
     */
    localB->Compare_e = (localP->Constant5_Value <
                         localP->CompareToConstant4_const);
  }

  /* Logic: '<S23>/AND6' */
  localB->BrakeHoldActive = (localB->OR && rtu_Info_h && localB->Compare_e);

  /* Product: '<S23>/Product' incorporates:
   *  Constant: '<S23>/b'
   */
  localB->Product = localP->b_Value * localB->EgoSpd;

  /* Math: '<S23>/Square' */
  localB->Square = localB->EgoSpd * localB->EgoSpd;

  /* Product: '<S23>/Product1' incorporates:
   *  Constant: '<S23>/c'
   */
  localB->Product1 = localP->c_Value * localB->Square;

  /* Gain: '<S23>/Gain7' */
  localB->Gain7 = localP->Gain7_Gain * rtu_Info_e;

  /* Product: '<S23>/Product4' incorporates:
   *  Constant: '<S23>/Constant'
   *  Constant: '<S23>/Constant4'
   */
  localB->Product4 = localB->Gain7 * localP->Constant_Value *
    localP->Constant4_Value;

  /* Sum: '<S23>/Add' incorporates:
   *  Constant: '<S23>/a'
   */
  localB->Add = ((localP->a_Value + localB->Product) + localB->Product1) +
    localB->Product4;

  /* RelationalOperator: '<S32>/Compare' incorporates:
   *  Constant: '<S32>/Constant'
   */
  localB->Compare_h = (localB->EBCM_Decel != localP->CompareToConstant3_const);
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Constant: '<S23>/Constant2' */
    localB->Constant2 = localP->Constant2_Value;

    /* Constant: '<S23>/Constant21' */
    localB->Constant21 = localP->Constant21_Value;

    /* Constant: '<S23>/Constant22' */
    localB->Constant22 = localP->Constant22_Value;

    /* Constant: '<S23>/Constant23' */
    localB->Constant23 = localP->Constant23_Value;

    /* RateTransition: '<S23>/Rate Transition' */
    if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
      localDW->RateTransition_Buffer = localB->EgoSpd;
    }

    /* DiscreteIntegrator: '<S23>/Discrete-Time Integrator3' */
    if (rtu_StopLightInfo_n && (localDW->DiscreteTimeIntegrator3_PrevResetState <=
         0)) {
      localDW->DiscreteTimeIntegrator3_DSTATE =
        localP->DiscreteTimeIntegrator3_IC;
    }

    localB->DistanceKeepTrack = localDW->DiscreteTimeIntegrator3_DSTATE;

    /* End of DiscreteIntegrator: '<S23>/Discrete-Time Integrator3' */
  }

  /* RateTransition: '<S23>/Rate Transition' */
  if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
    localB->RateTransition = localDW->RateTransition_Buffer;

    /* SampleTimeMath: '<S34>/TSamp'
     *
     * About '<S34>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     *  Multiplication by K = weightedTsampQuantized is being
     *  done implicitly by changing the scaling of the input signal.
     *  No work needs to be done here.  Downstream blocks may need
     *  to do work to handle the scaling of the output; this happens
     *  automatically.
     */
    localB->TSamp = localB->RateTransition;

    /* UnitDelay: '<S34>/UD' */
    localB->Uk1 = localDW->UD_DSTATE;

    /* Sum: '<S34>/Diff' */
    localB->Diff = localB->TSamp - localB->Uk1;

    /* SampleTimeMath: '<S35>/TSamp'
     *
     * About '<S35>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     *  Multiplication by K = weightedTsampQuantized is being
     *  done implicitly by changing the scaling of the input signal.
     *  No work needs to be done here.  Downstream blocks may need
     *  to do work to handle the scaling of the output; this happens
     *  automatically.
     */
    localB->TSamp_l = localB->Diff;

    /* UnitDelay: '<S35>/UD' */
    localB->Uk1_c = localDW->UD_DSTATE_i;

    /* Sum: '<S35>/Diff' */
    localB->Diff_l = localB->TSamp_l - localB->Uk1_c;

    /* DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */
    localB->EgoPosition = localDW->DiscreteTimeIntegrator_DSTATE;

    /* DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
    localB->xdotPosition = localDW->DiscreteTimeIntegrator1_DSTATE;
  }

  /* Product: '<S23>/Divide1' incorporates:
   *  Constant: '<S23>/Constant24'
   */
  localB->Divide1 = localB->EBCM_Decel / localP->Constant24_Value;

  /* SignalConversion generated from: '<S37>/Vector Concatenate1' */
  localB->VectorConcatenate1[0] = rtu_TargetRelSpd;

  /* SignalConversion generated from: '<S37>/Vector Concatenate1' */
  localB->VectorConcatenate1[1] = rtu_TargetRelSpd;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* DiscreteIntegrator: '<S37>/Discrete-Time Integrator' */
    localB->DiscreteTimeIntegrator = localDW->DiscreteTimeIntegrator_DSTATE_m;

    /* UnitDelay: '<S37>/Unit Delay' */
    localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
    localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];
  }

  /* Product: '<S37>/Product' */
  localB->Product_f = rtu_TargetRelSpd * rtu_TargetRelSpd;

  /* RelationalOperator: '<S37>/Relational Operator' */
  localB->VectorConcatenate_e[0] = (rtu_TargetRelSpd > localB->UnitDelay[0]);

  /* RelationalOperator: '<S37>/Relational Operator1' */
  localB->VectorConcatenate_e[1] = (rtu_TargetRelSpd < localB->UnitDelay[1]);

  /* Switch: '<S37>/Switch' */
  if (localB->VectorConcatenate_e[0]) {
    localB->Switch[0] = localB->VectorConcatenate1[0];
  } else {
    localB->Switch[0] = localB->UnitDelay[0];
  }

  if (localB->VectorConcatenate_e[1]) {
    localB->Switch[1] = localB->VectorConcatenate1[1];
  } else {
    localB->Switch[1] = localB->UnitDelay[1];
  }

  /* End of Switch: '<S37>/Switch' */

  /* Sum: '<S23>/Sum3' */
  localB->SetSpeedError = localB->SetSpd - localB->EgoSpd;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Gain: '<S79>/Proportional Gain' */
    localB->ProportionalGain = localP->PIDController1_P * localB->SetSpeedError;

    /* Gain: '<S66>/Derivative Gain' */
    localB->DerivativeGain = localP->PIDController1_D * localB->SetSpeedError;

    /* SampleTimeMath: '<S69>/Tsamp'
     *
     * About '<S69>/Tsamp':
     *  y = u * K where K = 1 / ( w * Ts )
     */
    localB->Tsamp = localB->DerivativeGain * localP->Tsamp_WtEt;

    /* Delay: '<S67>/UD' */
    localB->UD = localDW->UD_DSTATE_d;

    /* Sum: '<S67>/Diff' */
    localB->Diff_h = localB->Tsamp - localB->UD;

    /* Sum: '<S84>/Sum Fdbk' */
    localB->SumFdbk = (localB->ProportionalGain + localDW->Integrator_DSTATE) +
      localB->Diff_h;

    /* Gain: '<S65>/ZeroGain' */
    localB->ZeroGain = localP->ZeroGain_Gain * localB->SumFdbk;

    /* DeadZone: '<S65>/DeadZone' incorporates:
     *  Saturate: '<S81>/Saturation'
     */
    if (localB->SumFdbk > localP->PIDController1_UpperSaturationLimit) {
      /* Signum: '<S65>/SignPreSat' */
      localB->DeadZone = localB->SumFdbk -
        localP->PIDController1_UpperSaturationLimit;
    } else if (localB->SumFdbk >= localP->PIDController1_LowerSaturationLimit) {
      /* Signum: '<S65>/SignPreSat' */
      localB->DeadZone = 0.0;
    } else {
      /* Signum: '<S65>/SignPreSat' */
      localB->DeadZone = localB->SumFdbk -
        localP->PIDController1_LowerSaturationLimit;
    }

    /* End of DeadZone: '<S65>/DeadZone' */

    /* RelationalOperator: '<S65>/NotEqual' */
    localB->NotEqual = (localB->ZeroGain != localB->DeadZone);

    /* Signum: '<S65>/SignPreSat' */
    if (localB->DeadZone < 0.0) {
      localB->SignPreSat = -1.0;
    } else if (localB->DeadZone > 0.0) {
      localB->SignPreSat = 1.0;
    } else if (localB->DeadZone == 0.0) {
      localB->SignPreSat = 0.0;
    } else {
      localB->SignPreSat = (rtNaN);
    }

    /* DataTypeConversion: '<S65>/DataTypeConv1' */
    localB->DataTypeConv1 = (int8_T)floor(localB->SignPreSat);

    /* Signum: '<S65>/SignPreIntegrator' incorporates:
     *  Gain: '<S71>/Integral Gain'
     */
    localB->IntegralGain = localP->PIDController1_I * localB->SetSpeedError;
    if (localB->IntegralGain < 0.0) {
      localB->SignPreIntegrator = -1.0;
    } else if (localB->IntegralGain > 0.0) {
      localB->SignPreIntegrator = 1.0;
    } else if (localB->IntegralGain == 0.0) {
      localB->SignPreIntegrator = 0.0;
    } else {
      localB->SignPreIntegrator = (rtNaN);
    }

    /* End of Signum: '<S65>/SignPreIntegrator' */

    /* DataTypeConversion: '<S65>/DataTypeConv2' */
    localB->DataTypeConv2 = (int8_T)floor(localB->SignPreIntegrator);

    /* RelationalOperator: '<S65>/Equal1' */
    localB->Equal1 = (localB->DataTypeConv1 == localB->DataTypeConv2);

    /* Logic: '<S65>/AND3' */
    localB->AND3_e = (localB->NotEqual && localB->Equal1);

    /* Switch: '<S65>/Switch' incorporates:
     *  Constant: '<S65>/Constant1'
     */
    if (localB->AND3_e) {
      localB->Switch_a = localP->Constant1_Value;
    } else {
      localB->Switch_a = localB->IntegralGain;
    }

    /* End of Switch: '<S65>/Switch' */

    /* DiscreteIntegrator: '<S74>/Integrator' */
    localB->Integrator = localP->Integrator_gainval * localB->Switch_a +
      localDW->Integrator_DSTATE;

    /* Saturate: '<S81>/Saturation' incorporates:
     *  Sum: '<S83>/Sum'
     */
    localB->Sum = (localB->ProportionalGain + localB->Integrator) +
      localB->Diff_h;
    if (localB->Sum > localP->PIDController1_UpperSaturationLimit) {
      localB->Saturation = localP->PIDController1_UpperSaturationLimit;
    } else if (localB->Sum < localP->PIDController1_LowerSaturationLimit) {
      localB->Saturation = localP->PIDController1_LowerSaturationLimit;
    } else {
      localB->Saturation = localB->Sum;
    }
  }

  /* Product: '<S23>/Product5' */
  localB->Product5_i = localB->Add * localB->EgoSpd;

  /* Switch: '<S23>/Switch5' incorporates:
   *  Constant: '<S23>/Constant11'
   */
  if (localB->Compare_h) {
    localB->Switch5 = localP->Constant11_Value;
  } else {
    /* Gain: '<S23>/Gain1' */
    localB->Gain1 = localP->Gain1_Gain * localB->EgoSpd;

    /* Gain: '<S23>/Multiply' */
    a = 1.0 / HSC_Model_P.Re;
    localB->Multiply = a * localB->EgoSpd;

    /* Product: '<S23>/Divide' */
    localB->Divide = localB->ACCReqPwr / localB->Multiply;

    /* Saturate: '<S23>/Saturation5' incorporates:
     *  Lookup_n-D: '<S23>/2-D Lookup Table'
     */
    localB->uDLookupTable = look2_binlc(localB->Divide, localB->Gain1,
      localP->uDLookupTable_bp01Data, localP->uDLookupTable_bp02Data,
      HSC_Model_P.Reverse_APP, localP->uDLookupTable_maxIndex, 50U);
    if (localB->uDLookupTable > localP->Saturation5_UpperSat) {
      localB->Saturation5 = localP->Saturation5_UpperSat;
    } else if (localB->uDLookupTable < localP->Saturation5_LowerSat) {
      localB->Saturation5 = localP->Saturation5_LowerSat;
    } else {
      localB->Saturation5 = localB->uDLookupTable;
    }

    /* End of Saturate: '<S23>/Saturation5' */

    /* Product: '<S23>/Divide2' incorporates:
     *  Constant: '<S23>/Constant3'
     */
    localB->Divide2 = localB->Saturation5 / localP->Constant3_Value;
    localB->Switch5 = localB->Divide2;
  }

  /* End of Switch: '<S23>/Switch5' */

  /* Product: '<S23>/Product6' incorporates:
   *  Constant: '<S23>/Constant3'
   */
  localB->Product6_m = localB->Switch5 * localP->Constant3_Value;

  /* RateTransition: '<S23>/Rate Transition1' incorporates:
   *  RateTransition: '<S23>/Rate Transition2'
   */
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
      localDW->RateTransition1_Buffer = localB->EgoSpd;
    }

    if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
      localDW->RateTransition2_Buffer = rtu_Info_p;
    }
  }

  if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
    localB->RateTransition1 = localDW->RateTransition1_Buffer;
    localB->RateTransition2 = localDW->RateTransition2_Buffer;
  }

  /* End of RateTransition: '<S23>/Rate Transition1' */

  /* Switch: '<S23>/Switch11' incorporates:
   *  Constant: '<S23>/Constant25'
   */
  if (localB->AND) {
    localB->Switch11 = localB->EgoSpd;
  } else {
    localB->Switch11 = localP->Constant25_Value;
  }

  /* End of Switch: '<S23>/Switch11' */

  /* Switch: '<S23>/Switch2' incorporates:
   *  Constant: '<S23>/Constant6'
   */
  if (localB->AND5) {
    localB->Switch2 = localP->Constant6_Value;
  } else {
    localB->Switch2 = 0.0;
  }

  /* End of Switch: '<S23>/Switch2' */

  /* Inport: '<S23>/TargetRelPos' */
  localB->TargetRelPos = rtu_TargetRelPos;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Constant: '<S100>/Constant11' */
    localB->Constant11 = localP->Constant11_Value_m;

    /* Constant: '<S101>/Constant14' */
    localB->Constant14 = localP->Constant14_Value;

    /* Constant: '<S101>/Constant5' */
    localB->Constant5 = localP->Constant5_Value_a;

    /* Constant: '<S101>/Constant7' */
    localB->Constant7 = localP->Constant7_Value;
  }

  /* Integrator: '<S100>/Integrator3' */
  localB->x = localX->Integrator3_CSTATE;

  /* SignalConversion generated from: '<S91>/Vector Concatenate2' */
  localB->VectorConcatenate2[0] = localB->AccelCmd;

  /* SignalConversion generated from: '<S91>/Vector Concatenate2' */
  localB->VectorConcatenate2[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate2' */
  localB->VectorConcatenate2[2] = 0.0;

  /* UnitConversion: '<S100>/Unit Conversion' */
  /* Unit Conversion - from: m/s^2 to: gn
     Expression: output = (0.101972*input) + (0) */
  localB->UnitConversion_e[0] = 0.10197162129779282 * localB->
    VectorConcatenate2[0];
  localB->UnitConversion_e[1] = 0.10197162129779282 * localB->
    VectorConcatenate2[1];
  localB->UnitConversion_e[2] = 0.10197162129779282 * localB->
    VectorConcatenate2[2];

  /* Sum: '<S97>/Add' */
  localB->Add_h = localB->UnitConversion;
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Constant: '<S97>/Constant1' */
    localB->Constant1 = localP->Constant1_Value_i;

    /* Constant: '<S97>/Constant10' */
    localB->Constant10 = localP->Constant10_Value_l;

    /* Constant: '<S97>/Constant12' */
    localB->Y = localP->Constant12_Value;

    /* Constant: '<S97>/Constant2' */
    localB->Constant2_i = localP->Constant2_Value_d;
  }

  /* SignalConversion generated from: '<S104>/sincos' incorporates:
   *  Constant: '<S103>/Constant'
   */
  localB->TmpSignalConversionAtsincosInport1[0] = localP->Constant_Value_k;
  localB->TmpSignalConversionAtsincosInport1[1] = localB->Add_h;
  localB->TmpSignalConversionAtsincosInport1[2] = localP->Constant_Value_k;

  /* Trigonometry: '<S104>/sincos' */
  u = localB->TmpSignalConversionAtsincosInport1[0];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1[0] = a;
  localB->sincos_o2[0] = u;
  u = localB->TmpSignalConversionAtsincosInport1[1];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1[1] = a;
  localB->sincos_o2[1] = u;
  u = localB->TmpSignalConversionAtsincosInport1[2];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1[2] = a;
  localB->sincos_o2[2] = u;

  /* Fcn: '<S104>/Fcn11' */
  localB->VectorConcatenate[0] = localB->sincos_o2[1] * localB->sincos_o2[0];

  /* Fcn: '<S104>/Fcn21' */
  localB->VectorConcatenate[1] = localB->sincos_o1[2] * localB->sincos_o1[1] *
    localB->sincos_o2[0] - localB->sincos_o2[2] * localB->sincos_o1[0];

  /* Fcn: '<S104>/Fcn31' */
  localB->VectorConcatenate[2] = localB->sincos_o2[2] * localB->sincos_o1[1] *
    localB->sincos_o2[0] + localB->sincos_o1[2] * localB->sincos_o1[0];

  /* Fcn: '<S104>/Fcn12' */
  localB->VectorConcatenate[3] = localB->sincos_o2[1] * localB->sincos_o1[0];

  /* Fcn: '<S104>/Fcn22' */
  localB->VectorConcatenate[4] = localB->sincos_o1[2] * localB->sincos_o1[1] *
    localB->sincos_o1[0] + localB->sincos_o2[2] * localB->sincos_o2[0];

  /* Fcn: '<S104>/Fcn32' */
  localB->VectorConcatenate[5] = localB->sincos_o2[2] * localB->sincos_o1[1] *
    localB->sincos_o1[0] - localB->sincos_o1[2] * localB->sincos_o2[0];

  /* Fcn: '<S104>/Fcn13' */
  localB->VectorConcatenate[6] = -localB->sincos_o1[1];

  /* Fcn: '<S104>/Fcn23' */
  localB->VectorConcatenate[7] = localB->sincos_o1[2] * localB->sincos_o2[1];

  /* Fcn: '<S104>/Fcn33' */
  localB->VectorConcatenate[8] = localB->sincos_o2[2] * localB->sincos_o2[1];

  /* Reshape: '<S105>/Reshape (9) to [3x3] column-major' */
  memcpy(&localB->Reshape9to3x3columnmajor[0], &localB->VectorConcatenate[0], 9U
         * sizeof(real_T));

  /* Math: '<S103>/Transpose' */
  for (i = 0; i < 3; i++) {
    localB->Transpose[3 * i] = localB->Reshape9to3x3columnmajor[i];
    localB->Transpose[3 * i + 1] = localB->Reshape9to3x3columnmajor[i + 3];
    localB->Transpose[3 * i + 2] = localB->Reshape9to3x3columnmajor[i + 6];
  }

  /* End of Math: '<S103>/Transpose' */

  /* SignalConversion generated from: '<S91>/Vector Concatenate1' */
  localB->VectorConcatenate1_i[0] = localB->EgoSpd;

  /* SignalConversion generated from: '<S91>/Vector Concatenate1' */
  localB->VectorConcatenate1_i[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate1' */
  localB->VectorConcatenate1_i[2] = 0.0;

  /* SignalConversion generated from: '<S103>/Product' incorporates:
   *  Constant: '<S103>/Constant'
   */
  localB->TmpSignalConversionAtProductInport2[0] = localB->VectorConcatenate1_i
    [0];
  localB->TmpSignalConversionAtProductInport2[1] = localP->Constant_Value_k;
  localB->TmpSignalConversionAtProductInport2[2] = localB->VectorConcatenate1_i
    [2];

  /* Product: '<S103>/Product' */
  memcpy(&localB->Transpose_d[0], &localB->Transpose[0], 9U * sizeof(real_T));
  for (i = 0; i < 3; i++) {
    localB->Product_h[i] = 0.0;
    localB->Product_h[i] += localB->Transpose_d[i] *
      localB->TmpSignalConversionAtProductInport2[0];
    localB->Product_h[i] += localB->Transpose_d[i + 3] *
      localB->TmpSignalConversionAtProductInport2[1];
    localB->Product_h[i] += localB->Transpose_d[i + 6] *
      localB->TmpSignalConversionAtProductInport2[2];
  }

  /* End of Product: '<S103>/Product' */

  /* Product: '<S106>/Product' incorporates:
   *  Constant: '<S106>/Constant'
   */
  a = localP->VehicleBodyTotalRoadLoad_m * localP->VehicleBodyTotalRoadLoad_g;
  localB->Product_d = a * localB->Product_h[2];

  /* UnitConversion: '<S106>/Unit Conversion' */
  /* Unit Conversion - from: gn to: m/s^2
     Expression: output = (9.80665*input) + (0) */
  localB->UnitConversion_l = 9.8066500000000012 * localB->UnitConversion_e[0];

  /* Product: '<S106>/Product1' incorporates:
   *  Constant: '<S106>/Constant1'
   */
  localB->Product1_n = localP->VehicleBodyTotalRoadLoad_m *
    localB->VectorConcatenate1_i[0] * localB->UnitConversion_l;

  /* SignalConversion generated from: '<S91>/Vector Concatenate4' */
  localB->VectorConcatenate4[0] = localB->TotalForce;

  /* SignalConversion generated from: '<S91>/Vector Concatenate4' */
  localB->VectorConcatenate4[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate4' */
  localB->VectorConcatenate4[2] = 0.0;

  /* Product: '<S106>/Product8' */
  localB->Product8 = localB->VectorConcatenate4[0] *
    localB->VectorConcatenate1_i[0];

  /* Product: '<S106>/Product9' */
  localB->Product9 = localB->Add1 * localB->VectorConcatenate1_i[0];

  /* UnaryMinus: '<S106>/Unary Minus' */
  localB->UnaryMinus = -localB->Product9;

  /* UnaryMinus: '<S106>/Unary Minus1' */
  localB->UnaryMinus1 = -localB->Product_d;

  /* SignalConversion generated from: '<S91>/Vector Concatenate3' */
  localB->VectorConcatenate3[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate5' */
  localB->VectorConcatenate5[0] = localB->m1;

  /* SignalConversion generated from: '<S91>/Vector Concatenate5' */
  localB->VectorConcatenate5[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate5' */
  localB->VectorConcatenate5[2] = 0.0;

  /* SignalConversion generated from: '<S111>/sincos' incorporates:
   *  Constant: '<S93>/Constant'
   */
  localB->TmpSignalConversionAtsincosInport1_a[0] = localP->Constant_Value_b;
  localB->TmpSignalConversionAtsincosInport1_a[1] = localB->UnitConversion;
  localB->TmpSignalConversionAtsincosInport1_a[2] = localP->Constant_Value_b;

  /* Trigonometry: '<S111>/sincos' */
  u = localB->TmpSignalConversionAtsincosInport1_a[0];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1_h[0] = a;
  localB->sincos_o2_n[0] = u;
  u = localB->TmpSignalConversionAtsincosInport1_a[1];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1_h[1] = a;
  localB->sincos_o2_n[1] = u;
  u = localB->TmpSignalConversionAtsincosInport1_a[2];
  a = sin(u);
  u = cos(u);
  localB->sincos_o1_h[2] = a;
  localB->sincos_o2_n[2] = u;

  /* Fcn: '<S111>/Fcn11' */
  localB->VectorConcatenate_b[0] = localB->sincos_o2_n[1] * localB->sincos_o2_n
    [0];

  /* Fcn: '<S111>/Fcn21' */
  localB->VectorConcatenate_b[1] = localB->sincos_o1_h[2] * localB->sincos_o1_h
    [1] * localB->sincos_o2_n[0] - localB->sincos_o2_n[2] * localB->sincos_o1_h
    [0];

  /* Fcn: '<S111>/Fcn31' */
  localB->VectorConcatenate_b[2] = localB->sincos_o2_n[2] * localB->sincos_o1_h
    [1] * localB->sincos_o2_n[0] + localB->sincos_o1_h[2] * localB->sincos_o1_h
    [0];

  /* Fcn: '<S111>/Fcn12' */
  localB->VectorConcatenate_b[3] = localB->sincos_o2_n[1] * localB->sincos_o1_h
    [0];

  /* Fcn: '<S111>/Fcn22' */
  localB->VectorConcatenate_b[4] = localB->sincos_o1_h[2] * localB->sincos_o1_h
    [1] * localB->sincos_o1_h[0] + localB->sincos_o2_n[2] * localB->sincos_o2_n
    [0];

  /* Fcn: '<S111>/Fcn32' */
  localB->VectorConcatenate_b[5] = localB->sincos_o2_n[2] * localB->sincos_o1_h
    [1] * localB->sincos_o1_h[0] - localB->sincos_o1_h[2] * localB->sincos_o2_n
    [0];

  /* Fcn: '<S111>/Fcn13' */
  localB->VectorConcatenate_b[6] = -localB->sincos_o1_h[1];

  /* Fcn: '<S111>/Fcn23' */
  localB->VectorConcatenate_b[7] = localB->sincos_o1_h[2] * localB->sincos_o2_n
    [1];

  /* Fcn: '<S111>/Fcn33' */
  localB->VectorConcatenate_b[8] = localB->sincos_o2_n[2] * localB->sincos_o2_n
    [1];

  /* Reshape: '<S112>/Reshape (9) to [3x3] column-major' */
  memcpy(&localB->Reshape9to3x3columnmajor_c[0], &localB->VectorConcatenate_b[0],
         9U * sizeof(real_T));

  /* Math: '<S93>/Transpose' */
  for (i = 0; i < 3; i++) {
    localB->Transpose_d[3 * i] = localB->Reshape9to3x3columnmajor_c[i];
    localB->Transpose_d[3 * i + 1] = localB->Reshape9to3x3columnmajor_c[i + 3];
    localB->Transpose_d[3 * i + 2] = localB->Reshape9to3x3columnmajor_c[i + 6];
  }

  /* End of Math: '<S93>/Transpose' */

  /* Integrator: '<S91>/Integrator1' */
  localB->VectorConcatenate3[0] = localX->Integrator1_CSTATE;

  /* SignalConversion generated from: '<S93>/Product' incorporates:
   *  Constant: '<S93>/Constant'
   */
  localB->TmpSignalConversionAtProductInport2_p[0] = localB->VectorConcatenate3
    [0];
  localB->TmpSignalConversionAtProductInport2_p[1] = localP->Constant_Value_b;
  localB->TmpSignalConversionAtProductInport2_p[2] = localB->VectorConcatenate3
    [1];

  /* Product: '<S93>/Product' */
  for (i = 0; i < 3; i++) {
    localB->Product_c[i] = 0.0;
    localB->Product_c[i] += localB->Transpose_d[i] *
      localB->TmpSignalConversionAtProductInport2_p[0];
    localB->Product_c[i] += localB->Transpose_d[i + 3] *
      localB->TmpSignalConversionAtProductInport2_p[1];
    localB->Product_c[i] += localB->Transpose_d[i + 6] *
      localB->TmpSignalConversionAtProductInport2_p[2];
  }

  /* End of Product: '<S93>/Product' */

  /* SignalConversion generated from: '<S91>/Vector Concatenate6' */
  localB->VectorConcatenate6[0] = localB->Product_c[0];

  /* SignalConversion generated from: '<S91>/Vector Concatenate6' */
  localB->VectorConcatenate6[1] = 0.0;

  /* SignalConversion generated from: '<S91>/Vector Concatenate6' */
  localB->VectorConcatenate6[2] = localB->Product_c[2];

  /* SignalConversion generated from: '<S91>/Vector Concatenate' */
  localB->VectorConcatenate_k[0] = localB->Product5;

  /* Product: '<S91>/Product1' */
  localB->VectorConcatenate_k[1] = localB->TrigonometricFunction1_o2 * localB->m;
}

/* Update for atomic system: '<S12>/ACC Lookup' */
void HSC_Model_ACCLookup_Update(RT_MODEL_HSC_Model_T * const HSC_Model_M, real_T
  rtu_StopLightInfo_k, boolean_T rtu_StopLightInfo_n, B_ACCLookup_HSC_Model_T
  *localB, DW_ACCLookup_HSC_Model_T *localDW, P_ACCLookup_HSC_Model_T *localP)
{
  if (rtmIsMajorTimeStep(HSC_Model_M)) {
    /* Update for Delay: '<S23>/Delay One Step1' */
    localDW->DelayOneStep1_DSTATE = localB->DistInfo[5];

    /* Update for Delay: '<S23>/Delay One Step' */
    localDW->DelayOneStep_DSTATE = rtu_StopLightInfo_k;

    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator3' */
    localDW->DiscreteTimeIntegrator3_DSTATE +=
      localP->DiscreteTimeIntegrator3_gainval * localB->Switch11;
    localDW->DiscreteTimeIntegrator3_PrevResetState = (int8_T)
      rtu_StopLightInfo_n;

    /* Update for DiscreteIntegrator: '<S37>/Discrete-Time Integrator' */
    localDW->DiscreteTimeIntegrator_DSTATE_m +=
      localP->DiscreteTimeIntegrator_gainval_e * localB->Product_f;

    /* Update for UnitDelay: '<S37>/Unit Delay' */
    localDW->UnitDelay_DSTATE[0] = localB->Switch[0];
    localDW->UnitDelay_DSTATE[1] = localB->Switch[1];

    /* Update for Delay: '<S67>/UD' */
    localDW->UD_DSTATE_d = localB->Tsamp;

    /* Update for DiscreteIntegrator: '<S74>/Integrator' */
    localDW->Integrator_DSTATE = localP->Integrator_gainval * localB->Switch_a +
      localB->Integrator;
  }

  if (rtmIsMajorTimeStep(HSC_Model_M) && rtmIsSampleHit(HSC_Model_M, 2, 0)) {
    /* Update for UnitDelay: '<S34>/UD' */
    localDW->UD_DSTATE = localB->TSamp;

    /* Update for UnitDelay: '<S35>/UD' */
    localDW->UD_DSTATE_i = localB->TSamp_l;

    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */
    localDW->DiscreteTimeIntegrator_DSTATE +=
      localP->DiscreteTimeIntegrator_gainval * localB->RateTransition1;

    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
    localDW->DiscreteTimeIntegrator1_DSTATE +=
      localP->DiscreteTimeIntegrator1_gainval * localB->RateTransition2;
  }
}

/* Derivatives for atomic system: '<S12>/ACC Lookup' */
void HSC_Model_ACCLookup_Deriv(B_ACCLookup_HSC_Model_T *localB,
  XDot_ACCLookup_HSC_Model_T *localXdot)
{
  /* Derivatives for Integrator: '<S100>/Integrator3' */
  localXdot->Integrator3_CSTATE = localB->VectorConcatenate1_i[0];

  /* Derivatives for Integrator: '<S91>/Integrator1' */
  localXdot->Integrator1_CSTATE = localB->EgoSpd;
}
