/*
 * HSC_Model_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HSC_Model".
 *
 * Model version              : 1.270
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 00:10:45 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "HSC_Model_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "HSC_Model.h"
#include "HSC_Model_capi.h"
#include "HSC_Model_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 22, TARGET_STRING("HSC_Model/ACC Controller/CAVPCM_ACCMd_Request"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 23, TARGET_STRING("HSC_Model/ACC Controller/Chart"),
    TARGET_STRING("AutoMdSpdLmtStat"), 0, 0, 0, 0, 0 },

  { 2, 23, TARGET_STRING("HSC_Model/ACC Controller/Chart"),
    TARGET_STRING("ACCAct370"), 1, 0, 0, 0, 0 },

  { 3, 23, TARGET_STRING("HSC_Model/ACC Controller/Chart"),
    TARGET_STRING("AdapCrsCntVDA"), 2, 0, 0, 0, 0 },

  { 4, 23, TARGET_STRING("HSC_Model/ACC Controller/Chart"),
    TARGET_STRING("ACCDrvrSeltdSpd"), 3, 0, 0, 0, 0 },

  { 5, 24, TARGET_STRING("HSC_Model/ACC Controller/Chart3"),
    TARGET_STRING("HoldCancelDecelBool"), 0, 1, 0, 0, 0 },

  { 6, 26, TARGET_STRING("HSC_Model/ACC Controller/Generate SetSpd"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 7, 83, TARGET_STRING("HSC_Model/ACC Controller/Cast To Boolean"),
    TARGET_STRING("CAVACCReq"), 0, 1, 0, 0, 0 },

  { 8, 83, TARGET_STRING("HSC_Model/ACC Controller/Cast To Boolean1"),
    TARGET_STRING("CAVPCM_ACCAct"), 0, 1, 0, 0, 1 },

  { 9, 1, TARGET_STRING("HSC_Model/ACC Controller/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 10, 83, TARGET_STRING("HSC_Model/ACC Controller/km//h2m//s1"),
    TARGET_STRING("VehSpdms"), 0, 0, 0, 0, 1 },

  { 11, 83, TARGET_STRING("HSC_Model/ACC Controller/OR"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 12, 2, TARGET_STRING("HSC_Model/ACC Controller/OR1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 13, 2, TARGET_STRING("HSC_Model/ACC Controller/Switch"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 14, 83, TARGET_STRING("HSC_Model/ACC Controller/Switch1"),
    TARGET_STRING("CAVPCM_ACCMdActive"), 0, 1, 0, 0, 1 },

  { 15, 83, TARGET_STRING("HSC_Model/ACC Controller/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 16, 39, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Chart"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 17, 40, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Chart1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 18, 41, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Chart2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 19, 42, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Chart3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 20, 43, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Chart4"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 21, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Gain1"),
    TARGET_STRING("ChargeLimit"), 0, 0, 0, 0, 1 },

  { 22, 44, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/kph to mph"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 23, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 24, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 25, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 26, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 27, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 28, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC5"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 29, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC6"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 30, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC7"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 31, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC8"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 32, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/2-D Lookup Table"),
    TARGET_STRING("ContinuousCurrentLimit"), 0, 0, 0, 0, 1 },

  { 33, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("CurrentLimit"), 0, 0, 0, 0, 1 },

  { 34, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("CurrentLimit"), 0, 0, 0, 0, 1 },

  { 35, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/ContinuousDischageLimit"),
    TARGET_STRING("ContinuousDischageLimit"), 0, 0, 0, 0, 1 },

  { 36, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 37, 37, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 38, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 39, 35, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 40, 36, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 41, 34, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 42, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Memory"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 43, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Memory1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 44, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Min"),
    TARGET_STRING("ChargeLimit"), 0, 0, 0, 0, 1 },

  { 45, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Min1"),
    TARGET_STRING("DischargeLimit"), 0, 0, 0, 0, 1 },

  { 46, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Divide"),
    TARGET_STRING("CurrentDemanded"), 0, 0, 0, 0, 1 },

  { 47, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Divide1"),
    TARGET_STRING("CurrentDemanded"), 0, 0, 0, 0, 1 },

  { 48, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Product4"),
    TARGET_STRING("Battery_Pwr_Limit_Charge"), 0, 0, 0, 0, 1 },

  { 49, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Product5"),
    TARGET_STRING("Battery_Pwr_Limit_Charge"), 0, 0, 0, 0, 1 },

  { 50, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Product6"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 51, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Product7"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 52, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 53, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 54, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 55, 83, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 56, 83, TARGET_STRING("HSC_Model/Diagnostics/Constant3"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 57, 83, TARGET_STRING("HSC_Model/Diagnostics/Cast To Boolean"),
    TARGET_STRING("power direction fault"), 0, 1, 0, 0, 0 },

  { 58, 83, TARGET_STRING("HSC_Model/Diagnostics/kph to mps"),
    TARGET_STRING("Veh Spd_m/s"), 0, 0, 0, 0, 1 },

  { 59, 83, TARGET_STRING("HSC_Model/Diagnostics/Memory1"),
    TARGET_STRING(""), 0, 2, 0, 1, 0 },

  { 60, 83, TARGET_STRING("HSC_Model/Diagnostics/Memory2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 61, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/kph to mps"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 62, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/mps to rad//s"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 63, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/NOT"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 64, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Mass 2550"),
    TARGET_STRING("TotDrvrDmdTrq"), 0, 0, 0, 0, 1 },

  { 65, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Multiply"),
    TARGET_STRING("map"), 0, 0, 0, 0, 1 },

  { 66, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 67, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Saturation2"),
    TARGET_STRING("TotDrvrDmdTrq"), 0, 0, 0, 0, 1 },

  { 68, 83, TARGET_STRING(
    "HSC_Model/Driver_Arbitration/prevents zeroing Pwr Dmd at 0 kph"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 69, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Sum"),
    TARGET_STRING("total"), 0, 0, 0, 0, 1 },

  { 70, 83, TARGET_STRING("HSC_Model/Driver_Arbitration/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 71, 72, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Energy Management Strategy"),
    TARGET_STRING("emcp_p_eng_des_W1"), 0, 0, 0, 0, 0 },

  { 72, 72, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Energy Management Strategy"),
    TARGET_STRING("emcp_p_tot_W1"), 1, 0, 0, 0, 0 },

  { 73, 72, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Energy Management Strategy"),
    TARGET_STRING("emcp_p_elec_des_W1"), 2, 0, 0, 0, 0 },

  { 74, 72, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Energy Management Strategy"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 75, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Abs"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 76, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Abs1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 77, 58, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/FinalDrive"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 78, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 79, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 80, 58, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 81, 58, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 82, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/kph to mph"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 83, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/kph to mps"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 84, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/kph to mps1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 85, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/1-D Lookup Table"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 86, 58, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/1-D Lookup Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 87, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 88, 58, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 89, 58, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Product2"),
    TARGET_STRING("Engine_Axle_Torque"), 0, 0, 0, 0, 1 },

  { 90, 58, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 91, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Saturation1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 92, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Add"),
    TARGET_STRING("totaloutputpower"), 0, 0, 0, 0, 1 },

  { 93, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Add1"),
    TARGET_STRING("eng_mot"), 0, 0, 0, 0, 1 },

  { 94, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Add2"),
    TARGET_STRING("diff"), 0, 0, 0, 0, 1 },

  { 95, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Add6"),
    TARGET_STRING("diff"), 0, 0, 0, 0, 1 },

  { 96, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Add7"),
    TARGET_STRING("diff"), 0, 0, 0, 0, 1 },

  { 97, 83, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 98, 58, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Direct Lookup Table (n-D)"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 99, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean"),
    TARGET_STRING("dist_is_valid"), 0, 1, 0, 0, 1 },

  { 100, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 101, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean10"),
    TARGET_STRING("xdotref"), 0, 0, 0, 0, 1 },

  { 102, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean11"),
    TARGET_STRING("ACCBrakeTime"), 0, 0, 0, 0, 1 },

  { 103, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean12"),
    TARGET_STRING("TrafficLightPresent"), 0, 1, 0, 0, 1 },

  { 104, 28, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean13"),
    TARGET_STRING("CAVtrgVel"), 0, 0, 0, 0, 1 },

  { 105, 27, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean14"),
    TARGET_STRING("CAVtrgDist"), 0, 0, 0, 0, 1 },

  { 106, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean15"),
    TARGET_STRING("grade"), 0, 0, 0, 0, 1 },

  { 107, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean16"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 108, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 109, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean22"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 110, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean23"),
    TARGET_STRING("APP"), 0, 0, 0, 0, 1 },

  { 111, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean24"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 112, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean25"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 113, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean26"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 114, 2, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean27"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 115, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean28"),
    TARGET_STRING("gear"), 0, 0, 0, 0, 1 },

  { 116, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean29"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 117, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean3"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 118, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean30"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 119, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean31"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 120, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean32"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 121, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean33"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 122, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean34"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 123, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean35"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 124, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean36"),
    TARGET_STRING(""), 0, 3, 0, 0, 0 },

  { 125, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean37"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 126, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean38"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 127, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean39"),
    TARGET_STRING("lvrpos"), 0, 4, 0, 0, 1 },

  { 128, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 129, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean40"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 130, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean41"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 131, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean42"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 132, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean43"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 133, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean44"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 134, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean45"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 135, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean46"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 136, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean47"),
    TARGET_STRING(""), 0, 3, 0, 0, 0 },

  { 137, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean48"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 138, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean49"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 139, 2, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 140, 61, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean50"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 141, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean51"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 142, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean6"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 143, 57, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean7"),
    TARGET_STRING("DrvIntndAxlTrqMax"), 0, 0, 0, 0, 1 },

  { 144, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean8"),
    TARGET_STRING("DrvIntndAxlTrqMin"), 0, 0, 0, 0, 1 },

  { 145, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Boolean9"),
    TARGET_STRING("TrqReqStat"), 0, 3, 0, 0, 1 },

  { 146, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double"),
    TARGET_STRING("Tanh_Exponent"), 0, 0, 0, 0, 1 },

  { 147, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double1"),
    TARGET_STRING("Tanh_multiplier"), 0, 0, 0, 0, 1 },

  { 148, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double2"),
    TARGET_STRING("CurrentState"), 0, 0, 0, 0, 0 },

  { 149, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double3"),
    TARGET_STRING("DistanceToIntersection"), 0, 0, 0, 0, 1 },

  { 150, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double4"),
    TARGET_STRING("TimeToIntersection"), 0, 0, 0, 0, 0 },

  { 151, 83, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double5"),
    TARGET_STRING("Decel_Division_Value"), 0, 0, 0, 0, 1 },

  { 152, 38, TARGET_STRING("HSC_Model/Input_Wrapper/Cast To Double6"),
    TARGET_STRING("bcm_coolan_temp_C"), 0, 0, 0, 0, 1 },

  { 153, 81, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/LockInPowerDemandToGetRidOfTorqueJerk"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 154, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Data Type Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 155, 79, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 156, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/kph to mph"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 157, 80, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/rbcp_regen_enable"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 158, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Logical Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 159, 76, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 160, 75, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 161, 74, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 162, 78, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/BPP Fade Out"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 163, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Steering Wheel Angle Fade Out"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 164, 73, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Vehicle Speed Fade Out"),
    TARGET_STRING("rbcp_brake_motor_fade_out"), 0, 0, 0, 0, 1 },

  { 165, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Multiport Switch"),
    TARGET_STRING("rbcp_brake_power_demand_W"), 0, 0, 0, 0, 1 },

  { 166, 77, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Multiport Switch1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 167, 79, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 168, 80, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Product1"),
    TARGET_STRING("RegenPowerW"), 0, 0, 0, 0, 1 },

  { 169, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Product2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 170, 78, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Product3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 171, 80, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Saturation1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 172, 78, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 173, 79, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 174, 80, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 175, 80, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Switch1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 176, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING("hsc_bms_enable"), 0, 0, 0, 0, 0 },

  { 177, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING("hsc_bms_leakage_ena"), 1, 0, 0, 0, 0 },

  { 178, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING("hsc_bms_mainc_close"), 2, 0, 0, 0, 0 },

  { 179, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 180, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 4, 0, 0, 0, 0 },

  { 181, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING("R1"), 5, 0, 0, 0, 0 },

  { 182, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING("R2"), 6, 0, 0, 0, 0 },

  { 183, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 7, 0, 0, 0, 0 },

  { 184, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 8, 0, 0, 0, 0 },

  { 185, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 9, 0, 0, 0, 0 },

  { 186, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 10, 0, 0, 0, 0 },

  { 187, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 11, 0, 0, 0, 0 },

  { 188, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 12, 0, 0, 0, 0 },

  { 189, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 13, 0, 0, 0, 0 },

  { 190, 82, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMCP"),
    TARGET_STRING(""), 14, 0, 0, 0, 0 },

  { 191, 83, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/kph to mph"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 192, 83, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/Memory1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 193, 83, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 194, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 195, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 1, 0, 0, 0, 1 },

  { 196, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("distanceAccel"), 2, 0, 0, 0, 1 },

  { 197, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("DistErrFLipped"), 2, 0, 0, 0, 1 },

  { 198, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 199, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 200, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("EBCM_Decel"), 2, 0, 0, 0, 1 },

  { 201, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("ACCReqPwr"), 2, 0, 0, 0, 1 },

  { 202, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 203, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 204, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 205, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 206, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("setSpdAccel"), 2, 0, 0, 0, 1 },

  { 207, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("TotalACCAccel"), 2, 0, 0, 0, 1 },

  { 208, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("Total Force"), 2, 0, 0, 0, 1 },

  { 209, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("SetSpeedError"), 2, 0, 0, 0, 1 },

  { 210, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("SetSpd"), 2, 0, 0, 0, 0 },

  { 211, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 1, 0, 0, 0 },

  { 212, 15, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("LastDistance"), 2, 0, 0, 0, 0 },

  { 213, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("StopLightAccel"), 2, 0, 0, 0, 0 },

  { 214, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 215, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 216, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 217, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 218, 20, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("StoplightValidity"), 2, 0, 0, 0, 0 },

  { 219, 19, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("StoplightValidity"), 2, 0, 0, 0, 0 },

  { 220, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 1, 0, 0, 0 },

  { 221, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("EgoSpd"), 2, 0, 0, 0, 1 },

  { 222, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING(""), 2, 0, 0, 0, 1 },

  { 223, 21, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("BrakeHoldActive"), 2, 1, 0, 0, 1 },

  { 224, 17, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup"),
    TARGET_STRING("DistanceState"), 2, 0, 0, 0, 0 },

  { 225, 2, TARGET_STRING(
    "HSC_Model/ACC Controller/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 226, 2, TARGET_STRING(
    "HSC_Model/ACC Controller/Compare To Constant2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 227, 2, TARGET_STRING(
    "HSC_Model/ACC Controller/Compare To Constant3/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 228, 25, TARGET_STRING("HSC_Model/ACC Controller/Dash/Chart"),
    TARGET_STRING("ACCAct3702"), 0, 1, 0, 0, 0 },

  { 229, 25, TARGET_STRING("HSC_Model/ACC Controller/Dash/Chart"),
    TARGET_STRING("ACCHdwySTG"), 4, 0, 0, 0, 0 },

  { 230, 25, TARGET_STRING("HSC_Model/ACC Controller/Dash/Chart"),
    TARGET_STRING("ACCDrvrSeltdSpd2"), 5, 0, 0, 0, 0 },

  { 231, 83, TARGET_STRING("HSC_Model/ACC Controller/Dash/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 232, 83, TARGET_STRING("HSC_Model/ACC Controller/Dash/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 233, 83, TARGET_STRING("HSC_Model/ACC Controller/Dash/Memory"),
    TARGET_STRING("ACCHdwySTG"), 0, 0, 0, 0, 0 },

  { 234, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Data Type Conversion"),
    TARGET_STRING("EgoSpd"), 0, 0, 0, 0, 1 },

  { 235, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator"),
    TARGET_STRING("TargetPos"), 0, 0, 0, 0, 0 },

  { 236, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator1"),
    TARGET_STRING("EgoPos"), 0, 0, 0, 0, 0 },

  { 237, 83, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 238, 29, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 239, 83, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Switch"),
    TARGET_STRING("TargetRelSpd"), 0, 0, 0, 0, 1 },

  { 240, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Switch1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 241, 33, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Chart2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 242, 33, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Chart2"),
    TARGET_STRING("Distance"), 1, 0, 0, 0, 0 },

  { 243, 33, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Chart2"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 244, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Cast To Double"),
    TARGET_STRING("DistanceValidity"), 0, 0, 0, 0, 1 },

  { 245, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 246, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Gain1"),
    TARGET_STRING("LeadVehicleSpeedmph"), 0, 0, 0, 0, 1 },

  { 247, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/OR"),
    TARGET_STRING("DistanceValidity"), 0, 1, 0, 0, 1 },

  { 248, 30, TARGET_STRING(
    "HSC_Model/ACC Controller/Subsystem/FarDistanceTarget"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 249, 31, TARGET_STRING(
    "HSC_Model/ACC Controller/Subsystem/MediumDistanceTarget"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 250, 32, TARGET_STRING(
    "HSC_Model/ACC Controller/Subsystem/NearDistanceTarget"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 251, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Multiport Switch"),
    TARGET_STRING("SafeDist"), 0, 0, 0, 0, 1 },

  { 252, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Product"),
    TARGET_STRING("ctDist"), 0, 0, 0, 0, 1 },

  { 253, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 254, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Sum1"),
    TARGET_STRING("DistErr"), 0, 0, 0, 0, 1 },

  { 255, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 256, 83, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 257, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 258, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Matrix Concatenate"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 259, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Matrix Concatenate1"),
    TARGET_STRING(""), 0, 0, 1, 0, 0 },

  { 260, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 261, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 262, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 263, 44, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Vehicle Speed Multiplier"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 264, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 265, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Dynamic PSOC Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 266, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 267, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 268, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 269, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Saturation Dynamic/LowerRelop1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 270, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Saturation Dynamic/UpperRelop"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 271, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Saturation Dynamic/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 272, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/Saturation Dynamic/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 273, 45, TARGET_STRING("HSC_Model/Diagnostics/ABSRegenOff/ABSRegenOff"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 274, 83, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/Gain"),
    TARGET_STRING("BPPTrqCancel"), 0, 2, 0, 1, 1 },

  { 275, 83, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/IC"),
    TARGET_STRING("BPPTrqCancel"), 0, 1, 0, 0, 1 },

  { 276, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Brake Torque Cancelation/Logical Operator3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 277, 46, TARGET_STRING(
    "HSC_Model/Diagnostics/Electronics_Cooling/ABSRegenOff"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 278, 47, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/Chart"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 279, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/Data Type Conversion2"),
    TARGET_STRING("FirstTimeFlag"), 0, 1, 0, 0, 1 },

  { 280, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/Data Type Conversion3"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 281, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/kohms to ohms"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 282, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/Logical Operator11"),
    TARGET_STRING("gfd"), 0, 1, 0, 0, 1 },

  { 283, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/Memory7"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 284, 83, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 285, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/closed contactor battery range"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 286, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Motor Control Fault/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 287, 48, TARGET_STRING(
    "HSC_Model/Diagnostics/Over//UnderVoltage/OverVoltage"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 288, 49, TARGET_STRING(
    "HSC_Model/Diagnostics/Over//UnderVoltage/UnderVoltage"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 289, 50, TARGET_STRING("HSC_Model/Diagnostics/OverDischarge/OverDischarge"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 290, 51, TARGET_STRING("HSC_Model/Diagnostics/Overheat/fault Counter1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 291, 52, TARGET_STRING("HSC_Model/Diagnostics/Overheat/fault Counter2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 292, 53, TARGET_STRING("HSC_Model/Diagnostics/Overheat/fault Counter3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 293, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Data Type Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 294, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Data Type Conversion2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 295, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Data Type Conversion3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 296, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Data Type Conversion7"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 297, 83, TARGET_STRING("HSC_Model/Diagnostics/Overheat/Logical Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 298, 54, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Fault counter1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 299, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Data Type Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 300, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 301, 83, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 302, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Logical Operator6"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 303, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Logical Operator7"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 304, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/Logical Operator8"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 305, 83, TARGET_STRING("HSC_Model/Diagnostics/Protect HV/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 306, 55, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/Fault Counter"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 307, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Data Type Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 308, 83, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/IC"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 309, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator"),
    TARGET_STRING("RecieveDrive"), 0, 1, 0, 0, 0 },

  { 310, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 311, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 312, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 313, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator4"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 314, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 315, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator6"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 316, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/Logical Operator7"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 317, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/ZeroPwrTmTrq/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 318, 56, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Fault counter1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 319, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Abs1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 320, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Abs2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 321, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Abs3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 322, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Data Type Conversion4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 323, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/IC"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 324, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/AND"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 325, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Product2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 326, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 327, 83, TARGET_STRING(
    "HSC_Model/Driver_Arbitration/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 328, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/m//s2rad//s"),
    TARGET_STRING("whlspd"), 0, 0, 0, 0, 1 },

  { 329, 59, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/MinMax1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 330, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 331, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 332, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 333, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/prevents dividing by zero"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 334, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 335, 63, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 336, 64, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 337, 64, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart1"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 338, 65, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart2"),
    TARGET_STRING("Multiplier"), 0, 0, 0, 0, 0 },

  { 339, 60, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 340, 70, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 341, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Gain19"),
    TARGET_STRING("VehSpdMPH"), 0, 0, 0, 0, 1 },

  { 342, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/RPM_to_rad//s"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 343, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Diagnostic Faults"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 344, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Logical Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 345, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 346, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/OR"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 347, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T1 (start of compensation)"),
    TARGET_STRING("StartTorqueTime"), 0, 0, 0, 0, 1 },

  { 348, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T2 (time after t1 to full torque)"),
    TARGET_STRING("FullTorqueTime"), 0, 0, 0, 0, 1 },

  { 349, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T3 (time before t4 to lower torque)"),
    TARGET_STRING("LowerTorqueAtTime"), 0, 0, 0, 0, 1 },

  { 350, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T4 (direct time to end compensation)"),
    TARGET_STRING("EndTorqueTime"), 0, 0, 0, 0, 1 },

  { 351, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/TorqueAdditionTable"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 352, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Divide1"),
    TARGET_STRING("Motor_Trq_Req_Raw_Nm"), 0, 0, 0, 0, 1 },

  { 353, 70, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Product"),
    TARGET_STRING("PowerLossBetweenShifts"), 0, 0, 0, 0, 1 },

  { 354, 70, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 355, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Product3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 356, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 357, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/prevents dividing by zero"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 358, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 359, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 360, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Switch1"),
    TARGET_STRING("motor_trq_demand_Nm"), 0, 0, 0, 0, 1 },

  { 361, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Switch3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 362, 62, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Moving Average"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 363, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/AND"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 364, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Switch3"),
    TARGET_STRING("ACC_Correc_Eng"), 0, 0, 0, 0, 1 },

  { 365, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/AND"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 366, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Switch4"),
    TARGET_STRING("ACC_Correc_Mot"), 0, 0, 0, 0, 1 },

  { 367, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Increment Stored Integer/FixPt Gateway In"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 368, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Increment Stored Integer/FixPt Sum1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 369, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 370, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 371, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 372, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant3/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 373, 83, TARGET_STRING(
    "HSC_Model/Regenerative_Braking_Control_Process/SOC Charge Limit/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 374, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/EgoSpd"),
    TARGET_STRING("EgoSpd"), 0, 0, 0, 0, 1 },

  { 375, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/TargetRelPos"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 376, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/DistInfo"),
    TARGET_STRING(""), 0, 0, 2, 0, 1 },

  { 377, 14, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart"),
    TARGET_STRING("MustStop"), 0, 0, 0, 0, 0 },

  { 378, 15, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart2"),
    TARGET_STRING("LastDistance"), 0, 0, 0, 0, 0 },

  { 379, 16, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart3"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 380, 17, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart4"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 381, 17, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart4"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 382, 17, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart4"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 383, 17, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart4"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 384, 18, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart5"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 385, 18, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Chart5"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 386, 19, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/DistanceRC"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 387, 20, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/StopLightRC"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 388, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 389, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant21"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 390, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant22"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 391, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant23"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 392, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Cast To Boolean"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 393, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Cast To Boolean1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 394, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator"),
    TARGET_STRING("EgoPosition"), 0, 0, 0, 0, 2 },

  { 395, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator1"),
    TARGET_STRING("xdotPosition"), 0, 0, 0, 0, 2 },

  { 396, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator3"),
    TARGET_STRING("DistanceKeepTrack"), 0, 0, 0, 0, 0 },

  { 397, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 398, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 399, 13, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 400, 11, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain3"),
    TARGET_STRING("SpdMPH"), 0, 0, 0, 0, 1 },

  { 401, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain7"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 402, 12, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain8"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 403, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Multiply"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 404, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/kph2m//s"),
    TARGET_STRING("SetSpd"), 0, 0, 0, 0, 0 },

  { 405, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 406, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 407, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 408, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND3"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 409, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 410, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 411, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/AND6"),
    TARGET_STRING("BrakeHoldActive"), 0, 1, 0, 0, 1 },

  { 412, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/NOT2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 413, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/OR"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 414, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/OR1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 415, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/OR2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 416, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 417, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 418, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 419, 11, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Far Constant"),
    TARGET_STRING("Accel"), 0, 0, 0, 0, 1 },

  { 420, 12, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Medium Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 421, 13, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Near Constant"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 422, 9, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 423, 10, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 424, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Square"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 425, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Min"),
    TARGET_STRING("TotalACCAccel"), 0, 0, 0, 0, 1 },

  { 426, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Multiport Switch"),
    TARGET_STRING("DistanceControllerAccel"), 0, 0, 0, 0, 1 },

  { 427, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Divide"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 428, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Divide1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 429, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Divide2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 430, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Divide4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 431, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 432, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 433, 8, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 434, 7, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product3"),
    TARGET_STRING("ACCReqPwr"), 0, 0, 0, 0, 1 },

  { 435, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 436, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product5"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 437, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Product6"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 438, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Rate Transition"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 439, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Rate Transition1"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 440, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Rate Transition2"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 441, 6, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 442, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation1"),
    TARGET_STRING("distanceAccel"), 0, 0, 0, 0, 1 },

  { 443, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation2"),
    TARGET_STRING("AccelCmd"), 0, 0, 0, 0, 1 },

  { 444, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation3"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 445, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation4"),
    TARGET_STRING("setSpdAccel"), 0, 0, 0, 0, 1 },

  { 446, 4, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation5"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 447, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 448, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Sum3"),
    TARGET_STRING("SetSpeedError"), 0, 0, 0, 0, 1 },

  { 449, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch"),
    TARGET_STRING("SetSpeedAcccel2"), 0, 0, 0, 0, 1 },

  { 450, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch1"),
    TARGET_STRING("EBCM_Decel"), 0, 0, 0, 0, 1 },

  { 451, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch11"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 452, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch14"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 453, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 454, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch3"),
    TARGET_STRING("ACCReqPwr"), 0, 0, 0, 0, 1 },

  { 455, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch4"),
    TARGET_STRING("StopLightAccel"), 0, 0, 0, 0, 0 },

  { 456, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Switch5"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 457, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 458, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 459, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Unary Minus"),
    TARGET_STRING("DistErrFLipped"), 0, 0, 0, 0, 1 },

  { 460, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative/Diff"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 461, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative/TSamp"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 462, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative/UD"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 0 },

  { 463, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv/Diff"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 464, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv/TSamp"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 465, 83, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv/UD"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 0 },

  { 466, 83, TARGET_STRING(
    "HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/checks for Low Speed Cruise Charge Mode/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 467, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Brake Torque Cancelation/BPPCheck/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 468, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Brake Torque Cancelation/Launch Mode Check/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 469, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Electronics_Cooling/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 470, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Ground Fault Detection/Competition Requirement 500 ohms per volt/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 471, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 472, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 473, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/OverDischarge/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 474, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 475, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Compare To Constant2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 476, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Compare To Constant3/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 477, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Overheat/Compare To Constant6/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 478, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/CheckForDrive/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 479, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/CheckForReverse/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 480, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/ForwardMotionCheck/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 481, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Powertrain direction fault/ReverseMotionCheck/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 482, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/CheckForDrive1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 483, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/CheckForNeutral/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 484, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/CheckForPark1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 485, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/CheckForReverse /Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 486, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/CheckForReverse2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 487, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/FirstGearOrGreater/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 488, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/Shift Validity/NinethGearOrless/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 489, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 490, 83, TARGET_STRING(
    "HSC_Model/Diagnostics/motor_torque direction fault/Compare To Zero/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 491, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 492, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Logical Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 493, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 494, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Check for key in Run/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 495, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for Drive/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 496, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Reverse/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 497, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Unknown/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 498, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 499, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 500, 71, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 501, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Abs1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 502, 66, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/1-D Lookup Creep Trq_Nm"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 503, 67, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 504, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 505, 69, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Chart"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 506, 69, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Chart"),
    TARGET_STRING(""), 1, 0, 0, 0, 0 },

  { 507, 69, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Chart"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 508, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Abs"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 509, 68, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/1-D Lookup Table1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 510, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 511, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 512, 68, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Product2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 513, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 514, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Tanh"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 515, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Delay One Step"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 516, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Saturation Motor Limits/LowerRelop1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 517, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Saturation Motor Limits/UpperRelop"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 518, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Saturation Motor Limits/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 519, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Saturation Motor Limits/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 520, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode/Switch1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 521, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 522, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/OR"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 523, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/allows braking torque if in  either cruise changing modes"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 524, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Reverse/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 525, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Logical Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 526, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Logical Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 527, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Logical Operator2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 528, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Multiport Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 529, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Saturation Dynamic/LowerRelop1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 530, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Saturation Dynamic/UpperRelop"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 531, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Saturation Dynamic/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 532, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Saturation Dynamic/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 533, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Saturation Dynamic1/LowerRelop1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 534, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Saturation Dynamic1/UpperRelop"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 535, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Saturation Dynamic1/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 536, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Saturation Dynamic1/Switch2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 537, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 538, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant1/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 539, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant2/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 540, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant3/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 541, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant4/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 542, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative/Diff"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 543, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative/TSamp"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 544, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative/UD"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 2 },

  { 545, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative1/Diff"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 546, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative1/TSamp"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 547, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative1/UD"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 2 },

  { 548, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Vector Concatenate"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 549, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 3, 0, 1 },

  { 550, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Discrete-Time Integrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 551, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 552, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Relational Operator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 553, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Relational Operator1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 554, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Switch"),
    TARGET_STRING(""), 0, 0, 3, 0, 1 },

  { 555, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Unit Delay"),
    TARGET_STRING(""), 0, 0, 3, 0, 0 },

  { 556, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Drive/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 557, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Reverse/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 558, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for ShftLvrPos Unknown/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 559, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Creep Torque Threshold_Nm/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 560, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode/Check For  Launch Mode/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 561, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if cruise charging mode/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 562, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if low speed Cruise Charging mode/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 563, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if regen mode/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 564, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks negative torque/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 565, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks positive torque/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 566, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks regen switch is on/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 567, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charge SOC Limit/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 568, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charging Motor Torque/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 569, 83, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging Motor Torque/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 570, 61, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging SOC Limit/Compare"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 571, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 3, 0, 1 },

  { 572, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate1"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 573, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate2"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 574, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate3"),
    TARGET_STRING(""), 0, 0, 3, 0, 1 },

  { 575, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate4"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 576, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate5"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 577, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Vector Concatenate6"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 578, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/1//m2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 579, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/b"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 580, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/c"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 581, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/m"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 582, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/m1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 583, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Integrator1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 584, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 585, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Product5"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 586, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Product6"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 587, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Product7"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 588, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Add1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 589, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Add2"),
    TARGET_STRING("Total Force"), 0, 0, 0, 0, 1 },

  { 590, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Trigonometric Function1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 591, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Trigonometric Function1"),
    TARGET_STRING(""), 1, 0, 0, 0, 1 },

  { 592, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Trigonometric Function2"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 593, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Unit Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 594, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/DataTypeConv1"),
    TARGET_STRING(""), 0, 3, 0, 0, 0 },

  { 595, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/DataTypeConv2"),
    TARGET_STRING(""), 0, 3, 0, 0, 0 },

  { 596, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/DeadZone"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 597, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/ZeroGain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 598, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/AND3"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 599, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/Equal1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 600, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/NotEqual"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 601, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/SignPreIntegrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 602, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/SignPreSat"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 603, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/Switch"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 604, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/D Gain/Internal Parameters/Derivative Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 605, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Filter/Differentiator/Diff"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 606, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Filter/Differentiator/UD"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 607, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/I Gain/Internal Parameters/Integral Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 608, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Integrator/Discrete/Integrator"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 609, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Parallel P Gain/Internal Parameters/Proportional Gain"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 610, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Saturation/Enabled/Saturation"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 611, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Sum/Sum_PID/Sum"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 612, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Sum Fdbk/Enabled/Sum Fdbk"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 613, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Transpose"),
    TARGET_STRING(""), 0, 0, 5, 0, 1 },

  { 614, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Product"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 615, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 616, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant10"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 617, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant12"),
    TARGET_STRING("Y"), 0, 0, 0, 0, 0 },

  { 618, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant2"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 619, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Add"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 620, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn11"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 621, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn12"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 622, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn13"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 623, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn21"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 624, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn22"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 625, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn23"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 626, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn31"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 627, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn32"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 628, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn33"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 629, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/sincos"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 630, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/sincos"),
    TARGET_STRING(""), 1, 0, 4, 0, 1 },

  { 631, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Filter/Differentiator/Tsamp/Internal Ts/Tsamp"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 632, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Body Frame/Road Load/Constant11"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 633, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Body Frame/Road Load/Integrator3"),
    TARGET_STRING("x"), 0, 0, 0, 0, 1 },

  { 634, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Body Frame/Road Load/Unit Conversion"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 635, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant14"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 636, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant5"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 637, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant7"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 638, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Transpose"),
    TARGET_STRING(""), 0, 0, 5, 0, 1 },

  { 639, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Product"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 640, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Product"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 641, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Product1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 642, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Product8"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 643, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Product9"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 644, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Unary Minus"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 645, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Unary Minus1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 646, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Power/Road Load/Unit Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 647, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 6, 0, 1 },

  { 648, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix/Reshape (9) to [3x3] column-major"),
    TARGET_STRING(""), 0, 0, 5, 0, 1 },

  { 649, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn11"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 650, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn12"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 651, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn13"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 652, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn21"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 653, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn22"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 654, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn23"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 655, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn31"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 656, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn32"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 657, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Fcn33"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 658, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/sincos"),
    TARGET_STRING(""), 0, 0, 4, 0, 1 },

  { 659, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/sincos"),
    TARGET_STRING(""), 1, 0, 4, 0, 1 },

  { 660, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix/Vector Concatenate"),
    TARGET_STRING(""), 0, 0, 6, 0, 1 },

  { 661, 21, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Rotation Angles to Direction Cosine Matrix/Create 3x3 Matrix/Reshape (9) to [3x3] column-major"),
    TARGET_STRING(""), 0, 0, 5, 0, 1 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 662, TARGET_STRING("HSC_Model/ACC Controller/Compare To Constant1"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 663, TARGET_STRING("HSC_Model/ACC Controller/Compare To Constant2"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 664, TARGET_STRING("HSC_Model/ACC Controller/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 665, TARGET_STRING("HSC_Model/ACC Controller/Change"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 666, TARGET_STRING("HSC_Model/ACC Controller/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 667, TARGET_STRING("HSC_Model/ACC Controller/Denied"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 668, TARGET_STRING("HSC_Model/ACC Controller/SetSpdMPS"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 669, TARGET_STRING("HSC_Model/ACC Controller/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 670, TARGET_STRING("HSC_Model/ACC Controller/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 671, TARGET_STRING("HSC_Model/ACC Controller/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 672, TARGET_STRING("HSC_Model/ACC Controller/Gain5"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 673, TARGET_STRING("HSC_Model/ACC Controller/km//h2m//s1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 674, TARGET_STRING("HSC_Model/ACC Controller/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 675, TARGET_STRING("HSC_Model/ACC Controller/Switch2"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 676, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 677, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 678, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 679, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Target SOC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 680, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 681, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/kph to mph"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 682, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 683, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 684, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 685, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 686, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC4"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 687, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 688, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 689, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 690, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/IC8"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 691, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 692, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 8, 0 },

  { 693, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 694, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 695, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 8, 0 },

  { 696, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("BreakpointsForDimension3"), 0, 9, 0 },

  { 697, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("maxIndex"), 5, 4, 0 },

  { 698, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table2"),
    TARGET_STRING("dimSizes"), 5, 4, 0 },

  { 699, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 700, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 8, 0 },

  { 701, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("BreakpointsForDimension3"), 0, 9, 0 },

  { 702, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("maxIndex"), 5, 4, 0 },

  { 703, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/2-D Lookup Table5"),
    TARGET_STRING("dimSizes"), 5, 4, 0 },

  { 704, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousDischageLimit"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 7, 0 },

  { 705, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousDischageLimit"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 8, 0 },

  { 706, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousDischageLimit"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 707, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 708, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 709, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit1"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 710, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 711, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit2"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 712, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 713, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit3"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 714, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/ContinuousMotorPowerLimit3"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 715, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 716, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 717, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit1"),
    TARGET_STRING("Table"), 0, 10, 0 },

  { 718, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/DiscreteMotorPowerLimit1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 10, 0 },

  { 719, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 720, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Memory1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 721, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 722, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 723, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/Switch3"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 724, TARGET_STRING("HSC_Model/Diagnostics/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 725, TARGET_STRING("HSC_Model/Diagnostics/Constant3"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 726, TARGET_STRING("HSC_Model/Diagnostics/kph to mps"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 727, TARGET_STRING("HSC_Model/Diagnostics/Memory1"),
    TARGET_STRING("InitialCondition"), 2, 0, 1 },

  { 728, TARGET_STRING("HSC_Model/Diagnostics/Memory2"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 729, TARGET_STRING("HSC_Model/Driver_Arbitration/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 730, TARGET_STRING("HSC_Model/Driver_Arbitration/kph to mps"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 731, TARGET_STRING("HSC_Model/Driver_Arbitration/Mass 2550"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 11, 0 },

  { 732, TARGET_STRING("HSC_Model/Driver_Arbitration/Mass 2550"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 733, TARGET_STRING("HSC_Model/Driver_Arbitration/Mass 2550"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 734, TARGET_STRING("HSC_Model/Driver_Arbitration/Saturation2"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 735, TARGET_STRING("HSC_Model/Driver_Arbitration/Saturation2"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 736, TARGET_STRING("HSC_Model/Driver_Arbitration/prevents zeroing Pwr Dmd at 0 kph"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 737, TARGET_STRING("HSC_Model/Driver_Arbitration/prevents zeroing Pwr Dmd at 0 kph"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 738, TARGET_STRING("HSC_Model/Driver_Arbitration/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 739, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 740, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Motor Enable"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 741, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/FinalDrive"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 742, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 743, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Gain4"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 744, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/kph to mph"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 745, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/kph to mps"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 746, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/kph to mps1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 747, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/1-D Lookup Table1"),
    TARGET_STRING("Table"), 0, 13, 0 },

  { 748, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 749, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 750, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 751, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 752, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 753, TARGET_STRING("HSC_Model/Input_Wrapper/Activate MIL//HIL Version"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 754, TARGET_STRING("HSC_Model/Output_Wrapper/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 755, TARGET_STRING("HSC_Model/Output_Wrapper/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 756, TARGET_STRING("HSC_Model/Output_Wrapper/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 757, TARGET_STRING("HSC_Model/Output_Wrapper/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 758, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 759, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant1"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 760, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 761, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant3"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 762, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/SOC Charge Limit"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 763, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 764, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Max BPP Regen W"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 765, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Off Throttle Regen Power Demand W"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 766, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Vehicle Mass"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 767, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 768, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/kph to mph"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 769, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/rbcp_regen_enable"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 770, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table"),
    TARGET_STRING("Table"), 0, 14, 0 },

  { 771, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 14, 0 },

  { 772, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table1"),
    TARGET_STRING("Table"), 0, 14, 0 },

  { 773, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 14, 0 },

  { 774, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table2"),
    TARGET_STRING("Table"), 0, 9, 0 },

  { 775, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/1-D Lookup Table2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 9, 0 },

  { 776, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Steering Wheel Angle Fade Out"),
    TARGET_STRING("Table"), 0, 15, 0 },

  { 777, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Steering Wheel Angle Fade Out"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 15, 0 },

  { 778, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Vehicle Speed Fade Out"),
    TARGET_STRING("Table"), 0, 14, 0 },

  { 779, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Vehicle Speed Fade Out"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 14, 0 },

  { 780, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 781, TARGET_STRING("HSC_Model/Regenerative_Braking_Control_Process/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 782, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/Brusa Enable"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 783, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMUmajorProt"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 784, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/VMUminorProt"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 785, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/kph to mph"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 786, TARGET_STRING("HSC_Model/Vehicle_Mode_Control_Process/Memory1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 787, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 788, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 789, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 790, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant4"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 791, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 792, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant6"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 793, TARGET_STRING("HSC_Model/ACC Controller/Dash/Constant7"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 794, TARGET_STRING("HSC_Model/ACC Controller/Dash/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 795, TARGET_STRING("HSC_Model/ACC Controller/Dash/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 796, TARGET_STRING("HSC_Model/ACC Controller/Dash/Memory"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 797, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 798, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 799, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/TargetInitialPos"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 800, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 801, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 802, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator1"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 803, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 804, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 805, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Switch1"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 806, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 807, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 808, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/FarDistanceTarget"),
    TARGET_STRING("Table"), 0, 16, 0 },

  { 809, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/FarDistanceTarget"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 12, 0 },

  { 810, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/MediumDistanceTarget"),
    TARGET_STRING("Table"), 0, 12, 0 },

  { 811, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/MediumDistanceTarget"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 12, 0 },

  { 812, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/NearDistanceTarget"),
    TARGET_STRING("Table"), 0, 16, 0 },

  { 813, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/NearDistanceTarget"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 12, 0 },

  { 814, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 815, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 816, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/checks for Low Speed Cruise Charge Mode"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 817, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 818, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 819, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 820, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 821, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant4"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 822, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 823, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/psoc_table_SOC_offset"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 824, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Vehicle Speed Multiplier"),
    TARGET_STRING("Table"), 0, 17, 0 },

  { 825, TARGET_STRING("HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/Vehicle Speed Multiplier"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 17, 0 },

  { 826, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/BPPCheck"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 827, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/Launch Mode Check"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 828, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/Gain"),
    TARGET_STRING("Gain"), 2, 0, 1 },

  { 829, TARGET_STRING("HSC_Model/Diagnostics/Brake Torque Cancelation/IC"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 830, TARGET_STRING("HSC_Model/Diagnostics/Electronics_Cooling/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 831, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/Competition Requirement 500 ohms per volt"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 832, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/kohms to ohms"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 833, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/Memory7"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 834, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/closed contactor battery range"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 835, TARGET_STRING("HSC_Model/Diagnostics/Ground Fault Detection/closed contactor battery range"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 836, TARGET_STRING("HSC_Model/Diagnostics/Motor Control Fault/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 837, TARGET_STRING("HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 838, TARGET_STRING("HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 839, TARGET_STRING("HSC_Model/Diagnostics/OverDischarge/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 840, TARGET_STRING("HSC_Model/Diagnostics/Overheat/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 841, TARGET_STRING("HSC_Model/Diagnostics/Overheat/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 842, TARGET_STRING("HSC_Model/Diagnostics/Overheat/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 843, TARGET_STRING("HSC_Model/Diagnostics/Overheat/Compare To Constant6"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 844, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/CheckForDrive"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 845, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/CheckForReverse"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 846, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/ForwardMotionCheck"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 847, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/ReverseMotionCheck"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 848, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 849, TARGET_STRING("HSC_Model/Diagnostics/Powertrain direction fault/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 850, TARGET_STRING("HSC_Model/Diagnostics/Protect HV/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 851, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/CheckForDrive1"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 852, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/CheckForNeutral"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 853, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/CheckForPark1"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 854, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/CheckForReverse "),
    TARGET_STRING("const"), 0, 0, 0 },

  { 855, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/CheckForReverse2"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 856, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/FirstGearOrGreater"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 857, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/NinethGearOrless"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 858, TARGET_STRING("HSC_Model/Diagnostics/Shift Validity/IC"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 859, TARGET_STRING("HSC_Model/Diagnostics/motor_torque direction fault/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 860, TARGET_STRING("HSC_Model/Diagnostics/motor_torque direction fault/IC"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 861, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Compare To Constant"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 862, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 863, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 864, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/prevents dividing by zero"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 865, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/prevents dividing by zero"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 866, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Check for key in Run"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 867, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for Drive"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 868, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Reverse"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 869, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Unknown"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 870, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 871, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 872, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 873, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Reverse"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 874, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 875, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 876, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Gain19"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 877, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/RPM_to_rad//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 878, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T1 (start of compensation)"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 18, 0 },

  { 879, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T1 (start of compensation)"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 19, 0 },

  { 880, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T1 (start of compensation)"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 881, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T2 (time after t1 to full torque)"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 18, 0 },

  { 882, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T2 (time after t1 to full torque)"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 19, 0 },

  { 883, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T2 (time after t1 to full torque)"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 884, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T3 (time before t4 to lower torque)"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 18, 0 },

  { 885, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T3 (time before t4 to lower torque)"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 19, 0 },

  { 886, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T3 (time before t4 to lower torque)"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 887, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T4 (direct time to end compensation)"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 18, 0 },

  { 888, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T4 (direct time to end compensation)"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 19, 0 },

  { 889, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/T4 (direct time to end compensation)"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 890, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/TorqueAdditionTable"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 18, 0 },

  { 891, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/TorqueAdditionTable"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 19, 0 },

  { 892, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/TorqueAdditionTable"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 893, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 894, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 895, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/prevents dividing by zero"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 896, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/prevents dividing by zero"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 897, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 898, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Increment Stored Integer/FixPt Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 899, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 900, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant1"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 901, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant2"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 902, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant3"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 903, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Compare To Constant4"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 904, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 905, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative1"),
    TARGET_STRING("ICPrevScaledInput"), 0, 0, 0 },

  { 906, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("P"), 0, 0, 0 },

  { 907, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("I"), 0, 0, 0 },

  { 908, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("D"), 0, 0, 0 },

  { 909, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("InitialConditionForIntegrator"), 0, 0, 0 },

  { 910, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("DifferentiatorICPrevScaledInput"), 0, 0, 0 },

  { 911, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 912, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1"),
    TARGET_STRING("LowerSaturationLimit"), 0, 0, 0 },

  { 913, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("m"), 0, 0, 0 },

  { 914, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("a"), 0, 0, 0 },

  { 915, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("b"), 0, 0, 0 },

  { 916, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("c"), 0, 0, 0 },

  { 917, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("g"), 0, 0, 0 },

  { 918, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("x_o"), 0, 0, 0 },

  { 919, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load"),
    TARGET_STRING("xdot_o"), 0, 0, 0 },

  { 920, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 921, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 922, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 923, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 924, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 925, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant21"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 926, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant22"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 927, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant23"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 928, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant24"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 929, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant25"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 930, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant26"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 931, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant3"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 932, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant4"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 933, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 934, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Constant6"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 935, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/a"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 936, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/b"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 937, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/c"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 938, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/deceleration"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 939, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 940, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 941, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator1"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 942, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 943, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator3"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 944, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time Integrator3"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 945, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 946, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain1"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 947, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 948, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain3"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 949, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain7"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 950, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Gain8"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 951, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/kph2m//s"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 952, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 20, 0 },

  { 953, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 954, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 955, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 12, 0 },

  { 956, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table1"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 957, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table1"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 958, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table4"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 21, 0 },

  { 959, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table4"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 22, 0 },

  { 960, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/2-D Lookup Table4"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 961, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Far Constant"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 23, 0 },

  { 962, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Far Constant"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 963, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Far Constant"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 964, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Medium Constant"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 23, 0 },

  { 965, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Medium Constant"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 966, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Medium Constant"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 967, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Near Constant"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 23, 0 },

  { 968, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Near Constant"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 12, 0 },

  { 969, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Near Constant"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 970, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 24, 0 },

  { 971, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V1"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 24, 0 },

  { 972, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V1"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 973, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V2"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 24, 0 },

  { 974, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V2"),
    TARGET_STRING("BreakpointsForDimension2"), 0, 24, 0 },

  { 975, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Set Speed V2"),
    TARGET_STRING("maxIndex"), 5, 3, 0 },

  { 976, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 977, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 978, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation1"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 979, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation1"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 980, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation2"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 981, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation2"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 982, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation3"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 983, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation3"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 984, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation4"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 985, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation4"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 986, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation5"),
    TARGET_STRING("UpperLimit"), 0, 0, 0 },

  { 987, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Saturation5"),
    TARGET_STRING("LowerLimit"), 0, 0, 0 },

  { 988, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 989, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 990, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 991, TARGET_STRING("HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv/TSamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 992, TARGET_STRING("HSC_Model/Diagnostics/motor_torque direction fault/Compare To Zero/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 993, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Drive"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 994, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Reverse"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 995, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for ShftLvrPos Unknown"),
    TARGET_STRING("const"), 4, 0, 0 },

  { 996, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Creep Torque Threshold_Nm"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 997, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 998, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/1-D Lookup Creep Trq_Nm"),
    TARGET_STRING("Table"), 0, 3, 0 },

  { 999, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/1-D Lookup Creep Trq_Nm"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 9, 0 },

  { 1000, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/1-D Lookup Table1"),
    TARGET_STRING("BreakpointsForDimension1"), 0, 25, 0 },

  { 1001, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  { 1002, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Delay One Step"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1003, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode/Check For  Launch Mode"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1004, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode/Load Torque Nm"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1005, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if cruise charging mode"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1006, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if low speed Cruise Charging mode"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1007, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if regen mode"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1008, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charge SOC Limit"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1009, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging SOC Limit"),
    TARGET_STRING("const"), 0, 0, 0 },

  { 1010, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/SOC Okay"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1011, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Discrete-Time Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 1012, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Discrete-Time Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1013, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Unit Delay"),
    TARGET_STRING("InitialCondition"), 0, 9, 0 },

  { 1014, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks negative torque/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1015, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks positive torque/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1016, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks regen switch is on/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1017, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charging Motor Torque/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1018, TARGET_STRING("HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging Motor Torque/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1019, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/1//m2"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 1020, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1021, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Anti-windup/Disc. Clamping Parallel/ZeroGain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 1022, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Integrator/Discrete/Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 1023, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Inertial Axes/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1024, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant1"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1025, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant10"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1026, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant12"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1027, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Constant2"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1028, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Filter/Differentiator/Tsamp/Internal Ts/Tsamp"),
    TARGET_STRING("WtEt"), 0, 0, 0 },

  { 1029, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Body Frame/Road Load/Constant11"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1030, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant14"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1031, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant5"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1032, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Forces/Forces Road Load/Constant7"),
    TARGET_STRING("Value"), 0, 0, 0 },

  { 1033, TARGET_STRING("HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Inertial Frame/Inertial Axes/Constant"),
    TARGET_STRING("Value"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 1034, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time\nIntegrator"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1035, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete-Time\nIntegrator1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1036, -1, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1037, -1, TARGET_STRING("HSC_Model/ACC Controller/Subsystem/Delay One Step1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1038, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time\nIntegrator"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 2, 0, -1, 0 },

  { 1039, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time\nIntegrator1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 2, 0, -1, 0 },

  { 1040, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete-Time\nIntegrator3"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1041, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1042, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Delay One Step1"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1043, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative/UD"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1044, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv/UD"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1045, -1, TARGET_STRING(
    "HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Delay One Step"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1046, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative/UD"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 2, 0, -1, 0 },

  { 1047, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Discrete Derivative1/UD"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 2, 0, -1, 0 },

  { 1048, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Discrete-Time\nIntegrator"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1049, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Error Metrics/Unit Delay"),
    TARGET_STRING("DSTATE"), "", 0, 0, 3, 0, 0, 0, -1, 0 },

  { 1050, 1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Integrator1"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 1, 1, -1, 0 },

  { 1051, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Filter/Differentiator/UD"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1052, -1, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/PID Controller1/Integrator/Discrete/Integrator"),
    TARGET_STRING("DSTATE"), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 1053, 0, TARGET_STRING(
    "HSC_Model/ACC Controller/ACC Classical/ACC Lookup/Vehicle Body Total Road Load/Vehicle Body Total Road Load Kinematic Input/Bus Creation/Body Frame/Road Load/Integrator3"),
    TARGET_STRING(""),
    TARGET_STRING(""),
    0, 0, 0, 0, 1, 1, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 1054, TARGET_STRING("ACC_Distance_Lookup"), 0, 26, 0 },

  { 1055, TARGET_STRING("ACC_Distance_Lookup_Constant_Method"), 0, 27, 0 },

  { 1056, TARGET_STRING("ACC_Distance_Lookup_Far_Constant_Method"), 0, 27, 0 },

  { 1057, TARGET_STRING("ACC_Distance_Lookup_Near_Constant_Method"), 0, 27, 0 },

  { 1058, TARGET_STRING("ACC_Setspeed_Lookup"), 0, 28, 0 },

  { 1059, TARGET_STRING("ACC_Setspeed_Lookup_V2"), 0, 28, 0 },

  { 1060, TARGET_STRING("Breakpoint1MotorCompensation"), 0, 29, 0 },

  { 1061, TARGET_STRING("Breakpoint2MotorCompensation"), 0, 29, 0 },

  { 1062, TARGET_STRING("Breakpoint3MotorCompensation"), 0, 29, 0 },

  { 1063, TARGET_STRING("Breakpoint4MotorCompensation"), 0, 29, 0 },

  { 1064, TARGET_STRING("ContinuousBatteryCharge"), 0, 30, 0 },

  { 1065, TARGET_STRING("ContinuousBatteryDischarge"), 0, 30, 0 },

  { 1066, TARGET_STRING("InterpBatteryCharge"), 0, 31, 0 },

  { 1067, TARGET_STRING("InterpBatteryDischarge"), 0, 31, 0 },

  { 1068, TARGET_STRING("Mass2550TorqueMap"), 0, 32, 0 },

  { 1069, TARGET_STRING("MotorCompensationAxlTorque"), 0, 29, 0 },

  { 1070, TARGET_STRING("N"), 0, 7, 0 },

  { 1071, TARGET_STRING("Re"), 0, 0, 0 },

  { 1072, TARGET_STRING("Reverse_APP"), 0, 33, 0 },

  { 1073, TARGET_STRING("Stoplight_distance_speed_only"), 0, 34, 0 },

  { 1074, TARGET_STRING("bppRegenLookup"), 0, 35, 0 },

  { 1075, TARGET_STRING("bppRegenMap"), 0, 35, 0 },

  { 1076, TARGET_STRING("f_tbrake_n_bpt"), 0, 36, 0 },

  { 1077, TARGET_STRING("motor_speed_bkp_rpm"), 0, 37, 0 },

  { 1078, TARGET_STRING("peak_trq_curve"), 0, 37, 0 },

  { 1079, TARGET_STRING("tandivide"), 0, 25, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void HSC_Model_InitializeDataAddr(void* dataAddr[], B_HSC_Model_c_T
  *localB, DW_HSC_Model_f_T *localDW, X_HSC_Model_n_T *localX)
{
  dataAddr[0] = (void*) (&localB->CAVACCRequest);
  dataAddr[1] = (void*) (&localB->AutoMdSpdLmtStat);
  dataAddr[2] = (void*) (&localB->ACCAct370);
  dataAddr[3] = (void*) (&localB->AdapCrsCntVDA);
  dataAddr[4] = (void*) (&localB->ACCDrvrSeltdSpd_i);
  dataAddr[5] = (void*) (&localB->HoldCancelDecel);
  dataAddr[6] = (void*) (&localB->ACCSetSpd);
  dataAddr[7] = (void*) (&localB->CAVACCReq);
  dataAddr[8] = (void*) (&localB->CAVPCM_ACCAct);
  dataAddr[9] = (void*) (&localB->Gain_b);
  dataAddr[10] = (void*) (&localB->VehSpdms);
  dataAddr[11] = (void*) (&localB->OR);
  dataAddr[12] = (void*) (&localB->OR1);
  dataAddr[13] = (void*) (&localB->Switch_ja);
  dataAddr[14] = (void*) (&localB->CAVPCM_ACCMdActive);
  dataAddr[15] = (void*) (&localB->Switch2);
  dataAddr[16] = (void*) (&localB->sf_Chart_g.timer);
  dataAddr[17] = (void*) (&localB->timer_g);
  dataAddr[18] = (void*) (&localB->sf_Chart2_m.timer);
  dataAddr[19] = (void*) (&localB->timer);
  dataAddr[20] = (void*) (&localB->SOC_Multiplier);
  dataAddr[21] = (void*) (&localB->ChargeLimit_l);
  dataAddr[22] = (void*) (&localB->kphtomph_f);
  dataAddr[23] = (void*) (&localB->IC_m);
  dataAddr[24] = (void*) (&localB->IC1);
  dataAddr[25] = (void*) (&localB->IC2);
  dataAddr[26] = (void*) (&localB->IC3);
  dataAddr[27] = (void*) (&localB->IC4);
  dataAddr[28] = (void*) (&localB->IC5);
  dataAddr[29] = (void*) (&localB->IC6);
  dataAddr[30] = (void*) (&localB->IC7);
  dataAddr[31] = (void*) (&localB->IC8);
  dataAddr[32] = (void*) (&localB->ContinuousCurrentLimit);
  dataAddr[33] = (void*) (&localB->CurrentLimit_n);
  dataAddr[34] = (void*) (&localB->CurrentLimit);
  dataAddr[35] = (void*) (&localB->ContinuousDischageLimit);
  dataAddr[36] = (void*) (&localB->ContinuousMotorPowerLimit);
  dataAddr[37] = (void*) (&localB->ContinuousMotorPowerLimit1);
  dataAddr[38] = (void*) (&localB->ContinuousMotorPowerLimit2);
  dataAddr[39] = (void*) (&localB->ContinuousMotorPowerLimit3);
  dataAddr[40] = (void*) (&localB->DiscreteMotorPowerLimit);
  dataAddr[41] = (void*) (&localB->DiscreteMotorPowerLimit1);
  dataAddr[42] = (void*) (&localB->Memory);
  dataAddr[43] = (void*) (&localB->Memory1_n);
  dataAddr[44] = (void*) (&localB->ChargeLimit);
  dataAddr[45] = (void*) (&localB->DischargeLimit);
  dataAddr[46] = (void*) (&localB->CurrentDemanded);
  dataAddr[47] = (void*) (&localB->CurrentDemanded_k);
  dataAddr[48] = (void*) (&localB->Battery_Pwr_Limit_Charge_o);
  dataAddr[49] = (void*) (&localB->Battery_Pwr_Limit_Charge);
  dataAddr[50] = (void*) (&localB->Product6);
  dataAddr[51] = (void*) (&localB->Product7);
  dataAddr[52] = (void*) (&localB->Switch_l1);
  dataAddr[53] = (void*) (&localB->Switch1_m);
  dataAddr[54] = (void*) (&localB->Switch2_g);
  dataAddr[55] = (void*) (&localB->Switch3);
  dataAddr[56] = (void*) (&localB->Constant3);
  dataAddr[57] = (void*) (&localB->powerdirectionfault);
  dataAddr[58] = (void*) (&localB->VehSpd_ms);
  dataAddr[59] = (void*) (&localB->Memory1_m);
  dataAddr[60] = (void*) (&localB->Memory2);
  dataAddr[61] = (void*) (&localB->kphtomps);
  dataAddr[62] = (void*) (&localB->mpstorads);
  dataAddr[63] = (void*) (&localB->NOT);
  dataAddr[64] = (void*) (&localB->TotDrvrDmdTrq);
  dataAddr[65] = (void*) (&localB->map);
  dataAddr[66] = (void*) (&localB->Product_a);
  dataAddr[67] = (void*) (&localB->TotDrvrDmdTrq_g);
  dataAddr[68] = (void*) (&localB->preventszeroingPwrDmdat0kph);
  dataAddr[69] = (void*) (&localB->total);
  dataAddr[70] = (void*) (&localB->Switch_jp);
  dataAddr[71] = (void*) (&localB->emcp_p_eng_des_W);
  dataAddr[72] = (void*) (&localB->emcp_ptot_W);
  dataAddr[73] = (void*) (&localB->emcp_p_elec_des_W);
  dataAddr[74] = (void*) (&localB->emcp_mode);
  dataAddr[75] = (void*) (&localB->Abs);
  dataAddr[76] = (void*) (&localB->Abs1_a);
  dataAddr[77] = (void*) (&localB->FinalDrive);
  dataAddr[78] = (void*) (&localB->Gain_m);
  dataAddr[79] = (void*) (&localB->Gain1_i);
  dataAddr[80] = (void*) (&localB->Gain2);
  dataAddr[81] = (void*) (&localB->Gain4);
  dataAddr[82] = (void*) (&localB->kphtomph_c);
  dataAddr[83] = (void*) (&localB->kphtomps_m);
  dataAddr[84] = (void*) (&localB->kphtomps1);
  dataAddr[85] = (void*) (&localB->uDLookupTable);
  dataAddr[86] = (void*) (&localB->uDLookupTable1_p);
  dataAddr[87] = (void*) (&localB->Product_d);
  dataAddr[88] = (void*) (&localB->Product1_m);
  dataAddr[89] = (void*) (&localB->Engine_Axle_Torque);
  dataAddr[90] = (void*) (&localB->Saturation_h);
  dataAddr[91] = (void*) (&localB->Saturation1);
  dataAddr[92] = (void*) (&localB->totaloutputpower);
  dataAddr[93] = (void*) (&localB->eng_mot);
  dataAddr[94] = (void*) (&localB->diff_f);
  dataAddr[95] = (void*) (&localB->diff);
  dataAddr[96] = (void*) (&localB->diff_d);
  dataAddr[97] = (void*) (&localB->Switch_i);
  dataAddr[98] = (void*) (&localB->DirectLookupTablenD);
  dataAddr[99] = (void*) (&localB->dist_is_valid);
  dataAddr[100] = (void*) (&localB->CastToBoolean1);
  dataAddr[101] = (void*) (&localB->xdotref);
  dataAddr[102] = (void*) (&localB->ACCBrakeTime);
  dataAddr[103] = (void*) (&localB->TrafficLightPresent);
  dataAddr[104] = (void*) (&localB->CAVtrgVel);
  dataAddr[105] = (void*) (&localB->CAVtrgDist);
  dataAddr[106] = (void*) (&localB->grade);
  dataAddr[107] = (void*) (&localB->CastToBoolean16);
  dataAddr[108] = (void*) (&localB->CastToBoolean2);
  dataAddr[109] = (void*) (&localB->CastToBoolean22);
  dataAddr[110] = (void*) (&localB->APP);
  dataAddr[111] = (void*) (&localB->CastToBoolean24);
  dataAddr[112] = (void*) (&localB->CastToBoolean25);
  dataAddr[113] = (void*) (&localB->CastToBoolean26);
  dataAddr[114] = (void*) (&localB->CastToBoolean27);
  dataAddr[115] = (void*) (&localB->gear);
  dataAddr[116] = (void*) (&localB->CastToBoolean29);
  dataAddr[117] = (void*) (&localB->CastToBoolean3);
  dataAddr[118] = (void*) (&localB->CastToBoolean30);
  dataAddr[119] = (void*) (&localB->CastToBoolean31);
  dataAddr[120] = (void*) (&localB->CastToBoolean32);
  dataAddr[121] = (void*) (&localB->CastToBoolean33);
  dataAddr[122] = (void*) (&localB->CastToBoolean34);
  dataAddr[123] = (void*) (&localB->CastToBoolean35);
  dataAddr[124] = (void*) (&localB->CastToBoolean36);
  dataAddr[125] = (void*) (&localB->CastToBoolean37);
  dataAddr[126] = (void*) (&localB->CastToBoolean38);
  dataAddr[127] = (void*) (&localB->lvrpos);
  dataAddr[128] = (void*) (&localB->CastToBoolean4);
  dataAddr[129] = (void*) (&localB->CastToBoolean40);
  dataAddr[130] = (void*) (&localB->CastToBoolean41);
  dataAddr[131] = (void*) (&localB->CastToBoolean42);
  dataAddr[132] = (void*) (&localB->CastToBoolean43);
  dataAddr[133] = (void*) (&localB->CastToBoolean44);
  dataAddr[134] = (void*) (&localB->CastToBoolean45);
  dataAddr[135] = (void*) (&localB->CastToBoolean46);
  dataAddr[136] = (void*) (&localB->CastToBoolean47);
  dataAddr[137] = (void*) (&localB->CastToBoolean48);
  dataAddr[138] = (void*) (&localB->CastToBoolean49);
  dataAddr[139] = (void*) (&localB->CastToBoolean5);
  dataAddr[140] = (void*) (&localB->CastToBoolean50);
  dataAddr[141] = (void*) (&localB->CastToBoolean51);
  dataAddr[142] = (void*) (&localB->CastToBoolean6);
  dataAddr[143] = (void*) (&localB->DrvIntndAxlTrqMax);
  dataAddr[144] = (void*) (&localB->DrvIntndAxlTrqMin);
  dataAddr[145] = (void*) (&localB->TrqReqStat);
  dataAddr[146] = (void*) (&localB->Tanh_Exponent);
  dataAddr[147] = (void*) (&localB->Tanh_multiplier);
  dataAddr[148] = (void*) (&localB->CurrentState);
  dataAddr[149] = (void*) (&localB->DistanceToIntersection);
  dataAddr[150] = (void*) (&localB->TimeToIntersection);
  dataAddr[151] = (void*) (&localB->Decel_Division_Value);
  dataAddr[152] = (void*) (&localB->bcm_coolan_temp_C);
  dataAddr[153] = (void*) (&localB->PowerOut);
  dataAddr[154] = (void*) (&localB->DataTypeConversion_g);
  dataAddr[155] = (void*) (&localB->Gain_g);
  dataAddr[156] = (void*) (&localB->kphtomph_o);
  dataAddr[157] = (void*) (&localB->rbcp_regen_enable);
  dataAddr[158] = (void*) (&localB->LogicalOperator_l);
  dataAddr[159] = (void*) (&localB->uDLookupTable_g);
  dataAddr[160] = (void*) (&localB->uDLookupTable1);
  dataAddr[161] = (void*) (&localB->uDLookupTable2);
  dataAddr[162] = (void*) (&localB->BPPFadeOut);
  dataAddr[163] = (void*) (&localB->SteeringWheelAngleFadeOut);
  dataAddr[164] = (void*) (&localB->rbcp_brake_motor_fade_out);
  dataAddr[165] = (void*) (&localB->rbcp_brake_power_demand_W);
  dataAddr[166] = (void*) (&localB->MultiportSwitch1);
  dataAddr[167] = (void*) (&localB->Product_fl);
  dataAddr[168] = (void*) (&localB->RegenPowerW);
  dataAddr[169] = (void*) (&localB->Product2_a);
  dataAddr[170] = (void*) (&localB->Product3);
  dataAddr[171] = (void*) (&localB->Saturation1_g);
  dataAddr[172] = (void*) (&localB->Add_k);
  dataAddr[173] = (void*) (&localB->Add1);
  dataAddr[174] = (void*) (&localB->Switch_n);
  dataAddr[175] = (void*) (&localB->Switch1_d);
  dataAddr[176] = (void*) (&localB->hsc_bms_enable);
  dataAddr[177] = (void*) (&localB->hsc_bms_leakage_ena);
  dataAddr[178] = (void*) (&localB->hsc_bms_mainc_close);
  dataAddr[179] = (void*) (&localB->hsc_brusa_enable);
  dataAddr[180] = (void*) (&localB->Eng_Start);
  dataAddr[181] = (void*) (&localB->hsc_mpdm_R1_bmsIgn);
  dataAddr[182] = (void*) (&localB->hsc_mpdm_R2_mcuIgn);
  dataAddr[183] = (void*) (&localB->VMU_Cmd1_OpReq);
  dataAddr[184] = (void*) (&localB->VMU_Cmd2_OpMdCmd);
  dataAddr[185] = (void*) (&localB->vmcp_StartupSt);
  dataAddr[186] = (void*) (&localB->vmcp_operating_mode);
  dataAddr[187] = (void*) (&localB->hsc_mpdm_R8_bmsPwr);
  dataAddr[188] = (void*) (&localB->hsc_mpdm_HVpump);
  dataAddr[189] = (void*) (&localB->VMU_Kickout);
  dataAddr[190] = (void*) (&localB->VMU_Cmd2_CommandMd);
  dataAddr[191] = (void*) (&localB->kphtomph);
  dataAddr[192] = (void*) (&localB->Memory1);
  dataAddr[193] = (void*) (&localB->Switch);
  dataAddr[194] = (void*) (&localB->ACCLookup.Switch5);
  dataAddr[195] = (void*) (&localB->ACCLookup.Divide1);
  dataAddr[196] = (void*) (&localB->ACCLookup.distanceAccel);
  dataAddr[197] = (void*) (&localB->ACCLookup.DistErrFLipped);
  dataAddr[198] = (void*) (&localB->ACCLookup.TargetRelPos);
  dataAddr[199] = (void*) (( &localB->ACCLookup.DistInfo[0] + 1));
  dataAddr[200] = (void*) (&localB->ACCLookup.EBCM_Decel);
  dataAddr[201] = (void*) (&localB->ACCLookup.ACCReqPwr);
  dataAddr[202] = (void*) (&localB->ACCLookup.Constant21);
  dataAddr[203] = (void*) (&localB->ACCLookup.Constant23);
  dataAddr[204] = (void*) (&localB->ACCLookup.Constant22);
  dataAddr[205] = (void*) (&localB->ACCLookup.Constant2);
  dataAddr[206] = (void*) (&localB->ACCLookup.setSpdAccel);
  dataAddr[207] = (void*) (&localB->ACCLookup.TotalACCAccel);
  dataAddr[208] = (void*) (&localB->ACCLookup.TotalForce);
  dataAddr[209] = (void*) (&localB->ACCLookup.SetSpeedError);
  dataAddr[210] = (void*) (&localB->ACCLookup.SetSpd);
  dataAddr[211] = (void*) (&localB->ACCLookup.CastToBoolean1);
  dataAddr[212] = (void*) (&localB->ACCLookup.LastDistance);
  dataAddr[213] = (void*) (&localB->ACCLookup.StopLightAccel);
  dataAddr[214] = (void*) (( &localB->ACCLookup.DistInfo[0] + 1));
  dataAddr[215] = (void*) (&localB->ACCLookup.Product5_i);
  dataAddr[216] = (void*) (&localB->ACCLookup.Product6_m);
  dataAddr[217] = (void*) (&localB->ACCLookup.AND5);
  dataAddr[218] = (void*) (&localB->ACCLookup.sf_StopLightRC.StoplightValidity);
  dataAddr[219] = (void*) (&localB->ACCLookup.sf_DistanceRC.StoplightValidity);
  dataAddr[220] = (void*) (&localB->ACCLookup.CastToBoolean);
  dataAddr[221] = (void*) (&localB->ACCLookup.EgoSpd);
  dataAddr[222] = (void*) (( &localB->ACCLookup.DistInfo[0] + 5));
  dataAddr[223] = (void*) (&localB->ACCLookup.BrakeHoldActive);
  dataAddr[224] = (void*) (&localB->ACCLookup.DistanceState);
  dataAddr[225] = (void*) (&localB->Compare_av);
  dataAddr[226] = (void*) (&localB->Compare_pq);
  dataAddr[227] = (void*) (&localB->Compare_mu);
  dataAddr[228] = (void*) (&localB->ACCAct370_f);
  dataAddr[229] = (void*) (&localB->ACCHdwyStg);
  dataAddr[230] = (void*) (&localB->ACCDrvrSeltdSpd);
  dataAddr[231] = (void*) (&localB->Gain_k);
  dataAddr[232] = (void*) (&localB->Gain1);
  dataAddr[233] = (void*) (&localB->ACCHdwySTG);
  dataAddr[234] = (void*) (&localB->EgoSpd);
  dataAddr[235] = (void*) (&localB->TargetPos);
  dataAddr[236] = (void*) (&localB->EgoPos);
  dataAddr[237] = (void*) (&localB->Add);
  dataAddr[238] = (void*) (&localB->Add1_i);
  dataAddr[239] = (void*) (&localB->TargetRelSpd);
  dataAddr[240] = (void*) (&localB->Switch1);
  dataAddr[241] = (void*) (&localB->LastSpeed);
  dataAddr[242] = (void*) (&localB->LastDistance);
  dataAddr[243] = (void*) (&localB->KeepTrackValidity);
  dataAddr[244] = (void*) (&localB->DistanceValidity);
  dataAddr[245] = (void*) (&localB->Gain_h);
  dataAddr[246] = (void*) (&localB->LeadVehicleSpeedmph);
  dataAddr[247] = (void*) (&localB->DistanceValidity_d);
  dataAddr[248] = (void*) (&localB->FarDistanceTarget);
  dataAddr[249] = (void*) (&localB->MediumDistanceTarget);
  dataAddr[250] = (void*) (&localB->NearDistanceTarget);
  dataAddr[251] = (void*) (&localB->SafeDist);
  dataAddr[252] = (void*) (&localB->ctDist);
  dataAddr[253] = (void*) (&localB->Minus);
  dataAddr[254] = (void*) (&localB->DistErr);
  dataAddr[255] = (void*) (&localB->DelayOneStep);
  dataAddr[256] = (void*) (&localB->DelayOneStep1);
  dataAddr[257] = (void*) (&localB->Compare_is);
  dataAddr[258] = (void*) (&localB->MatrixConcatenate[0]);
  dataAddr[259] = (void*) (&localB->MatrixConcatenate1[0]);
  dataAddr[260] = (void*) (( &localB->MatrixConcatenate[0] + 2));
  dataAddr[261] = (void*) (&localB->MatrixConcatenate1[0]);
  dataAddr[262] = (void*) (( &localB->MatrixConcatenate1[0] + 4));
  dataAddr[263] = (void*) (&localB->VehicleSpeedMultiplier);
  dataAddr[264] = (void*) (&localB->Product);
  dataAddr[265] = (void*) (&localB->DynamicPSOCTable1);
  dataAddr[266] = (void*) (( &localB->MatrixConcatenate1[0] + 1));
  dataAddr[267] = (void*) (( &localB->MatrixConcatenate1[0] + 3));
  dataAddr[268] = (void*) (&localB->Switch_j);
  dataAddr[269] = (void*) (&localB->LowerRelop1);
  dataAddr[270] = (void*) (&localB->UpperRelop);
  dataAddr[271] = (void*) (&localB->Switch_l);
  dataAddr[272] = (void*) (&localB->Switch2_p);
  dataAddr[273] = (void*) (&localB->sf_ABSRegenOff.Fault_Out);
  dataAddr[274] = (void*) (&localB->BPPTrqCancel);
  dataAddr[275] = (void*) (&localB->BPPTrqCancel_h);
  dataAddr[276] = (void*) (&localB->LogicalOperator3_d);
  dataAddr[277] = (void*) (&localB->sf_ABSRegenOff_f.Fault_Out);
  dataAddr[278] = (void*) (&localB->GFDLightOn);
  dataAddr[279] = (void*) (&localB->FirstTimeFlag);
  dataAddr[280] = (void*) (&localB->DataTypeConversion3_k);
  dataAddr[281] = (void*) (&localB->kohmstoohms);
  dataAddr[282] = (void*) (&localB->gfd);
  dataAddr[283] = (void*) (&localB->Memory7);
  dataAddr[284] = (void*) (&localB->Divide);
  dataAddr[285] = (void*) (&localB->closedcontactorbatteryrange);
  dataAddr[286] = (void*) (&localB->LogicalOperator1_c);
  dataAddr[287] = (void*) (&localB->sf_OverVoltage.Fault_Out);
  dataAddr[288] = (void*) (&localB->sf_UnderVoltage.Fault_Out);
  dataAddr[289] = (void*) (&localB->sf_OverDischarge.Fault_Out);
  dataAddr[290] = (void*) (&localB->Fault_o);
  dataAddr[291] = (void*) (&localB->Fault_g);
  dataAddr[292] = (void*) (&localB->Fault);
  dataAddr[293] = (void*) (&localB->DataTypeConversion1_k);
  dataAddr[294] = (void*) (&localB->DataTypeConversion2);
  dataAddr[295] = (void*) (&localB->DataTypeConversion3);
  dataAddr[296] = (void*) (&localB->DataTypeConversion7);
  dataAddr[297] = (void*) (&localB->LogicalOperator);
  dataAddr[298] = (void*) (&localB->sf_Faultcounter1.fail_flag);
  dataAddr[299] = (void*) (&localB->DataTypeConversion);
  dataAddr[300] = (void*) (&localB->Gain);
  dataAddr[301] = (void*) (&localB->IC);
  dataAddr[302] = (void*) (&localB->LogicalOperator6);
  dataAddr[303] = (void*) (&localB->LogicalOperator7);
  dataAddr[304] = (void*) (&localB->LogicalOperator8);
  dataAddr[305] = (void*) (&localB->LogicalOperator1_a);
  dataAddr[306] = (void*) (&localB->fail_flag);
  dataAddr[307] = (void*) (&localB->DataTypeConversion1);
  dataAddr[308] = (void*) (&localB->IC_e);
  dataAddr[309] = (void*) (&localB->RecieveDrive);
  dataAddr[310] = (void*) (&localB->LogicalOperator1);
  dataAddr[311] = (void*) (&localB->LogicalOperator2);
  dataAddr[312] = (void*) (&localB->LogicalOperator3);
  dataAddr[313] = (void*) (&localB->LogicalOperator4);
  dataAddr[314] = (void*) (&localB->LogicalOperator5);
  dataAddr[315] = (void*) (&localB->LogicalOperator6_k);
  dataAddr[316] = (void*) (&localB->LogicalOperator7_c);
  dataAddr[317] = (void*) (&localB->LogicalOperator1_i);
  dataAddr[318] = (void*) (&localB->sf_Faultcounter1_f.fail_flag);
  dataAddr[319] = (void*) (&localB->Abs1_d);
  dataAddr[320] = (void*) (&localB->Abs2);
  dataAddr[321] = (void*) (&localB->Abs3);
  dataAddr[322] = (void*) (&localB->DataTypeConversion4);
  dataAddr[323] = (void*) (&localB->IC_d);
  dataAddr[324] = (void*) (&localB->AND_a);
  dataAddr[325] = (void*) (&localB->Product2);
  dataAddr[326] = (void*) (&localB->Add_m);
  dataAddr[327] = (void*) (&localB->Compare_o);
  dataAddr[328] = (void*) (&localB->whlspd);
  dataAddr[329] = (void*) (&localB->MinMax1);
  dataAddr[330] = (void*) (&localB->Divide_g);
  dataAddr[331] = (void*) (&localB->Product_f);
  dataAddr[332] = (void*) (&localB->Saturation_n);
  dataAddr[333] = (void*) (&localB->preventsdividingbyzero);
  dataAddr[334] = (void*) (&localB->Switch2_d);
  dataAddr[335] = (void*) (&localB->MotorCompCancel);
  dataAddr[336] = (void*) (&localB->GearTo);
  dataAddr[337] = (void*) (&localB->GearChangeDuration);
  dataAddr[338] = (void*) (&localB->Multiplier);
  dataAddr[339] = (void*) (&localB->Gain_ha);
  dataAddr[340] = (void*) (&localB->Gain1_l);
  dataAddr[341] = (void*) (&localB->VehSpdMPH);
  dataAddr[342] = (void*) (&localB->RPM_to_rads);
  dataAddr[343] = (void*) (&localB->DiagnosticFaults);
  dataAddr[344] = (void*) (&localB->LogicalOperator_d);
  dataAddr[345] = (void*) (&localB->LogicalOperator1_e);
  dataAddr[346] = (void*) (&localB->OR_b);
  dataAddr[347] = (void*) (&localB->StartTorqueTime);
  dataAddr[348] = (void*) (&localB->FullTorqueTime);
  dataAddr[349] = (void*) (&localB->LowerTorqueAtTime);
  dataAddr[350] = (void*) (&localB->EndTorqueTime);
  dataAddr[351] = (void*) (&localB->TorqueAdditionTable);
  dataAddr[352] = (void*) (&localB->Motor_Trq_Req_Raw_Nm);
  dataAddr[353] = (void*) (&localB->PowerLossBetweenShifts);
  dataAddr[354] = (void*) (&localB->Product1_e);
  dataAddr[355] = (void*) (&localB->Product3_f);
  dataAddr[356] = (void*) (&localB->Saturation);
  dataAddr[357] = (void*) (&localB->preventsdividingbyzero_h);
  dataAddr[358] = (void*) (&localB->Add_g);
  dataAddr[359] = (void*) (&localB->Switch_e);
  dataAddr[360] = (void*) (&localB->motor_trq_demand_Nm);
  dataAddr[361] = (void*) (&localB->Switch3_j);
  dataAddr[362] = (void*) (&localB->MovingAverage);
  dataAddr[363] = (void*) (&localB->AND_f);
  dataAddr[364] = (void*) (&localB->ACC_Correc_Eng);
  dataAddr[365] = (void*) (&localB->AND);
  dataAddr[366] = (void*) (&localB->ACC_Correc_Mot);
  dataAddr[367] = (void*) (&localB->FixPtGatewayIn);
  dataAddr[368] = (void*) (&localB->FixPtSum1);
  dataAddr[369] = (void*) (&localB->Compare_oe);
  dataAddr[370] = (void*) (&localB->Compare_kp);
  dataAddr[371] = (void*) (&localB->Compare_nj);
  dataAddr[372] = (void*) (&localB->Compare_o0);
  dataAddr[373] = (void*) (&localB->Compare_oa);
  dataAddr[374] = (void*) (&localB->ACCLookup.EgoSpd);
  dataAddr[375] = (void*) (&localB->ACCLookup.TargetRelPos);
  dataAddr[376] = (void*) (&localB->ACCLookup.DistInfo[0]);
  dataAddr[377] = (void*) (&localB->ACCLookup.Switch_d);
  dataAddr[378] = (void*) (&localB->ACCLookup.LastDistance);
  dataAddr[379] = (void*) (&localB->ACCLookup.DecelOut_d);
  dataAddr[380] = (void*) (&localB->ACCLookup.DecelOut);
  dataAddr[381] = (void*) (&localB->ACCLookup.DistanceMustStop);
  dataAddr[382] = (void*) (&localB->ACCLookup.BrakeHold_f);
  dataAddr[383] = (void*) (&localB->ACCLookup.DistanceState);
  dataAddr[384] = (void*) (&localB->ACCLookup.Decel);
  dataAddr[385] = (void*) (&localB->ACCLookup.BrakeHold);
  dataAddr[386] = (void*) (&localB->ACCLookup.sf_DistanceRC.StoplightValidity);
  dataAddr[387] = (void*) (&localB->ACCLookup.sf_StopLightRC.StoplightValidity);
  dataAddr[388] = (void*) (&localB->ACCLookup.Constant2);
  dataAddr[389] = (void*) (&localB->ACCLookup.Constant21);
  dataAddr[390] = (void*) (&localB->ACCLookup.Constant22);
  dataAddr[391] = (void*) (&localB->ACCLookup.Constant23);
  dataAddr[392] = (void*) (&localB->ACCLookup.CastToBoolean);
  dataAddr[393] = (void*) (&localB->ACCLookup.CastToBoolean1);
  dataAddr[394] = (void*) (&localB->ACCLookup.EgoPosition);
  dataAddr[395] = (void*) (&localB->ACCLookup.xdotPosition);
  dataAddr[396] = (void*) (&localB->ACCLookup.DistanceKeepTrack);
  dataAddr[397] = (void*) (&localB->ACCLookup.Gain);
  dataAddr[398] = (void*) (&localB->ACCLookup.Gain1);
  dataAddr[399] = (void*) (&localB->ACCLookup.Gain2);
  dataAddr[400] = (void*) (&localB->ACCLookup.SpdMPH);
  dataAddr[401] = (void*) (&localB->ACCLookup.Gain7);
  dataAddr[402] = (void*) (&localB->ACCLookup.Gain8);
  dataAddr[403] = (void*) (&localB->ACCLookup.Multiply);
  dataAddr[404] = (void*) (&localB->ACCLookup.SetSpd);
  dataAddr[405] = (void*) (&localB->ACCLookup.AND);
  dataAddr[406] = (void*) (&localB->ACCLookup.AND1);
  dataAddr[407] = (void*) (&localB->ACCLookup.AND2);
  dataAddr[408] = (void*) (&localB->ACCLookup.AND3);
  dataAddr[409] = (void*) (&localB->ACCLookup.AND4);
  dataAddr[410] = (void*) (&localB->ACCLookup.AND5);
  dataAddr[411] = (void*) (&localB->ACCLookup.BrakeHoldActive);
  dataAddr[412] = (void*) (&localB->ACCLookup.NOT2);
  dataAddr[413] = (void*) (&localB->ACCLookup.OR);
  dataAddr[414] = (void*) (&localB->ACCLookup.OR1);
  dataAddr[415] = (void*) (&localB->ACCLookup.OR2);
  dataAddr[416] = (void*) (&localB->ACCLookup.uDLookupTable);
  dataAddr[417] = (void*) (&localB->ACCLookup.uDLookupTable1);
  dataAddr[418] = (void*) (&localB->ACCLookup.uDLookupTable4);
  dataAddr[419] = (void*) (&localB->ACCLookup.Accel);
  dataAddr[420] = (void*) (&localB->ACCLookup.MediumConstant);
  dataAddr[421] = (void*) (&localB->ACCLookup.NearConstant);
  dataAddr[422] = (void*) (&localB->ACCLookup.SetSpeedV1);
  dataAddr[423] = (void*) (&localB->ACCLookup.SetSpeedV2);
  dataAddr[424] = (void*) (&localB->ACCLookup.Square);
  dataAddr[425] = (void*) (&localB->ACCLookup.TotalACCAccel);
  dataAddr[426] = (void*) (&localB->ACCLookup.DistanceControllerAccel);
  dataAddr[427] = (void*) (&localB->ACCLookup.Divide);
  dataAddr[428] = (void*) (&localB->ACCLookup.Divide1);
  dataAddr[429] = (void*) (&localB->ACCLookup.Divide2);
  dataAddr[430] = (void*) (&localB->ACCLookup.Divide4);
  dataAddr[431] = (void*) (&localB->ACCLookup.Product);
  dataAddr[432] = (void*) (&localB->ACCLookup.Product1);
  dataAddr[433] = (void*) (&localB->ACCLookup.Product2);
  dataAddr[434] = (void*) (&localB->ACCLookup.ACCReqPwr_m);
  dataAddr[435] = (void*) (&localB->ACCLookup.Product4);
  dataAddr[436] = (void*) (&localB->ACCLookup.Product5_i);
  dataAddr[437] = (void*) (&localB->ACCLookup.Product6_m);
  dataAddr[438] = (void*) (&localB->ACCLookup.RateTransition);
  dataAddr[439] = (void*) (&localB->ACCLookup.RateTransition1);
  dataAddr[440] = (void*) (&localB->ACCLookup.RateTransition2);
  dataAddr[441] = (void*) (&localB->ACCLookup.Saturation_e);
  dataAddr[442] = (void*) (&localB->ACCLookup.distanceAccel);
  dataAddr[443] = (void*) (&localB->ACCLookup.AccelCmd);
  dataAddr[444] = (void*) (&localB->ACCLookup.Saturation3);
  dataAddr[445] = (void*) (&localB->ACCLookup.setSpdAccel);
  dataAddr[446] = (void*) (&localB->ACCLookup.Saturation5);
  dataAddr[447] = (void*) (&localB->ACCLookup.Add);
  dataAddr[448] = (void*) (&localB->ACCLookup.SetSpeedError);
  dataAddr[449] = (void*) (&localB->ACCLookup.SetSpeedAcccel2);
  dataAddr[450] = (void*) (&localB->ACCLookup.EBCM_Decel);
  dataAddr[451] = (void*) (&localB->ACCLookup.Switch11);
  dataAddr[452] = (void*) (&localB->ACCLookup.Switch14);
  dataAddr[453] = (void*) (&localB->ACCLookup.Switch2);
  dataAddr[454] = (void*) (&localB->ACCLookup.ACCReqPwr);
  dataAddr[455] = (void*) (&localB->ACCLookup.StopLightAccel);
  dataAddr[456] = (void*) (&localB->ACCLookup.Switch5);
  dataAddr[457] = (void*) (&localB->ACCLookup.DelayOneStep);
  dataAddr[458] = (void*) (&localB->ACCLookup.DelayOneStep1);
  dataAddr[459] = (void*) (&localB->ACCLookup.DistErrFLipped);
  dataAddr[460] = (void*) (&localB->Diff);
  dataAddr[461] = (void*) (&localB->TSamp);
  dataAddr[462] = (void*) (&localB->Uk1);
  dataAddr[463] = (void*) (&localB->Diff_i);
  dataAddr[464] = (void*) (&localB->TSamp_c);
  dataAddr[465] = (void*) (&localB->Uk1_k);
  dataAddr[466] = (void*) (&localB->Compare_kf);
  dataAddr[467] = (void*) (&localB->Compare_j1);
  dataAddr[468] = (void*) (&localB->Compare_j2);
  dataAddr[469] = (void*) (&localB->Compare_nf);
  dataAddr[470] = (void*) (&localB->Compare_m);
  dataAddr[471] = (void*) (&localB->Compare_e);
  dataAddr[472] = (void*) (&localB->Compare_nx);
  dataAddr[473] = (void*) (&localB->Compare_jl);
  dataAddr[474] = (void*) (&localB->Compare_c);
  dataAddr[475] = (void*) (&localB->Compare_ej);
  dataAddr[476] = (void*) (&localB->Compare_jlm);
  dataAddr[477] = (void*) (&localB->Compare_b);
  dataAddr[478] = (void*) (&localB->Compare_l);
  dataAddr[479] = (void*) (&localB->Compare_f);
  dataAddr[480] = (void*) (&localB->Compare_i);
  dataAddr[481] = (void*) (&localB->Compare);
  dataAddr[482] = (void*) (&localB->Compare_k);
  dataAddr[483] = (void*) (&localB->Compare_n);
  dataAddr[484] = (void*) (&localB->Compare_j);
  dataAddr[485] = (void*) (&localB->Compare_a);
  dataAddr[486] = (void*) (&localB->Compare_h);
  dataAddr[487] = (void*) (&localB->Compare_fb);
  dataAddr[488] = (void*) (&localB->Compare_lt);
  dataAddr[489] = (void*) (&localB->Compare_nq);
  dataAddr[490] = (void*) (&localB->Compare_p);
  dataAddr[491] = (void*) (&localB->Compare_ha);
  dataAddr[492] = (void*) (&localB->LogicalOperator_f);
  dataAddr[493] = (void*) (&localB->LogicalOperator1_d);
  dataAddr[494] = (void*) (&localB->Compare_bf);
  dataAddr[495] = (void*) (&localB->Compare_ib);
  dataAddr[496] = (void*) (&localB->Compare_o5);
  dataAddr[497] = (void*) (&localB->Compare_mq);
  dataAddr[498] = (void*) (&localB->Compare_nw);
  dataAddr[499] = (void*) (&localB->Compare_f4);
  dataAddr[500] = (void*) (&localB->Compare_fd);
  dataAddr[501] = (void*) (&localB->Abs1);
  dataAddr[502] = (void*) (&localB->uDLookupCreepTrq_Nm);
  dataAddr[503] = (void*) (&localB->Switch_c);
  dataAddr[504] = (void*) (&localB->Switch2_a);
  dataAddr[505] = (void*) (&localB->TorqueOut);
  dataAddr[506] = (void*) (&localB->DeltaTime);
  dataAddr[507] = (void*) (&localB->TorqueReversed);
  dataAddr[508] = (void*) (&localB->Abs_g);
  dataAddr[509] = (void*) (&localB->uDLookupTable1_g);
  dataAddr[510] = (void*) (&localB->Product_n);
  dataAddr[511] = (void*) (&localB->Product1);
  dataAddr[512] = (void*) (&localB->Product2_i);
  dataAddr[513] = (void*) (&localB->Switch_oa);
  dataAddr[514] = (void*) (&localB->Tanh);
  dataAddr[515] = (void*) (&localB->DelayOneStep_b);
  dataAddr[516] = (void*) (&localB->LowerRelop1_h);
  dataAddr[517] = (void*) (&localB->UpperRelop_l5);
  dataAddr[518] = (void*) (&localB->Switch_g);
  dataAddr[519] = (void*) (&localB->Switch2_m);
  dataAddr[520] = (void*) (&localB->Switch1_i);
  dataAddr[521] = (void*) (&localB->LogicalOperator1_a1);
  dataAddr[522] = (void*) (&localB->OR_n);
  dataAddr[523] = (void*)
    (&localB->allowsbrakingtorqueifineithercruisechangingmodes);
  dataAddr[524] = (void*) (&localB->Compare_m2);
  dataAddr[525] = (void*) (&localB->LogicalOperator_fc);
  dataAddr[526] = (void*) (&localB->LogicalOperator1_d1);
  dataAddr[527] = (void*) (&localB->LogicalOperator2_m);
  dataAddr[528] = (void*) (&localB->MultiportSwitch);
  dataAddr[529] = (void*) (&localB->LowerRelop1_n);
  dataAddr[530] = (void*) (&localB->UpperRelop_e);
  dataAddr[531] = (void*) (&localB->Switch_gm);
  dataAddr[532] = (void*) (&localB->Switch2_cx);
  dataAddr[533] = (void*) (&localB->LowerRelop1_e);
  dataAddr[534] = (void*) (&localB->UpperRelop_l);
  dataAddr[535] = (void*) (&localB->Switch_o);
  dataAddr[536] = (void*) (&localB->Switch2_c);
  dataAddr[537] = (void*) (&localB->ACCLookup.Compare_a);
  dataAddr[538] = (void*) (&localB->ACCLookup.Compare);
  dataAddr[539] = (void*) (&localB->ACCLookup.Compare_k);
  dataAddr[540] = (void*) (&localB->ACCLookup.Compare_h);
  dataAddr[541] = (void*) (&localB->ACCLookup.Compare_e);
  dataAddr[542] = (void*) (&localB->ACCLookup.Diff);
  dataAddr[543] = (void*) (&localB->ACCLookup.TSamp);
  dataAddr[544] = (void*) (&localB->ACCLookup.Uk1);
  dataAddr[545] = (void*) (&localB->ACCLookup.Diff_l);
  dataAddr[546] = (void*) (&localB->ACCLookup.TSamp_l);
  dataAddr[547] = (void*) (&localB->ACCLookup.Uk1_c);
  dataAddr[548] = (void*) (&localB->ACCLookup.VectorConcatenate_e[0]);
  dataAddr[549] = (void*) (&localB->ACCLookup.VectorConcatenate1[0]);
  dataAddr[550] = (void*) (&localB->ACCLookup.DiscreteTimeIntegrator);
  dataAddr[551] = (void*) (&localB->ACCLookup.Product_f);
  dataAddr[552] = (void*) (&localB->ACCLookup.VectorConcatenate_e[0]);
  dataAddr[553] = (void*) (( &localB->ACCLookup.VectorConcatenate_e[0] + 1));
  dataAddr[554] = (void*) (&localB->ACCLookup.Switch[0]);
  dataAddr[555] = (void*) (&localB->ACCLookup.UnitDelay[0]);
  dataAddr[556] = (void*) (&localB->Compare_nm);
  dataAddr[557] = (void*) (&localB->Compare_lf);
  dataAddr[558] = (void*) (&localB->Compare_g);
  dataAddr[559] = (void*) (&localB->Compare_nu);
  dataAddr[560] = (void*) (&localB->Compare_jg);
  dataAddr[561] = (void*) (&localB->Compare_bz);
  dataAddr[562] = (void*) (&localB->Compare_lv);
  dataAddr[563] = (void*) (&localB->Compare_lz);
  dataAddr[564] = (void*) (&localB->Compare_nz);
  dataAddr[565] = (void*) (&localB->Compare_me);
  dataAddr[566] = (void*) (&localB->Compare_ni);
  dataAddr[567] = (void*) (&localB->Compare_fi);
  dataAddr[568] = (void*) (&localB->Compare_d);
  dataAddr[569] = (void*) (&localB->Compare_el);
  dataAddr[570] = (void*) (&localB->Compare_ns);
  dataAddr[571] = (void*) (&localB->ACCLookup.VectorConcatenate_k[0]);
  dataAddr[572] = (void*) (&localB->ACCLookup.VectorConcatenate1_i[0]);
  dataAddr[573] = (void*) (&localB->ACCLookup.VectorConcatenate2[0]);
  dataAddr[574] = (void*) (&localB->ACCLookup.VectorConcatenate3[0]);
  dataAddr[575] = (void*) (&localB->ACCLookup.VectorConcatenate4[0]);
  dataAddr[576] = (void*) (&localB->ACCLookup.VectorConcatenate5[0]);
  dataAddr[577] = (void*) (&localB->ACCLookup.VectorConcatenate6[0]);
  dataAddr[578] = (void*) (&localB->ACCLookup.um2);
  dataAddr[579] = (void*) (&localB->ACCLookup.b);
  dataAddr[580] = (void*) (&localB->ACCLookup.c);
  dataAddr[581] = (void*) (&localB->ACCLookup.m);
  dataAddr[582] = (void*) (&localB->ACCLookup.m1);
  dataAddr[583] = (void*) (&localB->ACCLookup.VectorConcatenate3[0]);
  dataAddr[584] = (void*) (( &localB->ACCLookup.VectorConcatenate_k[0] + 1));
  dataAddr[585] = (void*) (&localB->ACCLookup.Product5);
  dataAddr[586] = (void*) (&localB->ACCLookup.Product6);
  dataAddr[587] = (void*) (&localB->ACCLookup.Product7);
  dataAddr[588] = (void*) (&localB->ACCLookup.Add1);
  dataAddr[589] = (void*) (&localB->ACCLookup.TotalForce);
  dataAddr[590] = (void*) (&localB->ACCLookup.TrigonometricFunction1_o1);
  dataAddr[591] = (void*) (&localB->ACCLookup.TrigonometricFunction1_o2);
  dataAddr[592] = (void*) (&localB->ACCLookup.TrigonometricFunction2);
  dataAddr[593] = (void*) (&localB->ACCLookup.UnitConversion);
  dataAddr[594] = (void*) (&localB->ACCLookup.DataTypeConv1);
  dataAddr[595] = (void*) (&localB->ACCLookup.DataTypeConv2);
  dataAddr[596] = (void*) (&localB->ACCLookup.DeadZone);
  dataAddr[597] = (void*) (&localB->ACCLookup.ZeroGain);
  dataAddr[598] = (void*) (&localB->ACCLookup.AND3_e);
  dataAddr[599] = (void*) (&localB->ACCLookup.Equal1);
  dataAddr[600] = (void*) (&localB->ACCLookup.NotEqual);
  dataAddr[601] = (void*) (&localB->ACCLookup.SignPreIntegrator);
  dataAddr[602] = (void*) (&localB->ACCLookup.SignPreSat);
  dataAddr[603] = (void*) (&localB->ACCLookup.Switch_a);
  dataAddr[604] = (void*) (&localB->ACCLookup.DerivativeGain);
  dataAddr[605] = (void*) (&localB->ACCLookup.Diff_h);
  dataAddr[606] = (void*) (&localB->ACCLookup.UD);
  dataAddr[607] = (void*) (&localB->ACCLookup.IntegralGain);
  dataAddr[608] = (void*) (&localB->ACCLookup.Integrator);
  dataAddr[609] = (void*) (&localB->ACCLookup.ProportionalGain);
  dataAddr[610] = (void*) (&localB->ACCLookup.Saturation);
  dataAddr[611] = (void*) (&localB->ACCLookup.Sum);
  dataAddr[612] = (void*) (&localB->ACCLookup.SumFdbk);
  dataAddr[613] = (void*) (&localB->ACCLookup.Transpose_d[0]);
  dataAddr[614] = (void*) (&localB->ACCLookup.Product_c[0]);
  dataAddr[615] = (void*) (&localB->ACCLookup.Constant1);
  dataAddr[616] = (void*) (&localB->ACCLookup.Constant10);
  dataAddr[617] = (void*) (&localB->ACCLookup.Y);
  dataAddr[618] = (void*) (&localB->ACCLookup.Constant2_i);
  dataAddr[619] = (void*) (&localB->ACCLookup.Add_h);
  dataAddr[620] = (void*) (&localB->ACCLookup.VectorConcatenate_b[0]);
  dataAddr[621] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 3));
  dataAddr[622] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 6));
  dataAddr[623] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 1));
  dataAddr[624] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 4));
  dataAddr[625] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 7));
  dataAddr[626] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 2));
  dataAddr[627] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 5));
  dataAddr[628] = (void*) (( &localB->ACCLookup.VectorConcatenate_b[0] + 8));
  dataAddr[629] = (void*) (&localB->ACCLookup.sincos_o1_h[0]);
  dataAddr[630] = (void*) (&localB->ACCLookup.sincos_o2_n[0]);
  dataAddr[631] = (void*) (&localB->ACCLookup.Tsamp);
  dataAddr[632] = (void*) (&localB->ACCLookup.Constant11);
  dataAddr[633] = (void*) (&localB->ACCLookup.x);
  dataAddr[634] = (void*) (&localB->ACCLookup.UnitConversion_e[0]);
  dataAddr[635] = (void*) (&localB->ACCLookup.Constant14);
  dataAddr[636] = (void*) (&localB->ACCLookup.Constant5);
  dataAddr[637] = (void*) (&localB->ACCLookup.Constant7);
  dataAddr[638] = (void*) (&localB->ACCLookup.Transpose[0]);
  dataAddr[639] = (void*) (&localB->ACCLookup.Product_h[0]);
  dataAddr[640] = (void*) (&localB->ACCLookup.Product_d);
  dataAddr[641] = (void*) (&localB->ACCLookup.Product1_n);
  dataAddr[642] = (void*) (&localB->ACCLookup.Product8);
  dataAddr[643] = (void*) (&localB->ACCLookup.Product9);
  dataAddr[644] = (void*) (&localB->ACCLookup.UnaryMinus);
  dataAddr[645] = (void*) (&localB->ACCLookup.UnaryMinus1);
  dataAddr[646] = (void*) (&localB->ACCLookup.UnitConversion_l);
  dataAddr[647] = (void*) (&localB->ACCLookup.VectorConcatenate_b[0]);
  dataAddr[648] = (void*) (&localB->ACCLookup.Reshape9to3x3columnmajor_c[0]);
  dataAddr[649] = (void*) (&localB->ACCLookup.VectorConcatenate[0]);
  dataAddr[650] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 3));
  dataAddr[651] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 6));
  dataAddr[652] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 1));
  dataAddr[653] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 4));
  dataAddr[654] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 7));
  dataAddr[655] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 2));
  dataAddr[656] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 5));
  dataAddr[657] = (void*) (( &localB->ACCLookup.VectorConcatenate[0] + 8));
  dataAddr[658] = (void*) (&localB->ACCLookup.sincos_o1[0]);
  dataAddr[659] = (void*) (&localB->ACCLookup.sincos_o2[0]);
  dataAddr[660] = (void*) (&localB->ACCLookup.VectorConcatenate[0]);
  dataAddr[661] = (void*) (&localB->ACCLookup.Reshape9to3x3columnmajor[0]);
  dataAddr[662] = (void*) (&HSC_Model_P.CompareToConstant1_const_c);
  dataAddr[663] = (void*) (&HSC_Model_P.CompareToConstant2_const_a);
  dataAddr[664] = (void*) (&HSC_Model_P.CompareToConstant3_const);
  dataAddr[665] = (void*) (&HSC_Model_P.Change_Value);
  dataAddr[666] = (void*) (&HSC_Model_P.Constant10_Value);
  dataAddr[667] = (void*) (&HSC_Model_P.Denied_Value);
  dataAddr[668] = (void*) (&HSC_Model_P.SetSpdMPS_Value);
  dataAddr[669] = (void*) (&HSC_Model_P.Gain_Gain);
  dataAddr[670] = (void*) (&HSC_Model_P.Gain1_Gain_a);
  dataAddr[671] = (void*) (&HSC_Model_P.Gain2_Gain);
  dataAddr[672] = (void*) (&HSC_Model_P.Gain5_Gain);
  dataAddr[673] = (void*) (&HSC_Model_P.kmh2ms1_Gain);
  dataAddr[674] = (void*) (&HSC_Model_P.Switch1_Threshold_j);
  dataAddr[675] = (void*) (&HSC_Model_P.Switch2_Threshold);
  dataAddr[676] = (void*) (&HSC_Model_P.CompareToConstant_const_i);
  dataAddr[677] = (void*) (&HSC_Model_P.Constant_Value_dh);
  dataAddr[678] = (void*) (&HSC_Model_P.Constant1_Value);
  dataAddr[679] = (void*) (&HSC_Model_P.TargetSOC_Value);
  dataAddr[680] = (void*) (&HSC_Model_P.Gain1_Gain_o);
  dataAddr[681] = (void*) (&HSC_Model_P.kphtomph_Gain);
  dataAddr[682] = (void*) (&HSC_Model_P.IC_Value_h);
  dataAddr[683] = (void*) (&HSC_Model_P.IC1_Value);
  dataAddr[684] = (void*) (&HSC_Model_P.IC2_Value);
  dataAddr[685] = (void*) (&HSC_Model_P.IC3_Value);
  dataAddr[686] = (void*) (&HSC_Model_P.IC4_Value);
  dataAddr[687] = (void*) (&HSC_Model_P.IC5_Value);
  dataAddr[688] = (void*) (&HSC_Model_P.IC6_Value);
  dataAddr[689] = (void*) (&HSC_Model_P.IC7_Value);
  dataAddr[690] = (void*) (&HSC_Model_P.IC8_Value);
  dataAddr[691] = (void*) (&HSC_Model_P.uDLookupTable_bp01Data_m[0]);
  dataAddr[692] = (void*) (&HSC_Model_P.uDLookupTable_bp02Data[0]);
  dataAddr[693] = (void*) (&HSC_Model_P.uDLookupTable_maxIndex[0]);
  dataAddr[694] = (void*) (&HSC_Model_P.uDLookupTable2_bp01Data_k[0]);
  dataAddr[695] = (void*) (&HSC_Model_P.uDLookupTable2_bp02Data[0]);
  dataAddr[696] = (void*) (&HSC_Model_P.uDLookupTable2_bp03Data[0]);
  dataAddr[697] = (void*) (&HSC_Model_P.uDLookupTable2_maxIndex[0]);
  dataAddr[698] = (void*) (&HSC_Model_P.uDLookupTable2_dimSizes[0]);
  dataAddr[699] = (void*) (&HSC_Model_P.uDLookupTable5_bp01Data[0]);
  dataAddr[700] = (void*) (&HSC_Model_P.uDLookupTable5_bp02Data[0]);
  dataAddr[701] = (void*) (&HSC_Model_P.uDLookupTable5_bp03Data[0]);
  dataAddr[702] = (void*) (&HSC_Model_P.uDLookupTable5_maxIndex[0]);
  dataAddr[703] = (void*) (&HSC_Model_P.uDLookupTable5_dimSizes[0]);
  dataAddr[704] = (void*) (&HSC_Model_P.ContinuousDischageLimit_bp01Data[0]);
  dataAddr[705] = (void*) (&HSC_Model_P.ContinuousDischageLimit_bp02Data[0]);
  dataAddr[706] = (void*) (&HSC_Model_P.ContinuousDischageLimit_maxIndex[0]);
  dataAddr[707] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit_tableData[0]);
  dataAddr[708] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit_bp01Data[0]);
  dataAddr[709] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit1_tableData[0]);
  dataAddr[710] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit1_bp01Data[0]);
  dataAddr[711] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit2_tableData[0]);
  dataAddr[712] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit2_bp01Data[0]);
  dataAddr[713] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit3_tableData[0]);
  dataAddr[714] = (void*) (&HSC_Model_P.ContinuousMotorPowerLimit3_bp01Data[0]);
  dataAddr[715] = (void*) (&HSC_Model_P.DiscreteMotorPowerLimit_tableData[0]);
  dataAddr[716] = (void*) (&HSC_Model_P.DiscreteMotorPowerLimit_bp01Data[0]);
  dataAddr[717] = (void*) (&HSC_Model_P.DiscreteMotorPowerLimit1_tableData[0]);
  dataAddr[718] = (void*) (&HSC_Model_P.DiscreteMotorPowerLimit1_bp01Data[0]);
  dataAddr[719] = (void*) (&HSC_Model_P.Memory_InitialCondition_k);
  dataAddr[720] = (void*) (&HSC_Model_P.Memory1_InitialCondition_m);
  dataAddr[721] = (void*) (&HSC_Model_P.Switch_Threshold_n);
  dataAddr[722] = (void*) (&HSC_Model_P.Switch1_Threshold_d);
  dataAddr[723] = (void*) (&HSC_Model_P.Switch3_Threshold);
  dataAddr[724] = (void*) (&HSC_Model_P.Constant_Value_ok);
  dataAddr[725] = (void*) (&HSC_Model_P.Constant3_Value_i);
  dataAddr[726] = (void*) (&HSC_Model_P.kphtomps_Gain);
  dataAddr[727] = (void*) (&HSC_Model_P.Memory1_InitialCondition_d);
  dataAddr[728] = (void*) (&HSC_Model_P.Memory2_InitialCondition);
  dataAddr[729] = (void*) (&HSC_Model_P.CompareToConstant_const_p);
  dataAddr[730] = (void*) (&HSC_Model_P.kphtomps_Gain_g);
  dataAddr[731] = (void*) (&HSC_Model_P.Mass2550_bp01Data[0]);
  dataAddr[732] = (void*) (&HSC_Model_P.Mass2550_bp02Data[0]);
  dataAddr[733] = (void*) (&HSC_Model_P.Mass2550_maxIndex[0]);
  dataAddr[734] = (void*) (&HSC_Model_P.Saturation2_UpperSat);
  dataAddr[735] = (void*) (&HSC_Model_P.Saturation2_LowerSat);
  dataAddr[736] = (void*) (&HSC_Model_P.preventszeroingPwrDmdat0kph_UpperSat);
  dataAddr[737] = (void*) (&HSC_Model_P.preventszeroingPwrDmdat0kph_LowerSat);
  dataAddr[738] = (void*) (&HSC_Model_P.Switch_Threshold_k);
  dataAddr[739] = (void*) (&HSC_Model_P.Constant_Value_m);
  dataAddr[740] = (void*) (&HSC_Model_P.MotorEnable_Value);
  dataAddr[741] = (void*) (&HSC_Model_P.FinalDrive_Gain);
  dataAddr[742] = (void*) (&HSC_Model_P.Gain1_Gain_k);
  dataAddr[743] = (void*) (&HSC_Model_P.Gain4_Gain);
  dataAddr[744] = (void*) (&HSC_Model_P.kphtomph_Gain_e);
  dataAddr[745] = (void*) (&HSC_Model_P.kphtomps_Gain_i);
  dataAddr[746] = (void*) (&HSC_Model_P.kphtomps1_Gain);
  dataAddr[747] = (void*) (&HSC_Model_P.uDLookupTable1_tableData[0]);
  dataAddr[748] = (void*) (&HSC_Model_P.Saturation_UpperSat);
  dataAddr[749] = (void*) (&HSC_Model_P.Saturation_LowerSat);
  dataAddr[750] = (void*) (&HSC_Model_P.Saturation1_UpperSat_n);
  dataAddr[751] = (void*) (&HSC_Model_P.Saturation1_LowerSat_p);
  dataAddr[752] = (void*) (&HSC_Model_P.Switch_Threshold_f);
  dataAddr[753] = (void*) (&HSC_Model_P.ActivateMILHILVersion_Value);
  dataAddr[754] = (void*) (&HSC_Model_P.Gain_Gain_f);
  dataAddr[755] = (void*) (&HSC_Model_P.Gain1_Gain_i);
  dataAddr[756] = (void*) (&HSC_Model_P.Gain2_Gain_p);
  dataAddr[757] = (void*) (&HSC_Model_P.Gain3_Gain);
  dataAddr[758] = (void*) (&HSC_Model_P.CompareToConstant_const_l);
  dataAddr[759] = (void*) (&HSC_Model_P.CompareToConstant1_const_g);
  dataAddr[760] = (void*) (&HSC_Model_P.CompareToConstant2_const_g);
  dataAddr[761] = (void*) (&HSC_Model_P.CompareToConstant3_const_p);
  dataAddr[762] = (void*) (&HSC_Model_P.SOCChargeLimit_const);
  dataAddr[763] = (void*) (&HSC_Model_P.Constant1_Value_j);
  dataAddr[764] = (void*) (&HSC_Model_P.MaxBPPRegenW_Value);
  dataAddr[765] = (void*) (&HSC_Model_P.OffThrottleRegenPowerDemandW_Value);
  dataAddr[766] = (void*) (&HSC_Model_P.VehicleMass_Value);
  dataAddr[767] = (void*) (&HSC_Model_P.Gain_Gain_c);
  dataAddr[768] = (void*) (&HSC_Model_P.kphtomph_Gain_c);
  dataAddr[769] = (void*) (&HSC_Model_P.rbcp_regen_enable_Gain);
  dataAddr[770] = (void*) (&HSC_Model_P.uDLookupTable_tableData[0]);
  dataAddr[771] = (void*) (&HSC_Model_P.uDLookupTable_bp01Data[0]);
  dataAddr[772] = (void*) (&HSC_Model_P.uDLookupTable1_tableData_b[0]);
  dataAddr[773] = (void*) (&HSC_Model_P.uDLookupTable1_bp01Data_m[0]);
  dataAddr[774] = (void*) (&HSC_Model_P.uDLookupTable2_tableData[0]);
  dataAddr[775] = (void*) (&HSC_Model_P.uDLookupTable2_bp01Data[0]);
  dataAddr[776] = (void*) (&HSC_Model_P.SteeringWheelAngleFadeOut_tableData[0]);
  dataAddr[777] = (void*) (&HSC_Model_P.SteeringWheelAngleFadeOut_bp01Data[0]);
  dataAddr[778] = (void*) (&HSC_Model_P.VehicleSpeedFadeOut_tableData[0]);
  dataAddr[779] = (void*) (&HSC_Model_P.VehicleSpeedFadeOut_bp01Data[0]);
  dataAddr[780] = (void*) (&HSC_Model_P.Saturation1_UpperSat);
  dataAddr[781] = (void*) (&HSC_Model_P.Saturation1_LowerSat);
  dataAddr[782] = (void*) (&HSC_Model_P.BrusaEnable_Value);
  dataAddr[783] = (void*) (&HSC_Model_P.VMUmajorProt_Value);
  dataAddr[784] = (void*) (&HSC_Model_P.VMUminorProt_Value);
  dataAddr[785] = (void*) (&HSC_Model_P.kphtomph_Gain_i);
  dataAddr[786] = (void*) (&HSC_Model_P.Memory1_InitialCondition);
  dataAddr[787] = (void*) (&HSC_Model_P.Constant_Value_c);
  dataAddr[788] = (void*) (&HSC_Model_P.Constant1_Value_c);
  dataAddr[789] = (void*) (&HSC_Model_P.Constant2_Value_p);
  dataAddr[790] = (void*) (&HSC_Model_P.Constant4_Value_c);
  dataAddr[791] = (void*) (&HSC_Model_P.Constant5_Value);
  dataAddr[792] = (void*) (&HSC_Model_P.Constant6_Value);
  dataAddr[793] = (void*) (&HSC_Model_P.Constant7_Value_i);
  dataAddr[794] = (void*) (&HSC_Model_P.Gain_Gain_k);
  dataAddr[795] = (void*) (&HSC_Model_P.Gain1_Gain_c);
  dataAddr[796] = (void*) (&HSC_Model_P.Memory_InitialCondition);
  dataAddr[797] = (void*) (&HSC_Model_P.DiscreteDerivative_ICPrevScaledInput);
  dataAddr[798] = (void*) (&HSC_Model_P.jerkDeriv_ICPrevScaledInput);
  dataAddr[799] = (void*) (&HSC_Model_P.TargetInitialPos_Value);
  dataAddr[800] = (void*) (&HSC_Model_P.DiscreteTimeIntegrator_gainval);
  dataAddr[801] = (void*) (&HSC_Model_P.DiscreteTimeIntegrator_IC);
  dataAddr[802] = (void*) (&HSC_Model_P.DiscreteTimeIntegrator1_gainval);
  dataAddr[803] = (void*) (&HSC_Model_P.DiscreteTimeIntegrator1_IC);
  dataAddr[804] = (void*) (&HSC_Model_P.Switch_Threshold);
  dataAddr[805] = (void*) (&HSC_Model_P.Switch1_Threshold);
  dataAddr[806] = (void*) (&HSC_Model_P.Gain_Gain_iu);
  dataAddr[807] = (void*) (&HSC_Model_P.Gain1_Gain);
  dataAddr[808] = (void*) (&HSC_Model_P.FarDistanceTarget_tableData[0]);
  dataAddr[809] = (void*) (&HSC_Model_P.FarDistanceTarget_bp01Data[0]);
  dataAddr[810] = (void*) (&HSC_Model_P.MediumDistanceTarget_tableData[0]);
  dataAddr[811] = (void*) (&HSC_Model_P.MediumDistanceTarget_bp01Data[0]);
  dataAddr[812] = (void*) (&HSC_Model_P.NearDistanceTarget_tableData[0]);
  dataAddr[813] = (void*) (&HSC_Model_P.NearDistanceTarget_bp01Data[0]);
  dataAddr[814] = (void*) (&HSC_Model_P.DelayOneStep_InitialCondition);
  dataAddr[815] = (void*) (&HSC_Model_P.DelayOneStep1_InitialCondition);
  dataAddr[816] = (void*) (&HSC_Model_P.checksforLowSpeedCruiseChargeMode_const);
  dataAddr[817] = (void*) (&HSC_Model_P.Constant_Value_i);
  dataAddr[818] = (void*) (&HSC_Model_P.Constant1_Value_b);
  dataAddr[819] = (void*) (&HSC_Model_P.Constant2_Value);
  dataAddr[820] = (void*) (&HSC_Model_P.Constant3_Value);
  dataAddr[821] = (void*) (&HSC_Model_P.Constant4_Value);
  dataAddr[822] = (void*) (&HSC_Model_P.Constant7_Value);
  dataAddr[823] = (void*) (&HSC_Model_P.psoc_table_SOC_offset_Value);
  dataAddr[824] = (void*) (&HSC_Model_P.VehicleSpeedMultiplier_tableData[0]);
  dataAddr[825] = (void*) (&HSC_Model_P.VehicleSpeedMultiplier_bp01Data[0]);
  dataAddr[826] = (void*) (&HSC_Model_P.BPPCheck_const);
  dataAddr[827] = (void*) (&HSC_Model_P.LaunchModeCheck_const);
  dataAddr[828] = (void*) (&HSC_Model_P.Gain_Gain_g);
  dataAddr[829] = (void*) (&HSC_Model_P.IC_Value_c);
  dataAddr[830] = (void*) (&HSC_Model_P.CompareToConstant_const_pi);
  dataAddr[831] = (void*)
    (&HSC_Model_P.CompetitionRequirement500ohmspervolt_const);
  dataAddr[832] = (void*) (&HSC_Model_P.kohmstoohms_Gain);
  dataAddr[833] = (void*) (&HSC_Model_P.Memory7_InitialCondition);
  dataAddr[834] = (void*) (&HSC_Model_P.closedcontactorbatteryrange_UpperSat);
  dataAddr[835] = (void*) (&HSC_Model_P.closedcontactorbatteryrange_LowerSat);
  dataAddr[836] = (void*) (&HSC_Model_P.Constant_Value_d);
  dataAddr[837] = (void*) (&HSC_Model_P.CompareToConstant_const);
  dataAddr[838] = (void*) (&HSC_Model_P.CompareToConstant1_const);
  dataAddr[839] = (void*) (&HSC_Model_P.CompareToConstant_const_c);
  dataAddr[840] = (void*) (&HSC_Model_P.CompareToConstant1_const_f);
  dataAddr[841] = (void*) (&HSC_Model_P.CompareToConstant2_const);
  dataAddr[842] = (void*) (&HSC_Model_P.CompareToConstant3_const_n);
  dataAddr[843] = (void*) (&HSC_Model_P.CompareToConstant6_const);
  dataAddr[844] = (void*) (&HSC_Model_P.CheckForDrive_const);
  dataAddr[845] = (void*) (&HSC_Model_P.CheckForReverse_const_b);
  dataAddr[846] = (void*) (&HSC_Model_P.ForwardMotionCheck_const);
  dataAddr[847] = (void*) (&HSC_Model_P.ReverseMotionCheck_const);
  dataAddr[848] = (void*) (&HSC_Model_P.Gain_Gain_o);
  dataAddr[849] = (void*) (&HSC_Model_P.IC_Value);
  dataAddr[850] = (void*) (&HSC_Model_P.Constant_Value_p);
  dataAddr[851] = (void*) (&HSC_Model_P.CheckForDrive1_const);
  dataAddr[852] = (void*) (&HSC_Model_P.CheckForNeutral_const);
  dataAddr[853] = (void*) (&HSC_Model_P.CheckForPark1_const);
  dataAddr[854] = (void*) (&HSC_Model_P.CheckForReverse_const);
  dataAddr[855] = (void*) (&HSC_Model_P.CheckForReverse2_const);
  dataAddr[856] = (void*) (&HSC_Model_P.FirstGearOrGreater_const);
  dataAddr[857] = (void*) (&HSC_Model_P.NinethGearOrless_const);
  dataAddr[858] = (void*) (&HSC_Model_P.IC_Value_m);
  dataAddr[859] = (void*) (&HSC_Model_P.CompareToConstant_const_m);
  dataAddr[860] = (void*) (&HSC_Model_P.IC_Value_b);
  dataAddr[861] = (void*) (&HSC_Model_P.CompareToConstant_const_f);
  dataAddr[862] = (void*) (&HSC_Model_P.Saturation_UpperSat_a);
  dataAddr[863] = (void*) (&HSC_Model_P.Saturation_LowerSat_pg);
  dataAddr[864] = (void*) (&HSC_Model_P.preventsdividingbyzero_UpperSat_a);
  dataAddr[865] = (void*) (&HSC_Model_P.preventsdividingbyzero_LowerSat_n);
  dataAddr[866] = (void*) (&HSC_Model_P.CheckforkeyinRun_const);
  dataAddr[867] = (void*) (&HSC_Model_P.ChecksforDrive_const);
  dataAddr[868] = (void*) (&HSC_Model_P.ChecksforShftLvrPosReverse_const);
  dataAddr[869] = (void*) (&HSC_Model_P.ChecksforShftLvrPosUnknown_const);
  dataAddr[870] = (void*) (&HSC_Model_P.CompareToConstant_const_ph);
  dataAddr[871] = (void*) (&HSC_Model_P.CompareToConstant1_const_l);
  dataAddr[872] = (void*) (&HSC_Model_P.CompareToConstant2_const_k);
  dataAddr[873] = (void*) (&HSC_Model_P.Reverse_const);
  dataAddr[874] = (void*) (&HSC_Model_P.Constant1_Value_h);
  dataAddr[875] = (void*) (&HSC_Model_P.Gain_Gain_i);
  dataAddr[876] = (void*) (&HSC_Model_P.Gain19_Gain);
  dataAddr[877] = (void*) (&HSC_Model_P.RPM_to_rads_Gain);
  dataAddr[878] = (void*) (&HSC_Model_P.T1startofcompensation_bp01Data[0]);
  dataAddr[879] = (void*) (&HSC_Model_P.T1startofcompensation_bp02Data[0]);
  dataAddr[880] = (void*) (&HSC_Model_P.T1startofcompensation_maxIndex[0]);
  dataAddr[881] = (void*) (&HSC_Model_P.T2timeaftert1tofulltorque_bp01Data[0]);
  dataAddr[882] = (void*) (&HSC_Model_P.T2timeaftert1tofulltorque_bp02Data[0]);
  dataAddr[883] = (void*) (&HSC_Model_P.T2timeaftert1tofulltorque_maxIndex[0]);
  dataAddr[884] = (void*) (&HSC_Model_P.T3timebeforet4tolowertorque_bp01Data[0]);
  dataAddr[885] = (void*) (&HSC_Model_P.T3timebeforet4tolowertorque_bp02Data[0]);
  dataAddr[886] = (void*) (&HSC_Model_P.T3timebeforet4tolowertorque_maxIndex[0]);
  dataAddr[887] = (void*) (&HSC_Model_P.T4directtimetoendcompensation_bp01Data[0]);
  dataAddr[888] = (void*) (&HSC_Model_P.T4directtimetoendcompensation_bp02Data[0]);
  dataAddr[889] = (void*) (&HSC_Model_P.T4directtimetoendcompensation_maxIndex[0]);
  dataAddr[890] = (void*) (&HSC_Model_P.TorqueAdditionTable_bp01Data[0]);
  dataAddr[891] = (void*) (&HSC_Model_P.TorqueAdditionTable_bp02Data[0]);
  dataAddr[892] = (void*) (&HSC_Model_P.TorqueAdditionTable_maxIndex[0]);
  dataAddr[893] = (void*) (&HSC_Model_P.Saturation_UpperSat_c);
  dataAddr[894] = (void*) (&HSC_Model_P.Saturation_LowerSat_p);
  dataAddr[895] = (void*) (&HSC_Model_P.preventsdividingbyzero_UpperSat);
  dataAddr[896] = (void*) (&HSC_Model_P.preventsdividingbyzero_LowerSat);
  dataAddr[897] = (void*) (&HSC_Model_P.Constant_Value_ic);
  dataAddr[898] = (void*) (&HSC_Model_P.FixPtConstant_Value);
  dataAddr[899] = (void*) (&HSC_Model_P.ACCLookup.CompareToConstant_const);
  dataAddr[900] = (void*) (&HSC_Model_P.ACCLookup.CompareToConstant1_const);
  dataAddr[901] = (void*) (&HSC_Model_P.ACCLookup.CompareToConstant2_const);
  dataAddr[902] = (void*) (&HSC_Model_P.ACCLookup.CompareToConstant3_const);
  dataAddr[903] = (void*) (&HSC_Model_P.ACCLookup.CompareToConstant4_const);
  dataAddr[904] = (void*)
    (&HSC_Model_P.ACCLookup.DiscreteDerivative_ICPrevScaledInput);
  dataAddr[905] = (void*)
    (&HSC_Model_P.ACCLookup.DiscreteDerivative1_ICPrevScaledInput);
  dataAddr[906] = (void*) (&HSC_Model_P.ACCLookup.PIDController1_P);
  dataAddr[907] = (void*) (&HSC_Model_P.ACCLookup.PIDController1_I);
  dataAddr[908] = (void*) (&HSC_Model_P.ACCLookup.PIDController1_D);
  dataAddr[909] = (void*)
    (&HSC_Model_P.ACCLookup.PIDController1_InitialConditionForIntegrator);
  dataAddr[910] = (void*)
    (&HSC_Model_P.ACCLookup.PIDController1_DifferentiatorICPrevScaledInput);
  dataAddr[911] = (void*)
    (&HSC_Model_P.ACCLookup.PIDController1_UpperSaturationLimit);
  dataAddr[912] = (void*)
    (&HSC_Model_P.ACCLookup.PIDController1_LowerSaturationLimit);
  dataAddr[913] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_m);
  dataAddr[914] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_a);
  dataAddr[915] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_b);
  dataAddr[916] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_c);
  dataAddr[917] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_g);
  dataAddr[918] = (void*) (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_x_o);
  dataAddr[919] = (void*)
    (&HSC_Model_P.ACCLookup.VehicleBodyTotalRoadLoad_xdot_o);
  dataAddr[920] = (void*) (&HSC_Model_P.ACCLookup.Constant_Value);
  dataAddr[921] = (void*) (&HSC_Model_P.ACCLookup.Constant1_Value_b);
  dataAddr[922] = (void*) (&HSC_Model_P.ACCLookup.Constant10_Value);
  dataAddr[923] = (void*) (&HSC_Model_P.ACCLookup.Constant11_Value);
  dataAddr[924] = (void*) (&HSC_Model_P.ACCLookup.Constant2_Value);
  dataAddr[925] = (void*) (&HSC_Model_P.ACCLookup.Constant21_Value);
  dataAddr[926] = (void*) (&HSC_Model_P.ACCLookup.Constant22_Value);
  dataAddr[927] = (void*) (&HSC_Model_P.ACCLookup.Constant23_Value);
  dataAddr[928] = (void*) (&HSC_Model_P.ACCLookup.Constant24_Value);
  dataAddr[929] = (void*) (&HSC_Model_P.ACCLookup.Constant25_Value);
  dataAddr[930] = (void*) (&HSC_Model_P.ACCLookup.Constant26_Value);
  dataAddr[931] = (void*) (&HSC_Model_P.ACCLookup.Constant3_Value);
  dataAddr[932] = (void*) (&HSC_Model_P.ACCLookup.Constant4_Value);
  dataAddr[933] = (void*) (&HSC_Model_P.ACCLookup.Constant5_Value);
  dataAddr[934] = (void*) (&HSC_Model_P.ACCLookup.Constant6_Value);
  dataAddr[935] = (void*) (&HSC_Model_P.ACCLookup.a_Value);
  dataAddr[936] = (void*) (&HSC_Model_P.ACCLookup.b_Value);
  dataAddr[937] = (void*) (&HSC_Model_P.ACCLookup.c_Value);
  dataAddr[938] = (void*) (&HSC_Model_P.ACCLookup.deceleration_Value);
  dataAddr[939] = (void*) (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator_gainval);
  dataAddr[940] = (void*) (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator_IC);
  dataAddr[941] = (void*)
    (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator1_gainval);
  dataAddr[942] = (void*) (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator1_IC);
  dataAddr[943] = (void*)
    (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator3_gainval);
  dataAddr[944] = (void*) (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator3_IC);
  dataAddr[945] = (void*) (&HSC_Model_P.ACCLookup.Gain_Gain);
  dataAddr[946] = (void*) (&HSC_Model_P.ACCLookup.Gain1_Gain);
  dataAddr[947] = (void*) (&HSC_Model_P.ACCLookup.Gain2_Gain);
  dataAddr[948] = (void*) (&HSC_Model_P.ACCLookup.Gain3_Gain);
  dataAddr[949] = (void*) (&HSC_Model_P.ACCLookup.Gain7_Gain);
  dataAddr[950] = (void*) (&HSC_Model_P.ACCLookup.Gain8_Gain);
  dataAddr[951] = (void*) (&HSC_Model_P.ACCLookup.kph2ms_Gain);
  dataAddr[952] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable_bp01Data[0]);
  dataAddr[953] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable_bp02Data[0]);
  dataAddr[954] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable_maxIndex[0]);
  dataAddr[955] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable1_bp01Data[0]);
  dataAddr[956] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable1_bp02Data[0]);
  dataAddr[957] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable1_maxIndex[0]);
  dataAddr[958] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable4_bp01Data[0]);
  dataAddr[959] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable4_bp02Data[0]);
  dataAddr[960] = (void*) (&HSC_Model_P.ACCLookup.uDLookupTable4_maxIndex[0]);
  dataAddr[961] = (void*) (&HSC_Model_P.ACCLookup.FarConstant_bp01Data[0]);
  dataAddr[962] = (void*) (&HSC_Model_P.ACCLookup.FarConstant_bp02Data[0]);
  dataAddr[963] = (void*) (&HSC_Model_P.ACCLookup.FarConstant_maxIndex[0]);
  dataAddr[964] = (void*) (&HSC_Model_P.ACCLookup.MediumConstant_bp01Data[0]);
  dataAddr[965] = (void*) (&HSC_Model_P.ACCLookup.MediumConstant_bp02Data[0]);
  dataAddr[966] = (void*) (&HSC_Model_P.ACCLookup.MediumConstant_maxIndex[0]);
  dataAddr[967] = (void*) (&HSC_Model_P.ACCLookup.NearConstant_bp01Data[0]);
  dataAddr[968] = (void*) (&HSC_Model_P.ACCLookup.NearConstant_bp02Data[0]);
  dataAddr[969] = (void*) (&HSC_Model_P.ACCLookup.NearConstant_maxIndex[0]);
  dataAddr[970] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV1_bp01Data[0]);
  dataAddr[971] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV1_bp02Data[0]);
  dataAddr[972] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV1_maxIndex[0]);
  dataAddr[973] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV2_bp01Data[0]);
  dataAddr[974] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV2_bp02Data[0]);
  dataAddr[975] = (void*) (&HSC_Model_P.ACCLookup.SetSpeedV2_maxIndex[0]);
  dataAddr[976] = (void*) (&HSC_Model_P.ACCLookup.Saturation_UpperSat);
  dataAddr[977] = (void*) (&HSC_Model_P.ACCLookup.Saturation_LowerSat);
  dataAddr[978] = (void*) (&HSC_Model_P.ACCLookup.Saturation1_UpperSat);
  dataAddr[979] = (void*) (&HSC_Model_P.ACCLookup.Saturation1_LowerSat);
  dataAddr[980] = (void*) (&HSC_Model_P.ACCLookup.Saturation2_UpperSat);
  dataAddr[981] = (void*) (&HSC_Model_P.ACCLookup.Saturation2_LowerSat);
  dataAddr[982] = (void*) (&HSC_Model_P.ACCLookup.Saturation3_UpperSat);
  dataAddr[983] = (void*) (&HSC_Model_P.ACCLookup.Saturation3_LowerSat);
  dataAddr[984] = (void*) (&HSC_Model_P.ACCLookup.Saturation4_UpperSat);
  dataAddr[985] = (void*) (&HSC_Model_P.ACCLookup.Saturation4_LowerSat);
  dataAddr[986] = (void*) (&HSC_Model_P.ACCLookup.Saturation5_UpperSat);
  dataAddr[987] = (void*) (&HSC_Model_P.ACCLookup.Saturation5_LowerSat);
  dataAddr[988] = (void*) (&HSC_Model_P.ACCLookup.DelayOneStep_InitialCondition);
  dataAddr[989] = (void*) (&HSC_Model_P.ACCLookup.DelayOneStep1_InitialCondition);
  dataAddr[990] = (void*) (&HSC_Model_P.TSamp_WtEt);
  dataAddr[991] = (void*) (&HSC_Model_P.TSamp_WtEt_j);
  dataAddr[992] = (void*) (&HSC_Model_P.Constant_Value);
  dataAddr[993] = (void*) (&HSC_Model_P.ChecksforDrive_const_p);
  dataAddr[994] = (void*) (&HSC_Model_P.ChecksforReverse_const);
  dataAddr[995] = (void*) (&HSC_Model_P.ChecksforShftLvrPosUnknown_const_a);
  dataAddr[996] = (void*) (&HSC_Model_P.CreepTorqueThreshold_Nm_const);
  dataAddr[997] = (void*) (&HSC_Model_P.Constant_Value_ij);
  dataAddr[998] = (void*) (&HSC_Model_P.uDLookupCreepTrq_Nm_tableData[0]);
  dataAddr[999] = (void*) (&HSC_Model_P.uDLookupCreepTrq_Nm_bp01Data[0]);
  dataAddr[1000] = (void*) (&HSC_Model_P.uDLookupTable1_bp01Data[0]);
  dataAddr[1001] = (void*) (&HSC_Model_P.Switch_Threshold_nw);
  dataAddr[1002] = (void*) (&HSC_Model_P.DelayOneStep_InitialCondition_a);
  dataAddr[1003] = (void*) (&HSC_Model_P.CheckForLaunchMode_const);
  dataAddr[1004] = (void*) (&HSC_Model_P.LoadTorqueNm_Value);
  dataAddr[1005] = (void*) (&HSC_Model_P.checksifcruisechargingmode_const);
  dataAddr[1006] = (void*)
    (&HSC_Model_P.checksiflowspeedCruiseChargingmode_const);
  dataAddr[1007] = (void*) (&HSC_Model_P.checksifregenmode_const);
  dataAddr[1008] = (void*) (&HSC_Model_P.ChargeSOCLimit_const);
  dataAddr[1009] = (void*) (&HSC_Model_P.DischargingSOCLimit_const);
  dataAddr[1010] = (void*) (&HSC_Model_P.SOCOkay_Value);
  dataAddr[1011] = (void*)
    (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator_gainval_e);
  dataAddr[1012] = (void*) (&HSC_Model_P.ACCLookup.DiscreteTimeIntegrator_IC_d);
  dataAddr[1013] = (void*) (&HSC_Model_P.ACCLookup.UnitDelay_InitialCondition[0]);
  dataAddr[1014] = (void*) (&HSC_Model_P.Constant_Value_n);
  dataAddr[1015] = (void*) (&HSC_Model_P.Constant_Value_o);
  dataAddr[1016] = (void*) (&HSC_Model_P.Constant_Value_k);
  dataAddr[1017] = (void*) (&HSC_Model_P.Constant_Value_f);
  dataAddr[1018] = (void*) (&HSC_Model_P.Constant_Value_o5);
  dataAddr[1019] = (void*) (&HSC_Model_P.ACCLookup.um2_Gain);
  dataAddr[1020] = (void*) (&HSC_Model_P.ACCLookup.Constant1_Value);
  dataAddr[1021] = (void*) (&HSC_Model_P.ACCLookup.ZeroGain_Gain);
  dataAddr[1022] = (void*) (&HSC_Model_P.ACCLookup.Integrator_gainval);
  dataAddr[1023] = (void*) (&HSC_Model_P.ACCLookup.Constant_Value_b);
  dataAddr[1024] = (void*) (&HSC_Model_P.ACCLookup.Constant1_Value_i);
  dataAddr[1025] = (void*) (&HSC_Model_P.ACCLookup.Constant10_Value_l);
  dataAddr[1026] = (void*) (&HSC_Model_P.ACCLookup.Constant12_Value);
  dataAddr[1027] = (void*) (&HSC_Model_P.ACCLookup.Constant2_Value_d);
  dataAddr[1028] = (void*) (&HSC_Model_P.ACCLookup.Tsamp_WtEt);
  dataAddr[1029] = (void*) (&HSC_Model_P.ACCLookup.Constant11_Value_m);
  dataAddr[1030] = (void*) (&HSC_Model_P.ACCLookup.Constant14_Value);
  dataAddr[1031] = (void*) (&HSC_Model_P.ACCLookup.Constant5_Value_a);
  dataAddr[1032] = (void*) (&HSC_Model_P.ACCLookup.Constant7_Value);
  dataAddr[1033] = (void*) (&HSC_Model_P.ACCLookup.Constant_Value_k);
  dataAddr[1034] = (void*) (&localDW->DiscreteTimeIntegrator_DSTATE);
  dataAddr[1035] = (void*) (&localDW->DiscreteTimeIntegrator1_DSTATE);
  dataAddr[1036] = (void*) (&localDW->DelayOneStep_DSTATE);
  dataAddr[1037] = (void*) (&localDW->DelayOneStep1_DSTATE);
  dataAddr[1038] = (void*) (&localDW->ACCLookup.DiscreteTimeIntegrator_DSTATE);
  dataAddr[1039] = (void*) (&localDW->ACCLookup.DiscreteTimeIntegrator1_DSTATE);
  dataAddr[1040] = (void*) (&localDW->ACCLookup.DiscreteTimeIntegrator3_DSTATE);
  dataAddr[1041] = (void*) (&localDW->ACCLookup.DelayOneStep_DSTATE);
  dataAddr[1042] = (void*) (&localDW->ACCLookup.DelayOneStep1_DSTATE);
  dataAddr[1043] = (void*) (&localDW->UD_DSTATE);
  dataAddr[1044] = (void*) (&localDW->UD_DSTATE_j);
  dataAddr[1045] = (void*) (&localDW->DelayOneStep_DSTATE_b);
  dataAddr[1046] = (void*) (&localDW->ACCLookup.UD_DSTATE);
  dataAddr[1047] = (void*) (&localDW->ACCLookup.UD_DSTATE_i);
  dataAddr[1048] = (void*) (&localDW->ACCLookup.DiscreteTimeIntegrator_DSTATE_m);
  dataAddr[1049] = (void*) (&localDW->ACCLookup.UnitDelay_DSTATE[0]);
  dataAddr[1050] = (void*) (&localX->ACCLookup.Integrator1_CSTATE);
  dataAddr[1051] = (void*) (&localDW->ACCLookup.UD_DSTATE_d);
  dataAddr[1052] = (void*) (&localDW->ACCLookup.Integrator_DSTATE);
  dataAddr[1053] = (void*) (&localX->ACCLookup.Integrator3_CSTATE);
  dataAddr[1054] = (void*) (&HSC_Model_P.ACC_Distance_Lookup[0]);
  dataAddr[1055] = (void*) (&HSC_Model_P.ACC_Distance_Lookup_Constant_Method[0]);
  dataAddr[1056] = (void*)
    (&HSC_Model_P.ACC_Distance_Lookup_Far_Constant_Method[0]);
  dataAddr[1057] = (void*)
    (&HSC_Model_P.ACC_Distance_Lookup_Near_Constant_Method[0]);
  dataAddr[1058] = (void*) (&HSC_Model_P.ACC_Setspeed_Lookup[0]);
  dataAddr[1059] = (void*) (&HSC_Model_P.ACC_Setspeed_Lookup_V2[0]);
  dataAddr[1060] = (void*) (&HSC_Model_P.Breakpoint1MotorCompensation[0]);
  dataAddr[1061] = (void*) (&HSC_Model_P.Breakpoint2MotorCompensation[0]);
  dataAddr[1062] = (void*) (&HSC_Model_P.Breakpoint3MotorCompensation[0]);
  dataAddr[1063] = (void*) (&HSC_Model_P.Breakpoint4MotorCompensation[0]);
  dataAddr[1064] = (void*) (&HSC_Model_P.ContinuousBatteryCharge[0]);
  dataAddr[1065] = (void*) (&HSC_Model_P.ContinuousBatteryDischarge[0]);
  dataAddr[1066] = (void*) (&HSC_Model_P.InterpBatteryCharge[0]);
  dataAddr[1067] = (void*) (&HSC_Model_P.InterpBatteryDischarge[0]);
  dataAddr[1068] = (void*) (&HSC_Model_P.Mass2550TorqueMap[0]);
  dataAddr[1069] = (void*) (&HSC_Model_P.MotorCompensationAxlTorque[0]);
  dataAddr[1070] = (void*) (&HSC_Model_P.N[0]);
  dataAddr[1071] = (void*) (&HSC_Model_P.Re);
  dataAddr[1072] = (void*) (&HSC_Model_P.Reverse_APP[0]);
  dataAddr[1073] = (void*) (&HSC_Model_P.Stoplight_distance_speed_only[0]);
  dataAddr[1074] = (void*) (&HSC_Model_P.bppRegenLookup[0]);
  dataAddr[1075] = (void*) (&HSC_Model_P.bppRegenMap[0]);
  dataAddr[1076] = (void*) (&HSC_Model_P.f_tbrake_n_bpt[0]);
  dataAddr[1077] = (void*) (&HSC_Model_P.motor_speed_bkp_rpm[0]);
  dataAddr[1078] = (void*) (&HSC_Model_P.peak_trq_curve[0]);
  dataAddr[1079] = (void*) (&HSC_Model_P.tandivide[0]);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void HSC_Model_InitializeVarDimsAddr(int32_T* vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void HSC_Model_InitializeLoggingFunctions(RTWLoggingFcnPtr loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
  loggingPtrs[14] = (NULL);
  loggingPtrs[15] = (NULL);
  loggingPtrs[16] = (NULL);
  loggingPtrs[17] = (NULL);
  loggingPtrs[18] = (NULL);
  loggingPtrs[19] = (NULL);
  loggingPtrs[20] = (NULL);
  loggingPtrs[21] = (NULL);
  loggingPtrs[22] = (NULL);
  loggingPtrs[23] = (NULL);
  loggingPtrs[24] = (NULL);
  loggingPtrs[25] = (NULL);
  loggingPtrs[26] = (NULL);
  loggingPtrs[27] = (NULL);
  loggingPtrs[28] = (NULL);
  loggingPtrs[29] = (NULL);
  loggingPtrs[30] = (NULL);
  loggingPtrs[31] = (NULL);
  loggingPtrs[32] = (NULL);
  loggingPtrs[33] = (NULL);
  loggingPtrs[34] = (NULL);
  loggingPtrs[35] = (NULL);
  loggingPtrs[36] = (NULL);
  loggingPtrs[37] = (NULL);
  loggingPtrs[38] = (NULL);
  loggingPtrs[39] = (NULL);
  loggingPtrs[40] = (NULL);
  loggingPtrs[41] = (NULL);
  loggingPtrs[42] = (NULL);
  loggingPtrs[43] = (NULL);
  loggingPtrs[44] = (NULL);
  loggingPtrs[45] = (NULL);
  loggingPtrs[46] = (NULL);
  loggingPtrs[47] = (NULL);
  loggingPtrs[48] = (NULL);
  loggingPtrs[49] = (NULL);
  loggingPtrs[50] = (NULL);
  loggingPtrs[51] = (NULL);
  loggingPtrs[52] = (NULL);
  loggingPtrs[53] = (NULL);
  loggingPtrs[54] = (NULL);
  loggingPtrs[55] = (NULL);
  loggingPtrs[56] = (NULL);
  loggingPtrs[57] = (NULL);
  loggingPtrs[58] = (NULL);
  loggingPtrs[59] = (NULL);
  loggingPtrs[60] = (NULL);
  loggingPtrs[61] = (NULL);
  loggingPtrs[62] = (NULL);
  loggingPtrs[63] = (NULL);
  loggingPtrs[64] = (NULL);
  loggingPtrs[65] = (NULL);
  loggingPtrs[66] = (NULL);
  loggingPtrs[67] = (NULL);
  loggingPtrs[68] = (NULL);
  loggingPtrs[69] = (NULL);
  loggingPtrs[70] = (NULL);
  loggingPtrs[71] = (NULL);
  loggingPtrs[72] = (NULL);
  loggingPtrs[73] = (NULL);
  loggingPtrs[74] = (NULL);
  loggingPtrs[75] = (NULL);
  loggingPtrs[76] = (NULL);
  loggingPtrs[77] = (NULL);
  loggingPtrs[78] = (NULL);
  loggingPtrs[79] = (NULL);
  loggingPtrs[80] = (NULL);
  loggingPtrs[81] = (NULL);
  loggingPtrs[82] = (NULL);
  loggingPtrs[83] = (NULL);
  loggingPtrs[84] = (NULL);
  loggingPtrs[85] = (NULL);
  loggingPtrs[86] = (NULL);
  loggingPtrs[87] = (NULL);
  loggingPtrs[88] = (NULL);
  loggingPtrs[89] = (NULL);
  loggingPtrs[90] = (NULL);
  loggingPtrs[91] = (NULL);
  loggingPtrs[92] = (NULL);
  loggingPtrs[93] = (NULL);
  loggingPtrs[94] = (NULL);
  loggingPtrs[95] = (NULL);
  loggingPtrs[96] = (NULL);
  loggingPtrs[97] = (NULL);
  loggingPtrs[98] = (NULL);
  loggingPtrs[99] = (NULL);
  loggingPtrs[100] = (NULL);
  loggingPtrs[101] = (NULL);
  loggingPtrs[102] = (NULL);
  loggingPtrs[103] = (NULL);
  loggingPtrs[104] = (NULL);
  loggingPtrs[105] = (NULL);
  loggingPtrs[106] = (NULL);
  loggingPtrs[107] = (NULL);
  loggingPtrs[108] = (NULL);
  loggingPtrs[109] = (NULL);
  loggingPtrs[110] = (NULL);
  loggingPtrs[111] = (NULL);
  loggingPtrs[112] = (NULL);
  loggingPtrs[113] = (NULL);
  loggingPtrs[114] = (NULL);
  loggingPtrs[115] = (NULL);
  loggingPtrs[116] = (NULL);
  loggingPtrs[117] = (NULL);
  loggingPtrs[118] = (NULL);
  loggingPtrs[119] = (NULL);
  loggingPtrs[120] = (NULL);
  loggingPtrs[121] = (NULL);
  loggingPtrs[122] = (NULL);
  loggingPtrs[123] = (NULL);
  loggingPtrs[124] = (NULL);
  loggingPtrs[125] = (NULL);
  loggingPtrs[126] = (NULL);
  loggingPtrs[127] = (NULL);
  loggingPtrs[128] = (NULL);
  loggingPtrs[129] = (NULL);
  loggingPtrs[130] = (NULL);
  loggingPtrs[131] = (NULL);
  loggingPtrs[132] = (NULL);
  loggingPtrs[133] = (NULL);
  loggingPtrs[134] = (NULL);
  loggingPtrs[135] = (NULL);
  loggingPtrs[136] = (NULL);
  loggingPtrs[137] = (NULL);
  loggingPtrs[138] = (NULL);
  loggingPtrs[139] = (NULL);
  loggingPtrs[140] = (NULL);
  loggingPtrs[141] = (NULL);
  loggingPtrs[142] = (NULL);
  loggingPtrs[143] = (NULL);
  loggingPtrs[144] = (NULL);
  loggingPtrs[145] = (NULL);
  loggingPtrs[146] = (NULL);
  loggingPtrs[147] = (NULL);
  loggingPtrs[148] = (NULL);
  loggingPtrs[149] = (NULL);
  loggingPtrs[150] = (NULL);
  loggingPtrs[151] = (NULL);
  loggingPtrs[152] = (NULL);
  loggingPtrs[153] = (NULL);
  loggingPtrs[154] = (NULL);
  loggingPtrs[155] = (NULL);
  loggingPtrs[156] = (NULL);
  loggingPtrs[157] = (NULL);
  loggingPtrs[158] = (NULL);
  loggingPtrs[159] = (NULL);
  loggingPtrs[160] = (NULL);
  loggingPtrs[161] = (NULL);
  loggingPtrs[162] = (NULL);
  loggingPtrs[163] = (NULL);
  loggingPtrs[164] = (NULL);
  loggingPtrs[165] = (NULL);
  loggingPtrs[166] = (NULL);
  loggingPtrs[167] = (NULL);
  loggingPtrs[168] = (NULL);
  loggingPtrs[169] = (NULL);
  loggingPtrs[170] = (NULL);
  loggingPtrs[171] = (NULL);
  loggingPtrs[172] = (NULL);
  loggingPtrs[173] = (NULL);
  loggingPtrs[174] = (NULL);
  loggingPtrs[175] = (NULL);
  loggingPtrs[176] = (NULL);
  loggingPtrs[177] = (NULL);
  loggingPtrs[178] = (NULL);
  loggingPtrs[179] = (NULL);
  loggingPtrs[180] = (NULL);
  loggingPtrs[181] = (NULL);
  loggingPtrs[182] = (NULL);
  loggingPtrs[183] = (NULL);
  loggingPtrs[184] = (NULL);
  loggingPtrs[185] = (NULL);
  loggingPtrs[186] = (NULL);
  loggingPtrs[187] = (NULL);
  loggingPtrs[188] = (NULL);
  loggingPtrs[189] = (NULL);
  loggingPtrs[190] = (NULL);
  loggingPtrs[191] = (NULL);
  loggingPtrs[192] = (NULL);
  loggingPtrs[193] = (NULL);
  loggingPtrs[194] = (NULL);
  loggingPtrs[195] = (NULL);
  loggingPtrs[196] = (NULL);
  loggingPtrs[197] = (NULL);
  loggingPtrs[198] = (NULL);
  loggingPtrs[199] = (NULL);
  loggingPtrs[200] = (NULL);
  loggingPtrs[201] = (NULL);
  loggingPtrs[202] = (NULL);
  loggingPtrs[203] = (NULL);
  loggingPtrs[204] = (NULL);
  loggingPtrs[205] = (NULL);
  loggingPtrs[206] = (NULL);
  loggingPtrs[207] = (NULL);
  loggingPtrs[208] = (NULL);
  loggingPtrs[209] = (NULL);
  loggingPtrs[210] = (NULL);
  loggingPtrs[211] = (NULL);
  loggingPtrs[212] = (NULL);
  loggingPtrs[213] = (NULL);
  loggingPtrs[214] = (NULL);
  loggingPtrs[215] = (NULL);
  loggingPtrs[216] = (NULL);
  loggingPtrs[217] = (NULL);
  loggingPtrs[218] = (NULL);
  loggingPtrs[219] = (NULL);
  loggingPtrs[220] = (NULL);
  loggingPtrs[221] = (NULL);
  loggingPtrs[222] = (NULL);
  loggingPtrs[223] = (NULL);
  loggingPtrs[224] = (NULL);
  loggingPtrs[225] = (NULL);
  loggingPtrs[226] = (NULL);
  loggingPtrs[227] = (NULL);
  loggingPtrs[228] = (NULL);
  loggingPtrs[229] = (NULL);
  loggingPtrs[230] = (NULL);
  loggingPtrs[231] = (NULL);
  loggingPtrs[232] = (NULL);
  loggingPtrs[233] = (NULL);
  loggingPtrs[234] = (NULL);
  loggingPtrs[235] = (NULL);
  loggingPtrs[236] = (NULL);
  loggingPtrs[237] = (NULL);
  loggingPtrs[238] = (NULL);
  loggingPtrs[239] = (NULL);
  loggingPtrs[240] = (NULL);
  loggingPtrs[241] = (NULL);
  loggingPtrs[242] = (NULL);
  loggingPtrs[243] = (NULL);
  loggingPtrs[244] = (NULL);
  loggingPtrs[245] = (NULL);
  loggingPtrs[246] = (NULL);
  loggingPtrs[247] = (NULL);
  loggingPtrs[248] = (NULL);
  loggingPtrs[249] = (NULL);
  loggingPtrs[250] = (NULL);
  loggingPtrs[251] = (NULL);
  loggingPtrs[252] = (NULL);
  loggingPtrs[253] = (NULL);
  loggingPtrs[254] = (NULL);
  loggingPtrs[255] = (NULL);
  loggingPtrs[256] = (NULL);
  loggingPtrs[257] = (NULL);
  loggingPtrs[258] = (NULL);
  loggingPtrs[259] = (NULL);
  loggingPtrs[260] = (NULL);
  loggingPtrs[261] = (NULL);
  loggingPtrs[262] = (NULL);
  loggingPtrs[263] = (NULL);
  loggingPtrs[264] = (NULL);
  loggingPtrs[265] = (NULL);
  loggingPtrs[266] = (NULL);
  loggingPtrs[267] = (NULL);
  loggingPtrs[268] = (NULL);
  loggingPtrs[269] = (NULL);
  loggingPtrs[270] = (NULL);
  loggingPtrs[271] = (NULL);
  loggingPtrs[272] = (NULL);
  loggingPtrs[273] = (NULL);
  loggingPtrs[274] = (NULL);
  loggingPtrs[275] = (NULL);
  loggingPtrs[276] = (NULL);
  loggingPtrs[277] = (NULL);
  loggingPtrs[278] = (NULL);
  loggingPtrs[279] = (NULL);
  loggingPtrs[280] = (NULL);
  loggingPtrs[281] = (NULL);
  loggingPtrs[282] = (NULL);
  loggingPtrs[283] = (NULL);
  loggingPtrs[284] = (NULL);
  loggingPtrs[285] = (NULL);
  loggingPtrs[286] = (NULL);
  loggingPtrs[287] = (NULL);
  loggingPtrs[288] = (NULL);
  loggingPtrs[289] = (NULL);
  loggingPtrs[290] = (NULL);
  loggingPtrs[291] = (NULL);
  loggingPtrs[292] = (NULL);
  loggingPtrs[293] = (NULL);
  loggingPtrs[294] = (NULL);
  loggingPtrs[295] = (NULL);
  loggingPtrs[296] = (NULL);
  loggingPtrs[297] = (NULL);
  loggingPtrs[298] = (NULL);
  loggingPtrs[299] = (NULL);
  loggingPtrs[300] = (NULL);
  loggingPtrs[301] = (NULL);
  loggingPtrs[302] = (NULL);
  loggingPtrs[303] = (NULL);
  loggingPtrs[304] = (NULL);
  loggingPtrs[305] = (NULL);
  loggingPtrs[306] = (NULL);
  loggingPtrs[307] = (NULL);
  loggingPtrs[308] = (NULL);
  loggingPtrs[309] = (NULL);
  loggingPtrs[310] = (NULL);
  loggingPtrs[311] = (NULL);
  loggingPtrs[312] = (NULL);
  loggingPtrs[313] = (NULL);
  loggingPtrs[314] = (NULL);
  loggingPtrs[315] = (NULL);
  loggingPtrs[316] = (NULL);
  loggingPtrs[317] = (NULL);
  loggingPtrs[318] = (NULL);
  loggingPtrs[319] = (NULL);
  loggingPtrs[320] = (NULL);
  loggingPtrs[321] = (NULL);
  loggingPtrs[322] = (NULL);
  loggingPtrs[323] = (NULL);
  loggingPtrs[324] = (NULL);
  loggingPtrs[325] = (NULL);
  loggingPtrs[326] = (NULL);
  loggingPtrs[327] = (NULL);
  loggingPtrs[328] = (NULL);
  loggingPtrs[329] = (NULL);
  loggingPtrs[330] = (NULL);
  loggingPtrs[331] = (NULL);
  loggingPtrs[332] = (NULL);
  loggingPtrs[333] = (NULL);
  loggingPtrs[334] = (NULL);
  loggingPtrs[335] = (NULL);
  loggingPtrs[336] = (NULL);
  loggingPtrs[337] = (NULL);
  loggingPtrs[338] = (NULL);
  loggingPtrs[339] = (NULL);
  loggingPtrs[340] = (NULL);
  loggingPtrs[341] = (NULL);
  loggingPtrs[342] = (NULL);
  loggingPtrs[343] = (NULL);
  loggingPtrs[344] = (NULL);
  loggingPtrs[345] = (NULL);
  loggingPtrs[346] = (NULL);
  loggingPtrs[347] = (NULL);
  loggingPtrs[348] = (NULL);
  loggingPtrs[349] = (NULL);
  loggingPtrs[350] = (NULL);
  loggingPtrs[351] = (NULL);
  loggingPtrs[352] = (NULL);
  loggingPtrs[353] = (NULL);
  loggingPtrs[354] = (NULL);
  loggingPtrs[355] = (NULL);
  loggingPtrs[356] = (NULL);
  loggingPtrs[357] = (NULL);
  loggingPtrs[358] = (NULL);
  loggingPtrs[359] = (NULL);
  loggingPtrs[360] = (NULL);
  loggingPtrs[361] = (NULL);
  loggingPtrs[362] = (NULL);
  loggingPtrs[363] = (NULL);
  loggingPtrs[364] = (NULL);
  loggingPtrs[365] = (NULL);
  loggingPtrs[366] = (NULL);
  loggingPtrs[367] = (NULL);
  loggingPtrs[368] = (NULL);
  loggingPtrs[369] = (NULL);
  loggingPtrs[370] = (NULL);
  loggingPtrs[371] = (NULL);
  loggingPtrs[372] = (NULL);
  loggingPtrs[373] = (NULL);
  loggingPtrs[374] = (NULL);
  loggingPtrs[375] = (NULL);
  loggingPtrs[376] = (NULL);
  loggingPtrs[377] = (NULL);
  loggingPtrs[378] = (NULL);
  loggingPtrs[379] = (NULL);
  loggingPtrs[380] = (NULL);
  loggingPtrs[381] = (NULL);
  loggingPtrs[382] = (NULL);
  loggingPtrs[383] = (NULL);
  loggingPtrs[384] = (NULL);
  loggingPtrs[385] = (NULL);
  loggingPtrs[386] = (NULL);
  loggingPtrs[387] = (NULL);
  loggingPtrs[388] = (NULL);
  loggingPtrs[389] = (NULL);
  loggingPtrs[390] = (NULL);
  loggingPtrs[391] = (NULL);
  loggingPtrs[392] = (NULL);
  loggingPtrs[393] = (NULL);
  loggingPtrs[394] = (NULL);
  loggingPtrs[395] = (NULL);
  loggingPtrs[396] = (NULL);
  loggingPtrs[397] = (NULL);
  loggingPtrs[398] = (NULL);
  loggingPtrs[399] = (NULL);
  loggingPtrs[400] = (NULL);
  loggingPtrs[401] = (NULL);
  loggingPtrs[402] = (NULL);
  loggingPtrs[403] = (NULL);
  loggingPtrs[404] = (NULL);
  loggingPtrs[405] = (NULL);
  loggingPtrs[406] = (NULL);
  loggingPtrs[407] = (NULL);
  loggingPtrs[408] = (NULL);
  loggingPtrs[409] = (NULL);
  loggingPtrs[410] = (NULL);
  loggingPtrs[411] = (NULL);
  loggingPtrs[412] = (NULL);
  loggingPtrs[413] = (NULL);
  loggingPtrs[414] = (NULL);
  loggingPtrs[415] = (NULL);
  loggingPtrs[416] = (NULL);
  loggingPtrs[417] = (NULL);
  loggingPtrs[418] = (NULL);
  loggingPtrs[419] = (NULL);
  loggingPtrs[420] = (NULL);
  loggingPtrs[421] = (NULL);
  loggingPtrs[422] = (NULL);
  loggingPtrs[423] = (NULL);
  loggingPtrs[424] = (NULL);
  loggingPtrs[425] = (NULL);
  loggingPtrs[426] = (NULL);
  loggingPtrs[427] = (NULL);
  loggingPtrs[428] = (NULL);
  loggingPtrs[429] = (NULL);
  loggingPtrs[430] = (NULL);
  loggingPtrs[431] = (NULL);
  loggingPtrs[432] = (NULL);
  loggingPtrs[433] = (NULL);
  loggingPtrs[434] = (NULL);
  loggingPtrs[435] = (NULL);
  loggingPtrs[436] = (NULL);
  loggingPtrs[437] = (NULL);
  loggingPtrs[438] = (NULL);
  loggingPtrs[439] = (NULL);
  loggingPtrs[440] = (NULL);
  loggingPtrs[441] = (NULL);
  loggingPtrs[442] = (NULL);
  loggingPtrs[443] = (NULL);
  loggingPtrs[444] = (NULL);
  loggingPtrs[445] = (NULL);
  loggingPtrs[446] = (NULL);
  loggingPtrs[447] = (NULL);
  loggingPtrs[448] = (NULL);
  loggingPtrs[449] = (NULL);
  loggingPtrs[450] = (NULL);
  loggingPtrs[451] = (NULL);
  loggingPtrs[452] = (NULL);
  loggingPtrs[453] = (NULL);
  loggingPtrs[454] = (NULL);
  loggingPtrs[455] = (NULL);
  loggingPtrs[456] = (NULL);
  loggingPtrs[457] = (NULL);
  loggingPtrs[458] = (NULL);
  loggingPtrs[459] = (NULL);
  loggingPtrs[460] = (NULL);
  loggingPtrs[461] = (NULL);
  loggingPtrs[462] = (NULL);
  loggingPtrs[463] = (NULL);
  loggingPtrs[464] = (NULL);
  loggingPtrs[465] = (NULL);
  loggingPtrs[466] = (NULL);
  loggingPtrs[467] = (NULL);
  loggingPtrs[468] = (NULL);
  loggingPtrs[469] = (NULL);
  loggingPtrs[470] = (NULL);
  loggingPtrs[471] = (NULL);
  loggingPtrs[472] = (NULL);
  loggingPtrs[473] = (NULL);
  loggingPtrs[474] = (NULL);
  loggingPtrs[475] = (NULL);
  loggingPtrs[476] = (NULL);
  loggingPtrs[477] = (NULL);
  loggingPtrs[478] = (NULL);
  loggingPtrs[479] = (NULL);
  loggingPtrs[480] = (NULL);
  loggingPtrs[481] = (NULL);
  loggingPtrs[482] = (NULL);
  loggingPtrs[483] = (NULL);
  loggingPtrs[484] = (NULL);
  loggingPtrs[485] = (NULL);
  loggingPtrs[486] = (NULL);
  loggingPtrs[487] = (NULL);
  loggingPtrs[488] = (NULL);
  loggingPtrs[489] = (NULL);
  loggingPtrs[490] = (NULL);
  loggingPtrs[491] = (NULL);
  loggingPtrs[492] = (NULL);
  loggingPtrs[493] = (NULL);
  loggingPtrs[494] = (NULL);
  loggingPtrs[495] = (NULL);
  loggingPtrs[496] = (NULL);
  loggingPtrs[497] = (NULL);
  loggingPtrs[498] = (NULL);
  loggingPtrs[499] = (NULL);
  loggingPtrs[500] = (NULL);
  loggingPtrs[501] = (NULL);
  loggingPtrs[502] = (NULL);
  loggingPtrs[503] = (NULL);
  loggingPtrs[504] = (NULL);
  loggingPtrs[505] = (NULL);
  loggingPtrs[506] = (NULL);
  loggingPtrs[507] = (NULL);
  loggingPtrs[508] = (NULL);
  loggingPtrs[509] = (NULL);
  loggingPtrs[510] = (NULL);
  loggingPtrs[511] = (NULL);
  loggingPtrs[512] = (NULL);
  loggingPtrs[513] = (NULL);
  loggingPtrs[514] = (NULL);
  loggingPtrs[515] = (NULL);
  loggingPtrs[516] = (NULL);
  loggingPtrs[517] = (NULL);
  loggingPtrs[518] = (NULL);
  loggingPtrs[519] = (NULL);
  loggingPtrs[520] = (NULL);
  loggingPtrs[521] = (NULL);
  loggingPtrs[522] = (NULL);
  loggingPtrs[523] = (NULL);
  loggingPtrs[524] = (NULL);
  loggingPtrs[525] = (NULL);
  loggingPtrs[526] = (NULL);
  loggingPtrs[527] = (NULL);
  loggingPtrs[528] = (NULL);
  loggingPtrs[529] = (NULL);
  loggingPtrs[530] = (NULL);
  loggingPtrs[531] = (NULL);
  loggingPtrs[532] = (NULL);
  loggingPtrs[533] = (NULL);
  loggingPtrs[534] = (NULL);
  loggingPtrs[535] = (NULL);
  loggingPtrs[536] = (NULL);
  loggingPtrs[537] = (NULL);
  loggingPtrs[538] = (NULL);
  loggingPtrs[539] = (NULL);
  loggingPtrs[540] = (NULL);
  loggingPtrs[541] = (NULL);
  loggingPtrs[542] = (NULL);
  loggingPtrs[543] = (NULL);
  loggingPtrs[544] = (NULL);
  loggingPtrs[545] = (NULL);
  loggingPtrs[546] = (NULL);
  loggingPtrs[547] = (NULL);
  loggingPtrs[548] = (NULL);
  loggingPtrs[549] = (NULL);
  loggingPtrs[550] = (NULL);
  loggingPtrs[551] = (NULL);
  loggingPtrs[552] = (NULL);
  loggingPtrs[553] = (NULL);
  loggingPtrs[554] = (NULL);
  loggingPtrs[555] = (NULL);
  loggingPtrs[556] = (NULL);
  loggingPtrs[557] = (NULL);
  loggingPtrs[558] = (NULL);
  loggingPtrs[559] = (NULL);
  loggingPtrs[560] = (NULL);
  loggingPtrs[561] = (NULL);
  loggingPtrs[562] = (NULL);
  loggingPtrs[563] = (NULL);
  loggingPtrs[564] = (NULL);
  loggingPtrs[565] = (NULL);
  loggingPtrs[566] = (NULL);
  loggingPtrs[567] = (NULL);
  loggingPtrs[568] = (NULL);
  loggingPtrs[569] = (NULL);
  loggingPtrs[570] = (NULL);
  loggingPtrs[571] = (NULL);
  loggingPtrs[572] = (NULL);
  loggingPtrs[573] = (NULL);
  loggingPtrs[574] = (NULL);
  loggingPtrs[575] = (NULL);
  loggingPtrs[576] = (NULL);
  loggingPtrs[577] = (NULL);
  loggingPtrs[578] = (NULL);
  loggingPtrs[579] = (NULL);
  loggingPtrs[580] = (NULL);
  loggingPtrs[581] = (NULL);
  loggingPtrs[582] = (NULL);
  loggingPtrs[583] = (NULL);
  loggingPtrs[584] = (NULL);
  loggingPtrs[585] = (NULL);
  loggingPtrs[586] = (NULL);
  loggingPtrs[587] = (NULL);
  loggingPtrs[588] = (NULL);
  loggingPtrs[589] = (NULL);
  loggingPtrs[590] = (NULL);
  loggingPtrs[591] = (NULL);
  loggingPtrs[592] = (NULL);
  loggingPtrs[593] = (NULL);
  loggingPtrs[594] = (NULL);
  loggingPtrs[595] = (NULL);
  loggingPtrs[596] = (NULL);
  loggingPtrs[597] = (NULL);
  loggingPtrs[598] = (NULL);
  loggingPtrs[599] = (NULL);
  loggingPtrs[600] = (NULL);
  loggingPtrs[601] = (NULL);
  loggingPtrs[602] = (NULL);
  loggingPtrs[603] = (NULL);
  loggingPtrs[604] = (NULL);
  loggingPtrs[605] = (NULL);
  loggingPtrs[606] = (NULL);
  loggingPtrs[607] = (NULL);
  loggingPtrs[608] = (NULL);
  loggingPtrs[609] = (NULL);
  loggingPtrs[610] = (NULL);
  loggingPtrs[611] = (NULL);
  loggingPtrs[612] = (NULL);
  loggingPtrs[613] = (NULL);
  loggingPtrs[614] = (NULL);
  loggingPtrs[615] = (NULL);
  loggingPtrs[616] = (NULL);
  loggingPtrs[617] = (NULL);
  loggingPtrs[618] = (NULL);
  loggingPtrs[619] = (NULL);
  loggingPtrs[620] = (NULL);
  loggingPtrs[621] = (NULL);
  loggingPtrs[622] = (NULL);
  loggingPtrs[623] = (NULL);
  loggingPtrs[624] = (NULL);
  loggingPtrs[625] = (NULL);
  loggingPtrs[626] = (NULL);
  loggingPtrs[627] = (NULL);
  loggingPtrs[628] = (NULL);
  loggingPtrs[629] = (NULL);
  loggingPtrs[630] = (NULL);
  loggingPtrs[631] = (NULL);
  loggingPtrs[632] = (NULL);
  loggingPtrs[633] = (NULL);
  loggingPtrs[634] = (NULL);
  loggingPtrs[635] = (NULL);
  loggingPtrs[636] = (NULL);
  loggingPtrs[637] = (NULL);
  loggingPtrs[638] = (NULL);
  loggingPtrs[639] = (NULL);
  loggingPtrs[640] = (NULL);
  loggingPtrs[641] = (NULL);
  loggingPtrs[642] = (NULL);
  loggingPtrs[643] = (NULL);
  loggingPtrs[644] = (NULL);
  loggingPtrs[645] = (NULL);
  loggingPtrs[646] = (NULL);
  loggingPtrs[647] = (NULL);
  loggingPtrs[648] = (NULL);
  loggingPtrs[649] = (NULL);
  loggingPtrs[650] = (NULL);
  loggingPtrs[651] = (NULL);
  loggingPtrs[652] = (NULL);
  loggingPtrs[653] = (NULL);
  loggingPtrs[654] = (NULL);
  loggingPtrs[655] = (NULL);
  loggingPtrs[656] = (NULL);
  loggingPtrs[657] = (NULL);
  loggingPtrs[658] = (NULL);
  loggingPtrs[659] = (NULL);
  loggingPtrs[660] = (NULL);
  loggingPtrs[661] = (NULL);
  loggingPtrs[662] = (NULL);
  loggingPtrs[663] = (NULL);
  loggingPtrs[664] = (NULL);
  loggingPtrs[665] = (NULL);
  loggingPtrs[666] = (NULL);
  loggingPtrs[667] = (NULL);
  loggingPtrs[668] = (NULL);
  loggingPtrs[669] = (NULL);
  loggingPtrs[670] = (NULL);
  loggingPtrs[671] = (NULL);
  loggingPtrs[672] = (NULL);
  loggingPtrs[673] = (NULL);
  loggingPtrs[674] = (NULL);
  loggingPtrs[675] = (NULL);
  loggingPtrs[676] = (NULL);
  loggingPtrs[677] = (NULL);
  loggingPtrs[678] = (NULL);
  loggingPtrs[679] = (NULL);
  loggingPtrs[680] = (NULL);
  loggingPtrs[681] = (NULL);
  loggingPtrs[682] = (NULL);
  loggingPtrs[683] = (NULL);
  loggingPtrs[684] = (NULL);
  loggingPtrs[685] = (NULL);
  loggingPtrs[686] = (NULL);
  loggingPtrs[687] = (NULL);
  loggingPtrs[688] = (NULL);
  loggingPtrs[689] = (NULL);
  loggingPtrs[690] = (NULL);
  loggingPtrs[691] = (NULL);
  loggingPtrs[692] = (NULL);
  loggingPtrs[693] = (NULL);
  loggingPtrs[694] = (NULL);
  loggingPtrs[695] = (NULL);
  loggingPtrs[696] = (NULL);
  loggingPtrs[697] = (NULL);
  loggingPtrs[698] = (NULL);
  loggingPtrs[699] = (NULL);
  loggingPtrs[700] = (NULL);
  loggingPtrs[701] = (NULL);
  loggingPtrs[702] = (NULL);
  loggingPtrs[703] = (NULL);
  loggingPtrs[704] = (NULL);
  loggingPtrs[705] = (NULL);
  loggingPtrs[706] = (NULL);
  loggingPtrs[707] = (NULL);
  loggingPtrs[708] = (NULL);
  loggingPtrs[709] = (NULL);
  loggingPtrs[710] = (NULL);
  loggingPtrs[711] = (NULL);
  loggingPtrs[712] = (NULL);
  loggingPtrs[713] = (NULL);
  loggingPtrs[714] = (NULL);
  loggingPtrs[715] = (NULL);
  loggingPtrs[716] = (NULL);
  loggingPtrs[717] = (NULL);
  loggingPtrs[718] = (NULL);
  loggingPtrs[719] = (NULL);
  loggingPtrs[720] = (NULL);
  loggingPtrs[721] = (NULL);
  loggingPtrs[722] = (NULL);
  loggingPtrs[723] = (NULL);
  loggingPtrs[724] = (NULL);
  loggingPtrs[725] = (NULL);
  loggingPtrs[726] = (NULL);
  loggingPtrs[727] = (NULL);
  loggingPtrs[728] = (NULL);
  loggingPtrs[729] = (NULL);
  loggingPtrs[730] = (NULL);
  loggingPtrs[731] = (NULL);
  loggingPtrs[732] = (NULL);
  loggingPtrs[733] = (NULL);
  loggingPtrs[734] = (NULL);
  loggingPtrs[735] = (NULL);
  loggingPtrs[736] = (NULL);
  loggingPtrs[737] = (NULL);
  loggingPtrs[738] = (NULL);
  loggingPtrs[739] = (NULL);
  loggingPtrs[740] = (NULL);
  loggingPtrs[741] = (NULL);
  loggingPtrs[742] = (NULL);
  loggingPtrs[743] = (NULL);
  loggingPtrs[744] = (NULL);
  loggingPtrs[745] = (NULL);
  loggingPtrs[746] = (NULL);
  loggingPtrs[747] = (NULL);
  loggingPtrs[748] = (NULL);
  loggingPtrs[749] = (NULL);
  loggingPtrs[750] = (NULL);
  loggingPtrs[751] = (NULL);
  loggingPtrs[752] = (NULL);
  loggingPtrs[753] = (NULL);
  loggingPtrs[754] = (NULL);
  loggingPtrs[755] = (NULL);
  loggingPtrs[756] = (NULL);
  loggingPtrs[757] = (NULL);
  loggingPtrs[758] = (NULL);
  loggingPtrs[759] = (NULL);
  loggingPtrs[760] = (NULL);
  loggingPtrs[761] = (NULL);
  loggingPtrs[762] = (NULL);
  loggingPtrs[763] = (NULL);
  loggingPtrs[764] = (NULL);
  loggingPtrs[765] = (NULL);
  loggingPtrs[766] = (NULL);
  loggingPtrs[767] = (NULL);
  loggingPtrs[768] = (NULL);
  loggingPtrs[769] = (NULL);
  loggingPtrs[770] = (NULL);
  loggingPtrs[771] = (NULL);
  loggingPtrs[772] = (NULL);
  loggingPtrs[773] = (NULL);
  loggingPtrs[774] = (NULL);
  loggingPtrs[775] = (NULL);
  loggingPtrs[776] = (NULL);
  loggingPtrs[777] = (NULL);
  loggingPtrs[778] = (NULL);
  loggingPtrs[779] = (NULL);
  loggingPtrs[780] = (NULL);
  loggingPtrs[781] = (NULL);
  loggingPtrs[782] = (NULL);
  loggingPtrs[783] = (NULL);
  loggingPtrs[784] = (NULL);
  loggingPtrs[785] = (NULL);
  loggingPtrs[786] = (NULL);
  loggingPtrs[787] = (NULL);
  loggingPtrs[788] = (NULL);
  loggingPtrs[789] = (NULL);
  loggingPtrs[790] = (NULL);
  loggingPtrs[791] = (NULL);
  loggingPtrs[792] = (NULL);
  loggingPtrs[793] = (NULL);
  loggingPtrs[794] = (NULL);
  loggingPtrs[795] = (NULL);
  loggingPtrs[796] = (NULL);
  loggingPtrs[797] = (NULL);
  loggingPtrs[798] = (NULL);
  loggingPtrs[799] = (NULL);
  loggingPtrs[800] = (NULL);
  loggingPtrs[801] = (NULL);
  loggingPtrs[802] = (NULL);
  loggingPtrs[803] = (NULL);
  loggingPtrs[804] = (NULL);
  loggingPtrs[805] = (NULL);
  loggingPtrs[806] = (NULL);
  loggingPtrs[807] = (NULL);
  loggingPtrs[808] = (NULL);
  loggingPtrs[809] = (NULL);
  loggingPtrs[810] = (NULL);
  loggingPtrs[811] = (NULL);
  loggingPtrs[812] = (NULL);
  loggingPtrs[813] = (NULL);
  loggingPtrs[814] = (NULL);
  loggingPtrs[815] = (NULL);
  loggingPtrs[816] = (NULL);
  loggingPtrs[817] = (NULL);
  loggingPtrs[818] = (NULL);
  loggingPtrs[819] = (NULL);
  loggingPtrs[820] = (NULL);
  loggingPtrs[821] = (NULL);
  loggingPtrs[822] = (NULL);
  loggingPtrs[823] = (NULL);
  loggingPtrs[824] = (NULL);
  loggingPtrs[825] = (NULL);
  loggingPtrs[826] = (NULL);
  loggingPtrs[827] = (NULL);
  loggingPtrs[828] = (NULL);
  loggingPtrs[829] = (NULL);
  loggingPtrs[830] = (NULL);
  loggingPtrs[831] = (NULL);
  loggingPtrs[832] = (NULL);
  loggingPtrs[833] = (NULL);
  loggingPtrs[834] = (NULL);
  loggingPtrs[835] = (NULL);
  loggingPtrs[836] = (NULL);
  loggingPtrs[837] = (NULL);
  loggingPtrs[838] = (NULL);
  loggingPtrs[839] = (NULL);
  loggingPtrs[840] = (NULL);
  loggingPtrs[841] = (NULL);
  loggingPtrs[842] = (NULL);
  loggingPtrs[843] = (NULL);
  loggingPtrs[844] = (NULL);
  loggingPtrs[845] = (NULL);
  loggingPtrs[846] = (NULL);
  loggingPtrs[847] = (NULL);
  loggingPtrs[848] = (NULL);
  loggingPtrs[849] = (NULL);
  loggingPtrs[850] = (NULL);
  loggingPtrs[851] = (NULL);
  loggingPtrs[852] = (NULL);
  loggingPtrs[853] = (NULL);
  loggingPtrs[854] = (NULL);
  loggingPtrs[855] = (NULL);
  loggingPtrs[856] = (NULL);
  loggingPtrs[857] = (NULL);
  loggingPtrs[858] = (NULL);
  loggingPtrs[859] = (NULL);
  loggingPtrs[860] = (NULL);
  loggingPtrs[861] = (NULL);
  loggingPtrs[862] = (NULL);
  loggingPtrs[863] = (NULL);
  loggingPtrs[864] = (NULL);
  loggingPtrs[865] = (NULL);
  loggingPtrs[866] = (NULL);
  loggingPtrs[867] = (NULL);
  loggingPtrs[868] = (NULL);
  loggingPtrs[869] = (NULL);
  loggingPtrs[870] = (NULL);
  loggingPtrs[871] = (NULL);
  loggingPtrs[872] = (NULL);
  loggingPtrs[873] = (NULL);
  loggingPtrs[874] = (NULL);
  loggingPtrs[875] = (NULL);
  loggingPtrs[876] = (NULL);
  loggingPtrs[877] = (NULL);
  loggingPtrs[878] = (NULL);
  loggingPtrs[879] = (NULL);
  loggingPtrs[880] = (NULL);
  loggingPtrs[881] = (NULL);
  loggingPtrs[882] = (NULL);
  loggingPtrs[883] = (NULL);
  loggingPtrs[884] = (NULL);
  loggingPtrs[885] = (NULL);
  loggingPtrs[886] = (NULL);
  loggingPtrs[887] = (NULL);
  loggingPtrs[888] = (NULL);
  loggingPtrs[889] = (NULL);
  loggingPtrs[890] = (NULL);
  loggingPtrs[891] = (NULL);
  loggingPtrs[892] = (NULL);
  loggingPtrs[893] = (NULL);
  loggingPtrs[894] = (NULL);
  loggingPtrs[895] = (NULL);
  loggingPtrs[896] = (NULL);
  loggingPtrs[897] = (NULL);
  loggingPtrs[898] = (NULL);
  loggingPtrs[899] = (NULL);
  loggingPtrs[900] = (NULL);
  loggingPtrs[901] = (NULL);
  loggingPtrs[902] = (NULL);
  loggingPtrs[903] = (NULL);
  loggingPtrs[904] = (NULL);
  loggingPtrs[905] = (NULL);
  loggingPtrs[906] = (NULL);
  loggingPtrs[907] = (NULL);
  loggingPtrs[908] = (NULL);
  loggingPtrs[909] = (NULL);
  loggingPtrs[910] = (NULL);
  loggingPtrs[911] = (NULL);
  loggingPtrs[912] = (NULL);
  loggingPtrs[913] = (NULL);
  loggingPtrs[914] = (NULL);
  loggingPtrs[915] = (NULL);
  loggingPtrs[916] = (NULL);
  loggingPtrs[917] = (NULL);
  loggingPtrs[918] = (NULL);
  loggingPtrs[919] = (NULL);
  loggingPtrs[920] = (NULL);
  loggingPtrs[921] = (NULL);
  loggingPtrs[922] = (NULL);
  loggingPtrs[923] = (NULL);
  loggingPtrs[924] = (NULL);
  loggingPtrs[925] = (NULL);
  loggingPtrs[926] = (NULL);
  loggingPtrs[927] = (NULL);
  loggingPtrs[928] = (NULL);
  loggingPtrs[929] = (NULL);
  loggingPtrs[930] = (NULL);
  loggingPtrs[931] = (NULL);
  loggingPtrs[932] = (NULL);
  loggingPtrs[933] = (NULL);
  loggingPtrs[934] = (NULL);
  loggingPtrs[935] = (NULL);
  loggingPtrs[936] = (NULL);
  loggingPtrs[937] = (NULL);
  loggingPtrs[938] = (NULL);
  loggingPtrs[939] = (NULL);
  loggingPtrs[940] = (NULL);
  loggingPtrs[941] = (NULL);
  loggingPtrs[942] = (NULL);
  loggingPtrs[943] = (NULL);
  loggingPtrs[944] = (NULL);
  loggingPtrs[945] = (NULL);
  loggingPtrs[946] = (NULL);
  loggingPtrs[947] = (NULL);
  loggingPtrs[948] = (NULL);
  loggingPtrs[949] = (NULL);
  loggingPtrs[950] = (NULL);
  loggingPtrs[951] = (NULL);
  loggingPtrs[952] = (NULL);
  loggingPtrs[953] = (NULL);
  loggingPtrs[954] = (NULL);
  loggingPtrs[955] = (NULL);
  loggingPtrs[956] = (NULL);
  loggingPtrs[957] = (NULL);
  loggingPtrs[958] = (NULL);
  loggingPtrs[959] = (NULL);
  loggingPtrs[960] = (NULL);
  loggingPtrs[961] = (NULL);
  loggingPtrs[962] = (NULL);
  loggingPtrs[963] = (NULL);
  loggingPtrs[964] = (NULL);
  loggingPtrs[965] = (NULL);
  loggingPtrs[966] = (NULL);
  loggingPtrs[967] = (NULL);
  loggingPtrs[968] = (NULL);
  loggingPtrs[969] = (NULL);
  loggingPtrs[970] = (NULL);
  loggingPtrs[971] = (NULL);
  loggingPtrs[972] = (NULL);
  loggingPtrs[973] = (NULL);
  loggingPtrs[974] = (NULL);
  loggingPtrs[975] = (NULL);
  loggingPtrs[976] = (NULL);
  loggingPtrs[977] = (NULL);
  loggingPtrs[978] = (NULL);
  loggingPtrs[979] = (NULL);
  loggingPtrs[980] = (NULL);
  loggingPtrs[981] = (NULL);
  loggingPtrs[982] = (NULL);
  loggingPtrs[983] = (NULL);
  loggingPtrs[984] = (NULL);
  loggingPtrs[985] = (NULL);
  loggingPtrs[986] = (NULL);
  loggingPtrs[987] = (NULL);
  loggingPtrs[988] = (NULL);
  loggingPtrs[989] = (NULL);
  loggingPtrs[990] = (NULL);
  loggingPtrs[991] = (NULL);
  loggingPtrs[992] = (NULL);
  loggingPtrs[993] = (NULL);
  loggingPtrs[994] = (NULL);
  loggingPtrs[995] = (NULL);
  loggingPtrs[996] = (NULL);
  loggingPtrs[997] = (NULL);
  loggingPtrs[998] = (NULL);
  loggingPtrs[999] = (NULL);
  loggingPtrs[1000] = (NULL);
  loggingPtrs[1001] = (NULL);
  loggingPtrs[1002] = (NULL);
  loggingPtrs[1003] = (NULL);
  loggingPtrs[1004] = (NULL);
  loggingPtrs[1005] = (NULL);
  loggingPtrs[1006] = (NULL);
  loggingPtrs[1007] = (NULL);
  loggingPtrs[1008] = (NULL);
  loggingPtrs[1009] = (NULL);
  loggingPtrs[1010] = (NULL);
  loggingPtrs[1011] = (NULL);
  loggingPtrs[1012] = (NULL);
  loggingPtrs[1013] = (NULL);
  loggingPtrs[1014] = (NULL);
  loggingPtrs[1015] = (NULL);
  loggingPtrs[1016] = (NULL);
  loggingPtrs[1017] = (NULL);
  loggingPtrs[1018] = (NULL);
  loggingPtrs[1019] = (NULL);
  loggingPtrs[1020] = (NULL);
  loggingPtrs[1021] = (NULL);
  loggingPtrs[1022] = (NULL);
  loggingPtrs[1023] = (NULL);
  loggingPtrs[1024] = (NULL);
  loggingPtrs[1025] = (NULL);
  loggingPtrs[1026] = (NULL);
  loggingPtrs[1027] = (NULL);
  loggingPtrs[1028] = (NULL);
  loggingPtrs[1029] = (NULL);
  loggingPtrs[1030] = (NULL);
  loggingPtrs[1031] = (NULL);
  loggingPtrs[1032] = (NULL);
  loggingPtrs[1033] = (NULL);
  loggingPtrs[1034] = (NULL);
  loggingPtrs[1035] = (NULL);
  loggingPtrs[1036] = (NULL);
  loggingPtrs[1037] = (NULL);
  loggingPtrs[1038] = (NULL);
  loggingPtrs[1039] = (NULL);
  loggingPtrs[1040] = (NULL);
  loggingPtrs[1041] = (NULL);
  loggingPtrs[1042] = (NULL);
  loggingPtrs[1043] = (NULL);
  loggingPtrs[1044] = (NULL);
  loggingPtrs[1045] = (NULL);
  loggingPtrs[1046] = (NULL);
  loggingPtrs[1047] = (NULL);
  loggingPtrs[1048] = (NULL);
  loggingPtrs[1049] = (NULL);
  loggingPtrs[1050] = (NULL);
  loggingPtrs[1051] = (NULL);
  loggingPtrs[1052] = (NULL);
  loggingPtrs[1053] = (NULL);
  loggingPtrs[1054] = (NULL);
  loggingPtrs[1055] = (NULL);
  loggingPtrs[1056] = (NULL);
  loggingPtrs[1057] = (NULL);
  loggingPtrs[1058] = (NULL);
  loggingPtrs[1059] = (NULL);
  loggingPtrs[1060] = (NULL);
  loggingPtrs[1061] = (NULL);
  loggingPtrs[1062] = (NULL);
  loggingPtrs[1063] = (NULL);
  loggingPtrs[1064] = (NULL);
  loggingPtrs[1065] = (NULL);
  loggingPtrs[1066] = (NULL);
  loggingPtrs[1067] = (NULL);
  loggingPtrs[1068] = (NULL);
  loggingPtrs[1069] = (NULL);
  loggingPtrs[1070] = (NULL);
  loggingPtrs[1071] = (NULL);
  loggingPtrs[1072] = (NULL);
  loggingPtrs[1073] = (NULL);
  loggingPtrs[1074] = (NULL);
  loggingPtrs[1075] = (NULL);
  loggingPtrs[1076] = (NULL);
  loggingPtrs[1077] = (NULL);
  loggingPtrs[1078] = (NULL);
  loggingPtrs[1079] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "unsigned char", "uint8_T", 0, 0, sizeof(uint8_T), SS_UINT8, 0, 0, 0 },

  { "signed char", "int8_T", 0, 0, sizeof(int8_T), SS_INT8, 0, 0, 0 },

  { "short", "int16_T", 0, 0, sizeof(int16_T), SS_INT16, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 2, 2, 0 },

  { rtwCAPI_VECTOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_VECTOR, 20, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_VECTOR, 24, 2, 0 },

  { rtwCAPI_VECTOR, 26, 2, 0 },

  { rtwCAPI_VECTOR, 28, 2, 0 },

  { rtwCAPI_VECTOR, 30, 2, 0 },

  { rtwCAPI_VECTOR, 32, 2, 0 },

  { rtwCAPI_VECTOR, 34, 2, 0 },

  { rtwCAPI_VECTOR, 36, 2, 0 },

  { rtwCAPI_VECTOR, 38, 2, 0 },

  { rtwCAPI_VECTOR, 40, 2, 0 },

  { rtwCAPI_VECTOR, 42, 2, 0 },

  { rtwCAPI_VECTOR, 44, 2, 0 },

  { rtwCAPI_VECTOR, 46, 2, 0 },

  { rtwCAPI_VECTOR, 48, 2, 0 },

  { rtwCAPI_VECTOR, 50, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 52, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 54, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 56, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 58, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 60, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR_ND, 62, 3, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 65, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 67, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 69, 2, 0 },

  { rtwCAPI_VECTOR, 71, 2, 0 },

  { rtwCAPI_VECTOR, 73, 2, 0 },

  { rtwCAPI_VECTOR, 75, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  5,                                   /* 2 */
  1,                                   /* 3 */
  7,                                   /* 4 */
  1,                                   /* 5 */
  2,                                   /* 6 */
  1,                                   /* 7 */
  3,                                   /* 8 */
  1,                                   /* 9 */
  3,                                   /* 10 */
  3,                                   /* 11 */
  9,                                   /* 12 */
  1,                                   /* 13 */
  1,                                   /* 14 */
  10,                                  /* 15 */
  1,                                   /* 16 */
  11,                                  /* 17 */
  1,                                   /* 18 */
  2,                                   /* 19 */
  22,                                  /* 20 */
  1,                                   /* 21 */
  1,                                   /* 22 */
  8,                                   /* 23 */
  1,                                   /* 24 */
  17,                                  /* 25 */
  1,                                   /* 26 */
  40,                                  /* 27 */
  1,                                   /* 28 */
  3,                                   /* 29 */
  1,                                   /* 30 */
  4,                                   /* 31 */
  17,                                  /* 32 */
  1,                                   /* 33 */
  1,                                   /* 34 */
  6,                                   /* 35 */
  1,                                   /* 36 */
  7,                                   /* 37 */
  1,                                   /* 38 */
  5,                                   /* 39 */
  50,                                  /* 40 */
  1,                                   /* 41 */
  1,                                   /* 42 */
  21,                                  /* 43 */
  1,                                   /* 44 */
  16,                                  /* 45 */
  20,                                  /* 46 */
  1,                                   /* 47 */
  1,                                   /* 48 */
  19,                                  /* 49 */
  1,                                   /* 50 */
  1001,                                /* 51 */
  17,                                  /* 52 */
  17,                                  /* 53 */
  20,                                  /* 54 */
  17,                                  /* 55 */
  19,                                  /* 56 */
  19,                                  /* 57 */
  7,                                   /* 58 */
  5,                                   /* 59 */
  10,                                  /* 60 */
  11,                                  /* 61 */
  10,                                  /* 62 */
  11,                                  /* 63 */
  2,                                   /* 64 */
  8,                                   /* 65 */
  17,                                  /* 66 */
  50,                                  /* 67 */
  17,                                  /* 68 */
  21,                                  /* 69 */
  16,                                  /* 70 */
  1,                                   /* 71 */
  23,                                  /* 72 */
  40,                                  /* 73 */
  1,                                   /* 74 */
  1,                                   /* 75 */
  33                                   /* 76 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.0005, 0.0, 1.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    rtwCAPI_FIX_UNIFORM_SCALING, 8, -7, 0 }
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[1], (const void *) &rtcapiStoredFloats[1],
    0, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    2, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 662,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 372,
    rtModelParameters, 26 },

  { rtBlockStates, 20 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 166238093U,
    3712570954U,
    1648849262U,
    1614708166U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  HSC_Model_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void HSC_Model_InitializeDataMapInfo(RT_MODEL_HSC_Model_T *const HSC_Model_M,
  B_HSC_Model_c_T *localB, DW_HSC_Model_f_T *localDW, X_HSC_Model_n_T *localX)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(HSC_Model_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(HSC_Model_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(HSC_Model_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  HSC_Model_InitializeDataAddr(HSC_Model_M->DataMapInfo.dataAddress, localB,
    localDW, localX);
  rtwCAPI_SetDataAddressMap(HSC_Model_M->DataMapInfo.mmi,
    HSC_Model_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  HSC_Model_InitializeVarDimsAddr(HSC_Model_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(HSC_Model_M->DataMapInfo.mmi,
    HSC_Model_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(HSC_Model_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(HSC_Model_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  HSC_Model_InitializeLoggingFunctions(HSC_Model_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(HSC_Model_M->DataMapInfo.mmi,
    HSC_Model_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(HSC_Model_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(HSC_Model_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(HSC_Model_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void HSC_Model_host_InitializeDataMapInfo(HSC_Model_host_DataMapInfo_T
    *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: HSC_Model_capi.c */
