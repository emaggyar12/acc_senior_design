/*
 * MotMapped_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "MotMapped".
 *
 * Model version              : 1.488
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 00:09:51 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MotMapped_capi_h
#define RTW_HEADER_MotMapped_capi_h
#include "MotMapped.h"

extern void MotMapped_InitializeDataMapInfo(RT_MODEL_MotMapped_T *const
  MotMapped_M, B_MotMapped_c_T *localB, X_MotMapped_n_T *localX);

#endif                                 /* RTW_HEADER_MotMapped_capi_h */

/* EOF: MotMapped_capi.h */
