/*
 * BattHev_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "BattHev".
 *
 * Model version              : 1.5754
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 00:10:03 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_BattHev_types_h_
#define RTW_HEADER_BattHev_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters (default storage) */
typedef struct P_BattHev_T_ P_BattHev_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_BattHev_T RT_MODEL_BattHev_T;

#endif                                 /* RTW_HEADER_BattHev_types_h_ */
