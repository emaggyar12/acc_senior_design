/*
 * Blazer_Plant_Model_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_Plant_Model".
 *
 * Model version              : 1.1070
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 00:11:33 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Blazer_Plant_Model_capi_h
#define RTW_HEADER_Blazer_Plant_Model_capi_h
#include "Blazer_Plant_Model.h"

extern void Blazer_Plant_Model_InitializeDataMapInfo
  (RT_MODEL_Blazer_Plant_Model_T *const Blazer_Plant_Model_M,
   B_Blazer_Plant_Model_c_T *localB, DW_Blazer_Plant_Model_f_T *localDW,
   X_Blazer_Plant_Model_n_T *localX);

#endif                                /* RTW_HEADER_Blazer_Plant_Model_capi_h */

/* EOF: Blazer_Plant_Model_capi.h */
