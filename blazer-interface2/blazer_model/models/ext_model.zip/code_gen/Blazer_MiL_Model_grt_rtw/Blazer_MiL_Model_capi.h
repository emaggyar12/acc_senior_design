/*
 * Blazer_MiL_Model_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_MiL_Model".
 *
 * Model version              : 2.33
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:38:00 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Blazer_MiL_Model_capi_h
#define RTW_HEADER_Blazer_MiL_Model_capi_h
#include "Blazer_MiL_Model.h"

extern void Blazer_MiL_Model_InitializeDataMapInfo(void);

#endif                                 /* RTW_HEADER_Blazer_MiL_Model_capi_h */

/* EOF: Blazer_MiL_Model_capi.h */
