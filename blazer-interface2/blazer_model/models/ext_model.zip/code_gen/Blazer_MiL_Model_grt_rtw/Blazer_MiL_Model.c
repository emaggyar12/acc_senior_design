/*
 * Blazer_MiL_Model.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_MiL_Model".
 *
 * Model version              : 2.33
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:38:00 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#include "Blazer_MiL_Model_capi.h"
#include "Blazer_MiL_Model.h"
#include "Blazer_MiL_Model_private.h"
#include "look1_binlx.h"

rtTimingBridge Blazer_MiL_Model_TimingBrdg;
const CAN_to_Plant Blazer_MiL_Model_rtZCAN_to_Plant = {
  0.0,                                 /* MotorTorque */
  0.0,                                 /* ACCATC_AxlTrqRq */
  0.0                                  /* EngTrqActExtRng */
} ;                                    /* CAN_to_Plant ground */

/* Block signals (default storage) */
B_Blazer_MiL_Model_T Blazer_MiL_Model_B;

/* Continuous states */
X_Blazer_MiL_Model_T Blazer_MiL_Model_X;

/* Periodic continuous states */
PeriodicIndX_Blazer_MiL_Model_T Blazer_MiL_Model_PeriodicIndX;
PeriodicRngX_Blazer_MiL_Model_T Blazer_MiL_Model_PeriodicRngX;

/* Block states (default storage) */
DW_Blazer_MiL_Model_T Blazer_MiL_Model_DW;

/* Real-time model */
RT_MODEL_Blazer_MiL_Model_T Blazer_MiL_Model_M_;
RT_MODEL_Blazer_MiL_Model_T *const Blazer_MiL_Model_M = &Blazer_MiL_Model_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (Blazer_MiL_Model_M->Timing.TaskCounters.TID[2])++;
  if ((Blazer_MiL_Model_M->Timing.TaskCounters.TID[2]) > 999) {/* Sample time: [0.5s, 0.0s] */
    Blazer_MiL_Model_M->Timing.TaskCounters.TID[2] = 0;
  }

  (Blazer_MiL_Model_M->Timing.TaskCounters.TID[3])++;
  if ((Blazer_MiL_Model_M->Timing.TaskCounters.TID[3]) > 1999) {/* Sample time: [1.0s, 0.0s] */
    Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] = 0;
  }
}

/* State reduction function */
void local_stateReduction(real_T* x, int_T* p, int_T n, real_T* r)
{
  int_T i, j;
  for (i = 0, j = 0; i < n; ++i, ++j) {
    int_T k = p[i];
    real_T lb = r[j++];
    real_T xk = x[k]-lb;
    real_T rk = r[j]-lb;
    int_T q = (int_T) floor(xk/rk);
    if (q) {
      x[k] = xk-q*rk+lb;
    }
  }
}

/*
 * This function updates continuous states using the ODE4 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE4_IntgData *id = (ODE4_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T *f3 = id->f[3];
  real_T temp;
  int_T i;
  int_T nXc = 63;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Blazer_MiL_Model_derivatives();

  /* f1 = f(t + (h/2), y + (h/2)*f0) */
  temp = 0.5 * h;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f0[i]);
  }

  rtsiSetT(si, t + temp);
  rtsiSetdX(si, f1);
  Blazer_MiL_Model_step();
  Blazer_MiL_Model_derivatives();

  /* f2 = f(t + (h/2), y + (h/2)*f1) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (temp*f1[i]);
  }

  rtsiSetdX(si, f2);
  Blazer_MiL_Model_step();
  Blazer_MiL_Model_derivatives();

  /* f3 = f(t + h, y + h*f2) */
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (h*f2[i]);
  }

  rtsiSetT(si, tnew);
  rtsiSetdX(si, f3);
  Blazer_MiL_Model_step();
  Blazer_MiL_Model_derivatives();

  /* tnew = t + h
     ynew = y + (h/6)*(f0 + 2*f1 + 2*f2 + 2*f3) */
  temp = h / 6.0;
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + temp*(f0[i] + 2.0*f1[i] + 2.0*f2[i] + f3[i]);
  }

  local_stateReduction(x, rtsiGetPeriodicContStateIndices(si), 1,
                       rtsiGetPeriodicContStateRanges(si));
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Blazer_MiL_Model_step(void)
{
  boolean_T sf_internal_predicateOutput;
  real_T Jerkcost;
  real_T SOCcost;
  real_T DistError;
  real_T b_a;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&Blazer_MiL_Model_M->solverInfo,
                          ((Blazer_MiL_Model_M->Timing.clockTick0+1)*
      Blazer_MiL_Model_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Blazer_MiL_Model_M)) {
    Blazer_MiL_Model_M->Timing.t[0] = rtsiGetT(&Blazer_MiL_Model_M->solverInfo);
  }

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* UnitDelay: '<S19>/Output' */
    Blazer_MiL_Model_B.Output = Blazer_MiL_Model_DW.Output_DSTATE;

    /* MultiPortSwitch: '<S15>/Output' incorporates:
     *  Constant: '<S15>/Vector'
     */
    Blazer_MiL_Model_B.Output_h =
      Blazer_MiL_Model_P.RepeatingSequenceStair1_OutValues[Blazer_MiL_Model_B.Output];

    /* SignalConversion: '<S15>/Out' */
    Blazer_MiL_Model_B.BusCreator.DistanceInfo_RC = Blazer_MiL_Model_B.Output_h;

    /* Memory: '<Root>/Memory1' */
    Blazer_MiL_Model_B.Memory1 = Blazer_MiL_Model_DW.Memory1_PreviousInput;
  }

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
    /* DigitalClock: '<S6>/Drive Cycle Sim Time' */
    Blazer_MiL_Model_B.DriveCycleSimTime =
      ((Blazer_MiL_Model_M->Timing.clockTick3) * 1.0);

    /* MultiPortSwitch: '<S6>/Multiport Switch1' incorporates:
     *  Constant: '<S6>/Drive Cycle Start//Stop'
     *  Constant: '<S6>/Drive Cycle Stop'
     */
    if ((int32_T)Blazer_MiL_Model_P.DriveCycleStartStop_Value == 1) {
      Blazer_MiL_Model_B.MultiportSwitch1 = Blazer_MiL_Model_B.DriveCycleSimTime;
    } else {
      Blazer_MiL_Model_B.MultiportSwitch1 =
        Blazer_MiL_Model_P.DriveCycleStop_Value;
    }

    /* End of MultiPortSwitch: '<S6>/Multiport Switch1' */

    /* Lookup_n-D: '<S6>/HWFET' */
    Blazer_MiL_Model_B.HWFET = look1_binlx(Blazer_MiL_Model_B.MultiportSwitch1,
      Blazer_MiL_Model_P.HWFET_bp01Data, Blazer_MiL_Model_P.HWFET_tableData,
      764U);

    /* Lookup_n-D: '<S6>/UDDS' */
    Blazer_MiL_Model_B.UDDS = look1_binlx(Blazer_MiL_Model_B.MultiportSwitch1,
      Blazer_MiL_Model_P.UDDS_bp01Data, Blazer_MiL_Model_P.UDDS_tableData, 1368U);

    /* Lookup_n-D: '<S6>/USO6' */
    Blazer_MiL_Model_B.USO6 = look1_binlx(Blazer_MiL_Model_B.MultiportSwitch1,
      Blazer_MiL_Model_P.USO6_bp01Data, Blazer_MiL_Model_P.USO6_tableData, 599U);

    /* Lookup_n-D: '<S6>/UT Cycle' */
    Blazer_MiL_Model_B.UTCycle = look1_binlx(Blazer_MiL_Model_B.MultiportSwitch1,
      Blazer_MiL_Model_P.UTCycle_bp01Data, Blazer_MiL_Model_P.UTCycle_tableData,
      599U);

    /* Lookup_n-D: '<S6>/CAVs City' */
    Blazer_MiL_Model_B.CAVsCity = look1_binlx
      (Blazer_MiL_Model_B.MultiportSwitch1, Blazer_MiL_Model_P.CAVsCity_bp01Data,
       Blazer_MiL_Model_P.CAVsCity_tableData, 599U);
  }

  /* FromWorkspace: '<S22>/FromWs' */
  {
    real_T *pDataValues = (real_T *) Blazer_MiL_Model_DW.FromWs_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) Blazer_MiL_Model_DW.FromWs_PWORK.TimePtr;
    int_T currTimeIndex = Blazer_MiL_Model_DW.FromWs_IWORK.PrevIndex;
    real_T t = Blazer_MiL_Model_M->Timing.t[0];

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[7]) {
      currTimeIndex = 6;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    Blazer_MiL_Model_DW.FromWs_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          Blazer_MiL_Model_B.FromWs = pDataValues[currTimeIndex];
        } else {
          Blazer_MiL_Model_B.FromWs = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        Blazer_MiL_Model_B.FromWs = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += 8;
      }
    }
  }

  /* MultiPortSwitch: '<S6>/Multiport Switch' incorporates:
   *  Constant: '<S6>/Drive Cycle Selection'
   */
  switch ((int32_T)Blazer_MiL_Model_P.DriveCycleSelection_Value) {
   case 1:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.HWFET;
    break;

   case 2:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.UDDS;
    break;

   case 3:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.USO6;
    break;

   case 4:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.UTCycle;
    break;

   case 5:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.CAVsCity;
    break;

   default:
    Blazer_MiL_Model_B.MultiportSwitch = Blazer_MiL_Model_B.FromWs;
    break;
  }

  /* End of MultiPortSwitch: '<S6>/Multiport Switch' */

  /* Gain: '<S6>/MPH2MPS' */
  Blazer_MiL_Model_B.MPH2MPS = Blazer_MiL_Model_P.MPH2MPS_Gain *
    Blazer_MiL_Model_B.MultiportSwitch;

  /* BusCreator generated from: '<Root>/Model1' incorporates:
   *  Constant: '<S6>/CAVPCM ACC Enable'
   */
  Blazer_MiL_Model_B.BusConversion_InsertedFor_Model1_at_inport_0_BusCreator1.CAVsCrsCntrlSwStOnSwAct
    = Blazer_MiL_Model_P.CAVPCMACCEnable_Value;
  Blazer_MiL_Model_B.BusConversion_InsertedFor_Model1_at_inport_0_BusCreator1.CAVsCrsCntrlStSetSwAct
    = Blazer_MiL_Model_P.CAVPCMACCEnable_Value;
  Blazer_MiL_Model_B.BusConversion_InsertedFor_Model1_at_inport_0_BusCreator1.Long_Switch
    = Blazer_MiL_Model_P.CAVPCMACCEnable_Value;
  Blazer_MiL_Model_B.BusConversion_InsertedFor_Model1_at_inport_0_BusCreator1.xdotref
    = Blazer_MiL_Model_B.MPH2MPS;

  /* ModelReference generated from: '<Root>/Model1' */
  Blazer_Plant_Model(&(Blazer_MiL_Model_DW.Model1_InstanceData.rtm),
                     &Blazer_MiL_Model_B.BusConversion_InsertedFor_Model1_at_inport_0_BusCreator1,
                     &Blazer_MiL_Model_B.Memory1, ((CAN_to_Plant*)
    &Blazer_MiL_Model_rtZCAN_to_Plant), &Blazer_MiL_Model_B.APP,
                     &Blazer_MiL_Model_B.VehSpdAvgDrvn, &Blazer_MiL_Model_B.Gear,
                     &Blazer_MiL_Model_B.Brake_Pa, &Blazer_MiL_Model_B.xdotref,
                     &Blazer_MiL_Model_B.BPP, &Blazer_MiL_Model_B.BattCurr,
                     &Blazer_MiL_Model_B.BattPwr, &Blazer_MiL_Model_B.BattV,
                     &Blazer_MiL_Model_B.MotTrq, &Blazer_MiL_Model_B.BattSoc,
                     &Blazer_MiL_Model_B.MotPwrElec, &Blazer_MiL_Model_B.MotSpd,
                     &Blazer_MiL_Model_B.EngSpd, &Blazer_MiL_Model_B.EngTrqOut,
                     &Blazer_MiL_Model_B.Model1_o16,
                     &(Blazer_MiL_Model_DW.Model1_InstanceData.rtb),
                     &(Blazer_MiL_Model_DW.Model1_InstanceData.rtdw),
                     &(Blazer_MiL_Model_X.Model1_CSTATE));

  /* Gain: '<S5>/Gain' */
  Blazer_MiL_Model_B.APP_k = Blazer_MiL_Model_P.Gain_Gain_g *
    Blazer_MiL_Model_B.APP;

  /* Clock: '<S13>/Clock7' */
  Blazer_MiL_Model_B.Clock7 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch7' incorporates:
   *  Constant: '<S13>/BPP Fault Switch'
   *  Switch: '<S13>/Switch8'
   */
  if ((int32_T)Blazer_MiL_Model_P.BPPFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.MultiportSwitch7 = Blazer_MiL_Model_B.BPP;
  } else {
    if (Blazer_MiL_Model_B.Clock7 > Blazer_MiL_Model_P.Switch8_Threshold) {
      /* Switch: '<S13>/Switch8' incorporates:
       *  Constant: '<S13>/NewBPP'
       */
      Blazer_MiL_Model_B.Switch8_b = Blazer_MiL_Model_P.NewBPP_Value;
    } else {
      /* Switch: '<S13>/Switch8' */
      Blazer_MiL_Model_B.Switch8_b = Blazer_MiL_Model_B.BPP;
    }

    Blazer_MiL_Model_B.MultiportSwitch7 = Blazer_MiL_Model_B.Switch8_b;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch7' */

  /* Gain: '<S5>/Gain2' */
  Blazer_MiL_Model_B.BusCreator.BPP = Blazer_MiL_Model_P.Gain2_Gain *
    Blazer_MiL_Model_B.MultiportSwitch7;

  /* Clock: '<S13>/Clock6' */
  Blazer_MiL_Model_B.Clock6 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch6' incorporates:
   *  Constant: '<S13>/Gear Fault Switch'
   *  Switch: '<S13>/Switch7'
   */
  if ((int32_T)Blazer_MiL_Model_P.GearFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.MultiportSwitch6 = Blazer_MiL_Model_B.Gear;
  } else {
    if (Blazer_MiL_Model_B.Clock6 > Blazer_MiL_Model_P.Switch7_Threshold) {
      /* Switch: '<S13>/Switch7' incorporates:
       *  Constant: '<S13>/Gear Fault'
       */
      Blazer_MiL_Model_B.Switch7_h = Blazer_MiL_Model_P.GearFault_Value;
    } else {
      /* Switch: '<S13>/Switch7' */
      Blazer_MiL_Model_B.Switch7_h = Blazer_MiL_Model_B.Gear;
    }

    Blazer_MiL_Model_B.MultiportSwitch6 = Blazer_MiL_Model_B.Switch7_h;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch6' */

  /* Clock: '<S13>/Clock3' */
  Blazer_MiL_Model_B.Clock3 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch3' incorporates:
   *  Constant: '<S13>/GFD Fault Switch'
   *  Constant: '<S5>/bms_ground_fault'
   *  Switch: '<S13>/Switch4'
   */
  if ((int32_T)Blazer_MiL_Model_P.GFDFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.gfd =
      Blazer_MiL_Model_P.bms_ground_fault_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock3 > Blazer_MiL_Model_P.Switch4_Threshold) {
      /* Switch: '<S13>/Switch4' incorporates:
       *  Constant: '<S13>/battGFD'
       */
      Blazer_MiL_Model_B.Switch4_g = Blazer_MiL_Model_P.battGFD_Value;
    } else {
      /* Switch: '<S13>/Switch4' incorporates:
       *  Constant: '<S5>/bms_ground_fault'
       */
      Blazer_MiL_Model_B.Switch4_g = Blazer_MiL_Model_P.bms_ground_fault_Value;
    }

    Blazer_MiL_Model_B.BusCreator.gfd = Blazer_MiL_Model_B.Switch4_g;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch3' */

  /* Clock: '<S13>/Clock' */
  Blazer_MiL_Model_B.Clock = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch' incorporates:
   *  Constant: '<S13>/MCU Overheat Fault Switch'
   *  Constant: '<S5>/ThermalIndicator'
   *  Switch: '<S13>/Switch1'
   */
  if ((int32_T)Blazer_MiL_Model_P.MCUOverheatFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.McuThermal =
      Blazer_MiL_Model_P.ThermalIndicator_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock > Blazer_MiL_Model_P.Switch1_Threshold_h) {
      /* Switch: '<S13>/Switch1' incorporates:
       *  Constant: '<S13>/MCUOverheat'
       */
      Blazer_MiL_Model_B.Switch1 = Blazer_MiL_Model_P.MCUOverheat_Value;
    } else {
      /* Switch: '<S13>/Switch1' incorporates:
       *  Constant: '<S5>/ThermalIndicator'
       */
      Blazer_MiL_Model_B.Switch1 = Blazer_MiL_Model_P.ThermalIndicator_Value;
    }

    Blazer_MiL_Model_B.BusCreator.McuThermal = Blazer_MiL_Model_B.Switch1;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch' */

  /* Gain: '<S5>/Gain1' */
  Blazer_MiL_Model_B.BusCreator.MotorSpd = Blazer_MiL_Model_P.Gain1_Gain *
    Blazer_MiL_Model_B.MotSpd;

  /* Clock: '<S13>/Clock4' */
  Blazer_MiL_Model_B.Clock4 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch4' incorporates:
   *  Constant: '<S13>/MtrTrqEst Fault Switch'
   *  Switch: '<S13>/Switch5'
   */
  if ((int32_T)Blazer_MiL_Model_P.MtrTrqEstFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.MotorTrqEst = 0.0;
  } else {
    if (Blazer_MiL_Model_B.Clock4 > Blazer_MiL_Model_P.Switch5_Threshold_d) {
      /* Switch: '<S13>/Switch5' incorporates:
       *  Constant: '<S13>/MotrTrqEst Fault'
       */
      Blazer_MiL_Model_B.Switch5 = Blazer_MiL_Model_P.MotrTrqEstFault_Value;
    } else {
      /* Switch: '<S13>/Switch5' */
      Blazer_MiL_Model_B.Switch5 = 0.0;
    }

    Blazer_MiL_Model_B.BusCreator.MotorTrqEst = Blazer_MiL_Model_B.Switch5;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch4' */

  /* Clock: '<S13>/Clock2' */
  Blazer_MiL_Model_B.Clock2 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch2' incorporates:
   *  Constant: '<S13>/TranshftLvr Fault Switch'
   *  Constant: '<S5>/TrnsShiftLvrPos'
   *  Switch: '<S13>/Switch3'
   */
  if ((int32_T)Blazer_MiL_Model_P.TranshftLvrFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.TrnsShftPos =
      Blazer_MiL_Model_P.TrnsShiftLvrPos_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock2 > Blazer_MiL_Model_P.Switch3_Threshold_b) {
      /* Switch: '<S13>/Switch3' incorporates:
       *  Constant: '<S13>/TrnsPos'
       */
      Blazer_MiL_Model_B.Switch3 = Blazer_MiL_Model_P.TrnsPos_Value;
    } else {
      /* Switch: '<S13>/Switch3' incorporates:
       *  Constant: '<S5>/TrnsShiftLvrPos'
       */
      Blazer_MiL_Model_B.Switch3 = Blazer_MiL_Model_P.TrnsShiftLvrPos_Value;
    }

    Blazer_MiL_Model_B.BusCreator.TrnsShftPos = Blazer_MiL_Model_B.Switch3;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch2' */

  /* Gain: '<S5>/m//s2kph' */
  Blazer_MiL_Model_B.ms2kph = Blazer_MiL_Model_P.ms2kph_Gain *
    Blazer_MiL_Model_B.VehSpdAvgDrvn;

  /* Clock: '<S13>/Clock8' */
  Blazer_MiL_Model_B.Clock8 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch8' incorporates:
   *  Constant: '<S13>/PwrTrainDirection Fault Switch'
   *  Switch: '<S13>/Switch9'
   */
  if ((int32_T)Blazer_MiL_Model_P.PwrTrainDirectionFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.VehSpd = Blazer_MiL_Model_B.ms2kph;
  } else {
    if (Blazer_MiL_Model_B.Clock8 > Blazer_MiL_Model_P.Switch9_Threshold) {
      /* Gain: '<S13>/Gain' incorporates:
       *  Switch: '<S13>/Switch9'
       */
      Blazer_MiL_Model_B.Gain = Blazer_MiL_Model_P.Gain_Gain *
        Blazer_MiL_Model_B.ms2kph;

      /* Switch: '<S13>/Switch9' */
      Blazer_MiL_Model_B.Switch9 = Blazer_MiL_Model_B.Gain;
    } else {
      /* Switch: '<S13>/Switch9' */
      Blazer_MiL_Model_B.Switch9 = Blazer_MiL_Model_B.ms2kph;
    }

    Blazer_MiL_Model_B.BusCreator.VehSpd = Blazer_MiL_Model_B.Switch9;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch8' */

  /* Clock: '<S13>/Clock1' */
  Blazer_MiL_Model_B.Clock1 = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch1' incorporates:
   *  Constant: '<S13>/Battery Overheat Fault Switch'
   *  Constant: '<S5>/bms_t_coolant'
   *  Switch: '<S13>/Switch2'
   */
  if ((int32_T)Blazer_MiL_Model_P.BatteryOverheatFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.BusCreator.battTcoolant =
      Blazer_MiL_Model_P.bms_t_coolant_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock1 > Blazer_MiL_Model_P.Switch2_Threshold) {
      /* Switch: '<S13>/Switch2' incorporates:
       *  Constant: '<S13>/BattTemp1'
       */
      Blazer_MiL_Model_B.Switch2_n = Blazer_MiL_Model_P.BattTemp1_Value;
    } else {
      /* Switch: '<S13>/Switch2' incorporates:
       *  Constant: '<S5>/bms_t_coolant'
       */
      Blazer_MiL_Model_B.Switch2_n = Blazer_MiL_Model_P.bms_t_coolant_Value;
    }

    Blazer_MiL_Model_B.BusCreator.battTcoolant = Blazer_MiL_Model_B.Switch2_n;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch1' */

  /* Clock: '<S5>/Clock3' */
  Blazer_MiL_Model_B.Clock3_h = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock2' */
  Blazer_MiL_Model_B.Clock2_a = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock' */
  Blazer_MiL_Model_B.Clock_f = Blazer_MiL_Model_M->Timing.t[0];

  /* Switch: '<S5>/Switch4' incorporates:
   *  Constant: '<S5>/Constant17'
   *  Switch: '<S5>/Switch1'
   *  Switch: '<S5>/Switch3'
   */
  if (Blazer_MiL_Model_B.Clock3_h > Blazer_MiL_Model_P.Switch4_Threshold_h) {
    Blazer_MiL_Model_B.Switch4 = Blazer_MiL_Model_P.Constant17_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock2_a > Blazer_MiL_Model_P.Switch3_Threshold) {
      /* Switch: '<S5>/Switch3' incorporates:
       *  Constant: '<S5>/Constant16'
       */
      Blazer_MiL_Model_B.Switch3_b = Blazer_MiL_Model_P.Constant16_Value;
    } else {
      if (Blazer_MiL_Model_B.Clock_f > Blazer_MiL_Model_P.Switch1_Threshold) {
        /* Switch: '<S5>/Switch1' incorporates:
         *  Constant: '<S5>/Constant14'
         *  Switch: '<S5>/Switch3'
         */
        Blazer_MiL_Model_B.Switch1_g = Blazer_MiL_Model_P.Constant14_Value;
      } else {
        /* Switch: '<S5>/Switch1' incorporates:
         *  Constant: '<S5>/Constant13'
         *  Switch: '<S5>/Switch3'
         */
        Blazer_MiL_Model_B.Switch1_g = Blazer_MiL_Model_P.Constant13_Value;
      }

      /* Switch: '<S5>/Switch3' */
      Blazer_MiL_Model_B.Switch3_b = Blazer_MiL_Model_B.Switch1_g;
    }

    Blazer_MiL_Model_B.Switch4 = Blazer_MiL_Model_B.Switch3_b;
  }

  /* End of Switch: '<S5>/Switch4' */

  /* DataTypeConversion: '<S5>/Cast To Boolean' */
  Blazer_MiL_Model_B.BusCreator.dist_is_valid = (Blazer_MiL_Model_B.Switch4 !=
    0.0);

  /* Clock: '<S5>/Clock1' */
  Blazer_MiL_Model_B.Clock1_k = Blazer_MiL_Model_M->Timing.t[0];

  /* Switch: '<S5>/Switch2' incorporates:
   *  Constant: '<S5>/Constant12'
   *  Constant: '<S5>/Constant15'
   */
  if (Blazer_MiL_Model_B.Clock1_k > Blazer_MiL_Model_P.Switch2_Threshold_o) {
    Blazer_MiL_Model_B.Switch2 = Blazer_MiL_Model_P.Constant12_Value;
  } else {
    Blazer_MiL_Model_B.Switch2 = Blazer_MiL_Model_P.Constant15_Value;
  }

  /* End of Switch: '<S5>/Switch2' */

  /* DataTypeConversion: '<S5>/Cast To Boolean1' */
  Blazer_MiL_Model_B.BusCreator.TrafficLightPresent =
    (Blazer_MiL_Model_B.Switch2 != 0.0);

  /* Clock: '<S5>/Clock8' */
  Blazer_MiL_Model_B.Clock8_g = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock6' */
  Blazer_MiL_Model_B.Clock6_m = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock5' */
  Blazer_MiL_Model_B.Clock5 = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock7' */
  Blazer_MiL_Model_B.Clock7_a = Blazer_MiL_Model_M->Timing.t[0];

  /* Clock: '<S5>/Clock4' */
  Blazer_MiL_Model_B.Clock4_c = Blazer_MiL_Model_M->Timing.t[0];

  /* Switch: '<S5>/Switch7' incorporates:
   *  Switch: '<S5>/Switch5'
   *  Switch: '<S5>/Switch6'
   */
  if (Blazer_MiL_Model_B.Clock6_m > Blazer_MiL_Model_P.Switch7_Threshold_l) {
    /* Sum: '<S5>/Minus1' incorporates:
     *  Constant: '<S5>/Constant21'
     */
    Blazer_MiL_Model_B.Minus1 = Blazer_MiL_Model_P.Constant21_Value -
      Blazer_MiL_Model_B.Clock8_g;
    Blazer_MiL_Model_B.BusCreator.DistanceToIntersection =
      Blazer_MiL_Model_B.Minus1;
  } else {
    if (Blazer_MiL_Model_B.Clock5 > Blazer_MiL_Model_P.Switch6_Threshold) {
      /* Switch: '<S5>/Switch6' incorporates:
       *  Constant: '<S5>/Constant20'
       */
      Blazer_MiL_Model_B.Switch6_j = Blazer_MiL_Model_P.Constant20_Value;
    } else {
      if (Blazer_MiL_Model_B.Clock4_c > Blazer_MiL_Model_P.Switch5_Threshold) {
        /* Sum: '<S5>/Minus' incorporates:
         *  Constant: '<S5>/Constant19'
         *  Switch: '<S5>/Switch5'
         *  Switch: '<S5>/Switch6'
         */
        Blazer_MiL_Model_B.Minus = Blazer_MiL_Model_P.Constant19_Value -
          Blazer_MiL_Model_B.Clock7_a;

        /* Switch: '<S5>/Switch5' incorporates:
         *  Switch: '<S5>/Switch6'
         */
        Blazer_MiL_Model_B.Switch5_e = Blazer_MiL_Model_B.Minus;
      } else {
        /* Switch: '<S5>/Switch5' incorporates:
         *  Constant: '<S5>/Constant18'
         *  Switch: '<S5>/Switch6'
         */
        Blazer_MiL_Model_B.Switch5_e = Blazer_MiL_Model_P.Constant18_Value;
      }

      /* Switch: '<S5>/Switch6' */
      Blazer_MiL_Model_B.Switch6_j = Blazer_MiL_Model_B.Switch5_e;
    }

    Blazer_MiL_Model_B.BusCreator.DistanceToIntersection =
      Blazer_MiL_Model_B.Switch6_j;
  }

  /* End of Switch: '<S5>/Switch7' */
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Memory: '<Root>/Memory' */
    Blazer_MiL_Model_B.Memory = Blazer_MiL_Model_DW.Memory_PreviousInput;
  }

  /* ModelReference generated from: '<Root>/Model' */
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0 || rtmIsMajorTimeStep
      (Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
    HSC_Model(&(Blazer_MiL_Model_DW.Model_InstanceData.rtm),
              &Blazer_MiL_Model_B.Memory.ABSAtv, &Blazer_MiL_Model_B.Memory.APP,
              &Blazer_MiL_Model_B.Memory.APPv, &Blazer_MiL_Model_B.Memory.BPP,
              &Blazer_MiL_Model_B.Memory.EngRunAtv,
              &Blazer_MiL_Model_B.Memory.EngSpd, &Blazer_MiL_Model_B.Memory.Gear,
              &Blazer_MiL_Model_B.Memory.HdSt, &Blazer_MiL_Model_B.Memory.KeySt,
              &Blazer_MiL_Model_B.Memory.gfd,
              &Blazer_MiL_Model_B.Memory.McuThermal,
              &Blazer_MiL_Model_B.Memory.MotorSpd,
              &Blazer_MiL_Model_B.Memory.MotorTrqEst,
              &Blazer_MiL_Model_B.Memory.SOC,
              &Blazer_MiL_Model_B.Memory.StateMcu,
              &Blazer_MiL_Model_B.Memory.StrWhAng,
              &Blazer_MiL_Model_B.Memory.StrWhAngV,
              &Blazer_MiL_Model_B.Memory.TrnsShftPos,
              &Blazer_MiL_Model_B.Memory.VehSpd,
              &Blazer_MiL_Model_B.Memory.battTcoolant,
              &Blazer_MiL_Model_B.Memory.bcmready,
              &Blazer_MiL_Model_B.Memory.cpwrcmd,
              &Blazer_MiL_Model_B.Memory.cpwrmon,
              &Blazer_MiL_Model_B.Memory.hvilmon,
              &Blazer_MiL_Model_B.Memory.ibat,
              &Blazer_MiL_Model_B.Memory.maincstat,
              &Blazer_MiL_Model_B.Memory.vbat, &Blazer_MiL_Model_B.Memory.vehmon,
              &Blazer_MiL_Model_B.Memory.ICESwitch,
              &Blazer_MiL_Model_B.Memory.RegenSwitch,
              &Blazer_MiL_Model_B.Memory.CAVsCrsLmtrSwStat,
              &Blazer_MiL_Model_B.Memory.CAVsCrsCntrlSwStOnSwAct,
              &Blazer_MiL_Model_B.Memory.CAVsCrsCntrlStSetSwAct,
              &Blazer_MiL_Model_B.Memory.Long_Switch,
              &Blazer_MiL_Model_B.Memory.TCSysAtv,
              &Blazer_MiL_Model_B.Memory.MotorRC,
              &Blazer_MiL_Model_B.Memory.DrvIntndAxlTrqMax,
              &Blazer_MiL_Model_B.Memory.DrvIntndAxlTrqMin,
              &Blazer_MiL_Model_B.Memory.TrqReqStat,
              &Blazer_MiL_Model_B.Memory.xdotref,
              &Blazer_MiL_Model_B.Memory.ACCBrakeTime,
              &Blazer_MiL_Model_B.Memory.CAVtrgVel,
              &Blazer_MiL_Model_B.Memory.CAVtrgDist,
              &Blazer_MiL_Model_B.Memory.grade,
              &Blazer_MiL_Model_B.Memory.Tanh_Exponent,
              &Blazer_MiL_Model_B.Memory.Tanh_multiplier,
              &Blazer_MiL_Model_B.Memory.dist_is_valid,
              &Blazer_MiL_Model_B.Memory.TrafficLightPresent,
              &Blazer_MiL_Model_B.Memory.DistanceToIntersection,
              &Blazer_MiL_Model_B.Memory.TimeToNextState,
              &Blazer_MiL_Model_B.Memory.CurrentState,
              &Blazer_MiL_Model_B.Memory.Decel_Division_Value,
              &Blazer_MiL_Model_B.Memory.bcm_coolan_temp_C,
              &Blazer_MiL_Model_B.Memory.DistanceObjValid,
              &Blazer_MiL_Model_B.Memory.TimeGap,
              &Blazer_MiL_Model_B.Memory.TransEstGear,
              &Blazer_MiL_Model_B.Memory.SwitchToLinearOnlyMotorFadeOut,
              &Blazer_MiL_Model_B.Memory.CrsSecSwStat, &Blazer_MiL_Model_B.Model,
              &(Blazer_MiL_Model_DW.Model_InstanceData.rtb),
              &(Blazer_MiL_Model_DW.Model_InstanceData.rtdw));
  }

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Chart: '<S5>/Chart' */
    if (Blazer_MiL_Model_DW.temporalCounter_i1 < 4095U) {
      Blazer_MiL_Model_DW.temporalCounter_i1++;
    }

    /* Gateway: Subsystem3/Chart */
    /* During: Subsystem3/Chart */
    if (Blazer_MiL_Model_DW.is_active_c1_Blazer_MiL_Model == 0U) {
      /* Entry: Subsystem3/Chart */
      Blazer_MiL_Model_DW.is_active_c1_Blazer_MiL_Model = 1U;

      /* Entry Internal: Subsystem3/Chart */
      /* Transition: '<S12>:3' */
      Blazer_MiL_Model_DW.temporalCounter_i1 = 0U;

      /* Entry 'Enter': '<S12>:2' */
      /* '<S12>:2:3' EstimatedGear=CommandedGear; */
      Blazer_MiL_Model_B.BusCreator.TransEstGear =
        Blazer_MiL_Model_B.MultiportSwitch6;

      /* '<S12>:2:4' CommandedLatch=CommandedGear; */
      Blazer_MiL_Model_DW.CommandedLatch = Blazer_MiL_Model_B.MultiportSwitch6;
    } else {
      /* During 'Enter': '<S12>:2' */
      /* '<S12>:8:1' sf_internal_predicateOutput = CommandedGear<CommandedLatch || CommandedGear>CommandedLatch; */
      sf_internal_predicateOutput = ((Blazer_MiL_Model_B.MultiportSwitch6 <
        Blazer_MiL_Model_DW.CommandedLatch) ||
        (Blazer_MiL_Model_B.MultiportSwitch6 >
         Blazer_MiL_Model_DW.CommandedLatch));
      if (sf_internal_predicateOutput && (Blazer_MiL_Model_DW.temporalCounter_i1
           >= 3000U)) {
        /* Transition: '<S12>:8' */
        /* '<S12>:9:1' sf_internal_predicateOutput = after(1.5,sec); */
        /* Transition: '<S12>:9' */
        Blazer_MiL_Model_DW.temporalCounter_i1 = 0U;

        /* Entry 'Enter': '<S12>:2' */
        /* '<S12>:2:3' EstimatedGear=CommandedGear; */
        Blazer_MiL_Model_B.BusCreator.TransEstGear =
          Blazer_MiL_Model_B.MultiportSwitch6;

        /* '<S12>:2:4' CommandedLatch=CommandedGear; */
        Blazer_MiL_Model_DW.CommandedLatch = Blazer_MiL_Model_B.MultiportSwitch6;
      }
    }

    /* End of Chart: '<S5>/Chart' */

    /* UnitDelay: '<S16>/Output' */
    Blazer_MiL_Model_B.Output_k = Blazer_MiL_Model_DW.Output_DSTATE_n;

    /* MultiPortSwitch: '<S14>/Output' incorporates:
     *  Constant: '<S14>/Vector'
     */
    Blazer_MiL_Model_B.Output_f =
      Blazer_MiL_Model_P.RepeatingSequenceStair_OutValues[Blazer_MiL_Model_B.Output_k];

    /* SignalConversion: '<S14>/Out' */
    Blazer_MiL_Model_B.BusCreator.TrafficInfo_RC = Blazer_MiL_Model_B.Output_f;
  }

  /* BusCreator: '<S5>/Bus Creator' incorporates:
   *  Constant: '<S5>/ABSAtv'
   *  Constant: '<S5>/APP_validity'
   *  Constant: '<S5>/Constant1'
   *  Constant: '<S5>/Constant10'
   *  Constant: '<S5>/Constant11'
   *  Constant: '<S5>/Constant2'
   *  Constant: '<S5>/Constant22'
   *  Constant: '<S5>/Constant23'
   *  Constant: '<S5>/Constant24'
   *  Constant: '<S5>/Constant25'
   *  Constant: '<S5>/Constant26'
   *  Constant: '<S5>/Constant27'
   *  Constant: '<S5>/Constant28'
   *  Constant: '<S5>/Constant29'
   *  Constant: '<S5>/Constant3'
   *  Constant: '<S5>/Constant30'
   *  Constant: '<S5>/Constant31'
   *  Constant: '<S5>/Constant4'
   *  Constant: '<S5>/Constant5'
   *  Constant: '<S5>/Constant6'
   *  Constant: '<S5>/Constant7'
   *  Constant: '<S5>/Constant8'
   *  Constant: '<S5>/Constant9'
   *  Constant: '<S5>/EngRunAtv'
   *  Constant: '<S5>/Hood_state'
   *  Constant: '<S5>/Key_status'
   *  Constant: '<S5>/StateMcu'
   *  Constant: '<S5>/StrWhAng'
   *  Constant: '<S5>/StrWhAngV'
   *  Constant: '<S5>/SwitchMotorFadeOut'
   *  Constant: '<S5>/bms_cpwr_cmd'
   *  Constant: '<S5>/bms_cpwr_mon'
   *  Constant: '<S5>/bms_hvil_mon'
   *  Constant: '<S5>/bms_mainc_stat'
   *  Constant: '<S5>/bms_ready'
   *  Constant: '<S5>/bms_veh_mon'
   */
  Blazer_MiL_Model_B.BusCreator.ABSAtv = Blazer_MiL_Model_P.ABSAtv_Value;
  Blazer_MiL_Model_B.BusCreator.APP = Blazer_MiL_Model_B.APP_k;
  Blazer_MiL_Model_B.BusCreator.APPv = Blazer_MiL_Model_P.APP_validity_Value;
  Blazer_MiL_Model_B.BusCreator.EngRunAtv = Blazer_MiL_Model_P.EngRunAtv_Value;
  Blazer_MiL_Model_B.BusCreator.EngSpd = Blazer_MiL_Model_B.EngSpd;
  Blazer_MiL_Model_B.BusCreator.Gear = Blazer_MiL_Model_B.MultiportSwitch6;
  Blazer_MiL_Model_B.BusCreator.HdSt = Blazer_MiL_Model_P.Hood_state_Value;
  Blazer_MiL_Model_B.BusCreator.KeySt = Blazer_MiL_Model_P.Key_status_Value;
  Blazer_MiL_Model_B.BusCreator.SOC = Blazer_MiL_Model_B.BattSoc;
  Blazer_MiL_Model_B.BusCreator.StateMcu = Blazer_MiL_Model_P.StateMcu_Value;
  Blazer_MiL_Model_B.BusCreator.StrWhAng = Blazer_MiL_Model_P.StrWhAng_Value;
  Blazer_MiL_Model_B.BusCreator.StrWhAngV = Blazer_MiL_Model_P.StrWhAngV_Value;
  Blazer_MiL_Model_B.BusCreator.bcmready = Blazer_MiL_Model_P.bms_ready_Value;
  Blazer_MiL_Model_B.BusCreator.cpwrcmd = Blazer_MiL_Model_P.bms_cpwr_cmd_Value;
  Blazer_MiL_Model_B.BusCreator.cpwrmon = Blazer_MiL_Model_P.bms_cpwr_mon_Value;
  Blazer_MiL_Model_B.BusCreator.hvilmon = Blazer_MiL_Model_P.bms_hvil_mon_Value;
  Blazer_MiL_Model_B.BusCreator.ibat = Blazer_MiL_Model_B.BattCurr;
  Blazer_MiL_Model_B.BusCreator.maincstat =
    Blazer_MiL_Model_P.bms_mainc_stat_Value;
  Blazer_MiL_Model_B.BusCreator.vbat = Blazer_MiL_Model_B.BattV;
  Blazer_MiL_Model_B.BusCreator.vehmon = Blazer_MiL_Model_P.bms_veh_mon_Value;
  Blazer_MiL_Model_B.BusCreator.ICESwitch = Blazer_MiL_Model_P.Constant2_Value;
  Blazer_MiL_Model_B.BusCreator.RegenSwitch = Blazer_MiL_Model_P.Constant1_Value;
  Blazer_MiL_Model_B.BusCreator.CAVsCrsLmtrSwStat =
    Blazer_MiL_Model_P.Constant3_Value;
  Blazer_MiL_Model_B.BusCreator.CAVsCrsCntrlSwStOnSwAct = 0.0;
  Blazer_MiL_Model_B.BusCreator.CAVsCrsCntrlStSetSwAct = 0.0;
  Blazer_MiL_Model_B.BusCreator.Long_Switch =
    Blazer_MiL_Model_P.Constant31_Value;
  Blazer_MiL_Model_B.BusCreator.TCSysAtv = 0.0;
  Blazer_MiL_Model_B.BusCreator.MotorRC = 0.0;
  Blazer_MiL_Model_B.BusCreator.DrvIntndAxlTrqMax = 0.0;
  Blazer_MiL_Model_B.BusCreator.DrvIntndAxlTrqMin = 0.0;
  Blazer_MiL_Model_B.BusCreator.TrqReqStat = 0.0;
  Blazer_MiL_Model_B.BusCreator.xdotref = Blazer_MiL_Model_B.xdotref;
  Blazer_MiL_Model_B.BusCreator.ACCBrakeTime =
    Blazer_MiL_Model_P.Constant4_Value;
  Blazer_MiL_Model_B.BusCreator.CAVtrgVel = 0.0;
  Blazer_MiL_Model_B.BusCreator.CAVtrgDist = 0.0;
  Blazer_MiL_Model_B.BusCreator.grade = Blazer_MiL_Model_P.Constant5_Value;
  Blazer_MiL_Model_B.BusCreator.Tanh_Exponent =
    Blazer_MiL_Model_P.Constant6_Value;
  Blazer_MiL_Model_B.BusCreator.Tanh_multiplier =
    Blazer_MiL_Model_P.Constant7_Value;
  Blazer_MiL_Model_B.BusCreator.TimeToNextState =
    Blazer_MiL_Model_P.Constant23_Value;
  Blazer_MiL_Model_B.BusCreator.CurrentState =
    Blazer_MiL_Model_P.Constant22_Value;
  Blazer_MiL_Model_B.BusCreator.Decel_Division_Value =
    Blazer_MiL_Model_P.Constant8_Value;
  Blazer_MiL_Model_B.BusCreator.bcm_coolan_temp_C =
    Blazer_MiL_Model_P.Constant9_Value;
  Blazer_MiL_Model_B.BusCreator.DistanceObjValid =
    Blazer_MiL_Model_P.Constant10_Value;
  Blazer_MiL_Model_B.BusCreator.TimeGap = Blazer_MiL_Model_P.Constant11_Value;
  Blazer_MiL_Model_B.BusCreator.ActualAxleTrq =
    Blazer_MiL_Model_P.Constant25_Value;
  Blazer_MiL_Model_B.BusCreator.MotorShiftCompensation =
    Blazer_MiL_Model_P.Constant26_Value;
  Blazer_MiL_Model_B.BusCreator.ACCModeRegenOn =
    Blazer_MiL_Model_P.Constant27_Value;
  Blazer_MiL_Model_B.BusCreator.DirectDistanceLookupTableSwitch =
    Blazer_MiL_Model_P.Constant28_Value;
  Blazer_MiL_Model_B.BusCreator.SetSpeedLookupTableSwitch =
    Blazer_MiL_Model_P.Constant29_Value;
  Blazer_MiL_Model_B.BusCreator.TorqueMapSwitch =
    Blazer_MiL_Model_P.Constant30_Value;
  Blazer_MiL_Model_B.BusCreator.SwitchToLinearOnlyMotorFadeOut =
    Blazer_MiL_Model_P.SwitchMotorFadeOut_Value;
  Blazer_MiL_Model_B.BusCreator.CrsSecSwStat =
    Blazer_MiL_Model_P.Constant24_Value;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Sum: '<S17>/FixPt Sum1' incorporates:
     *  Constant: '<S17>/FixPt Constant'
     */
    Blazer_MiL_Model_B.FixPtSum1 = (uint8_T)((uint32_T)
      Blazer_MiL_Model_B.Output_k + Blazer_MiL_Model_P.FixPtConstant_Value);

    /* Switch: '<S18>/FixPt Switch' incorporates:
     *  Constant: '<S18>/Constant'
     */
    if (Blazer_MiL_Model_B.FixPtSum1 > Blazer_MiL_Model_P.LimitedCounter_uplimit)
    {
      Blazer_MiL_Model_B.FixPtSwitch = Blazer_MiL_Model_P.Constant_Value;
    } else {
      Blazer_MiL_Model_B.FixPtSwitch = Blazer_MiL_Model_B.FixPtSum1;
    }

    /* End of Switch: '<S18>/FixPt Switch' */

    /* SignalConversion generated from: '<S1>/Bus Selector' */
    Blazer_MiL_Model_B.APP_o = Blazer_MiL_Model_B.Memory.APP;

    /* SignalConversion generated from: '<S1>/Bus Selector' */
    Blazer_MiL_Model_B.BPP_f = Blazer_MiL_Model_B.Memory.BPP;

    /* Gain: '<S1>/Gain' */
    Blazer_MiL_Model_B.APP_p = Blazer_MiL_Model_P.Gain_Gain_h *
      Blazer_MiL_Model_B.APP_o;

    /* SignalConversion generated from: '<S1>/Bus Selector1' */
    Blazer_MiL_Model_B.ACC_APP = Blazer_MiL_Model_B.Memory1.ACC_APP;

    /* Gain: '<S1>/Gain1' */
    Blazer_MiL_Model_B.APPACC = Blazer_MiL_Model_P.Gain1_Gain_j *
      Blazer_MiL_Model_B.ACC_APP;
  }

  /* SignalConversion generated from: '<Root>/Bus Selector' */
  Blazer_MiL_Model_B.VehSpd_mph = Blazer_MiL_Model_B.Model1_o16.VehSpd_mph;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
    /* Gain: '<S1>/mph2ms' */
    Blazer_MiL_Model_B.xdot = Blazer_MiL_Model_P.mph2ms_Gain *
      Blazer_MiL_Model_B.VehSpd_mph;

    /* RateTransition: '<S1>/Rate Transition' */
    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
      Blazer_MiL_Model_B.RateTransition = Blazer_MiL_Model_B.xdot;
    }

    /* End of RateTransition: '<S1>/Rate Transition' */

    /* SampleTimeMath: '<S7>/TSamp'
     *
     * About '<S7>/TSamp':
     *  y = u * K where K = 1 / ( w * Ts )
     *  Multiplication by K = weightedTsampQuantized is being
     *  done implicitly by changing the scaling of the input signal.
     *  No work needs to be done here.  Downstream blocks may need
     *  to do work to handle the scaling of the output; this happens
     *  automatically.
     */
    Blazer_MiL_Model_B.TSamp = Blazer_MiL_Model_B.RateTransition;

    /* UnitDelay: '<S7>/UD' */
    Blazer_MiL_Model_B.Uk1 = Blazer_MiL_Model_DW.UD_DSTATE;

    /* Sum: '<S7>/Diff' */
    Blazer_MiL_Model_B.Diff = Blazer_MiL_Model_B.TSamp - Blazer_MiL_Model_B.Uk1;
  }

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* SignalConversion generated from: '<S1>/Bus Selector1' */
    Blazer_MiL_Model_B.SafeDist = Blazer_MiL_Model_B.Memory1.SafeDist;

    /* SignalConversion generated from: '<S1>/Bus Selector1' */
    Blazer_MiL_Model_B.RelDist = Blazer_MiL_Model_B.Memory1.RelDist;
  }

  /* MATLAB Function: '<S1>/MATLAB Function1' */
  Blazer_MiL_Model_B.Jerksim = Blazer_MiL_Model_B.Diff;

  /* MATLAB Function 'ACC Tuning/MATLAB Function1': '<S8>:1' */
  /* '<S8>:1:6' w1=0.3; */
  /* '<S8>:1:7' w2=0.5; */
  /* '<S8>:1:8' w3=0.2; */
  /* '<S8>:1:11' if SOC >= 70 && SOC <= 90 */
  if ((Blazer_MiL_Model_B.Model1_o16.BattSOC >= 70.0) &&
      (Blazer_MiL_Model_B.Model1_o16.BattSOC <= 90.0)) {
    /* '<S8>:1:12' SOCcost=((SOC-70)./(90-20))^2; */
    b_a = (Blazer_MiL_Model_B.Model1_o16.BattSOC - 70.0) / 70.0;
    SOCcost = b_a * b_a;
  } else if ((Blazer_MiL_Model_B.Model1_o16.BattSOC <= 30.0) &&
             (Blazer_MiL_Model_B.Model1_o16.BattSOC >= 20.0)) {
    /* '<S8>:1:13' elseif SOC <= 30 && SOC>= 20 */
    /* '<S8>:1:14' SOCcost=((30-SOC)./(30-20))^2; */
    b_a = (30.0 - Blazer_MiL_Model_B.Model1_o16.BattSOC) / 10.0;
    SOCcost = b_a * b_a;
  } else if ((Blazer_MiL_Model_B.Model1_o16.BattSOC > 30.0) &&
             (Blazer_MiL_Model_B.Model1_o16.BattSOC < 70.0)) {
    /* '<S8>:1:15' elseif SOC > 30 && SOC < 70 */
    /* '<S8>:1:16' SOCcost=0; */
    SOCcost = 0.0;
  } else {
    /* '<S8>:1:17' else */
    /* '<S8>:1:18' SOCcost=800000; */
    SOCcost = 800000.0;
  }

  /* '<S8>:1:22' if Jerksim >=-5.5 && Jerksim<=0 */
  if ((Blazer_MiL_Model_B.Jerksim >= -5.5) && (Blazer_MiL_Model_B.Jerksim <= 0.0))
  {
    /* '<S8>:1:23' Jerkcost=abs(((0+Jerksim)./(-5))); */
    Jerkcost = fabs(Blazer_MiL_Model_B.Jerksim / -5.0);
  } else if ((Blazer_MiL_Model_B.Jerksim >= 0.0) && (Blazer_MiL_Model_B.Jerksim <=
              4.5)) {
    /* '<S8>:1:24' elseif Jerksim >=0 && Jerksim <=4.5 */
    /* '<S8>:1:25' Jerkcost=((3-Jerksim)./(3)); */
    Jerkcost = (3.0 - Blazer_MiL_Model_B.Jerksim) / 3.0;
  } else {
    /* '<S8>:1:26' else */
    /* '<S8>:1:27' Jerkcost=500000; */
    Jerkcost = 500000.0;
  }

  /* '<S8>:1:34' Fuelcost=1-(BattFuel/TotFuel); */
  b_a = 1.0 - Blazer_MiL_Model_B.Model1_o16.Fuelout.BattFuel /
    Blazer_MiL_Model_B.Model1_o16.Fuelout.TotFuel;

  /* '<S8>:1:37' DistError=SafeDist-RelDist; */
  DistError = Blazer_MiL_Model_B.SafeDist - Blazer_MiL_Model_B.RelDist;

  /* '<S8>:1:39' if DistError>-7 && DistError<=6 */
  if ((DistError > -7.0) && (DistError <= 6.0)) {
    /* '<S8>:1:40' Cost=w1*Fuelcost+w2*Jerkcost+w3*SOCcost; */
    Blazer_MiL_Model_B.Cost = (0.3 * b_a + 0.5 * Jerkcost) + 0.2 * SOCcost;
  } else {
    /* '<S8>:1:41' else */
    /* '<S8>:1:42' Cost=60000; */
    Blazer_MiL_Model_B.Cost = 60000.0;
  }

  Blazer_MiL_Model_B.Jerkcost = Jerkcost;
  Blazer_MiL_Model_B.SOCcost = SOCcost;
  Blazer_MiL_Model_B.Fuelcost = b_a;

  /* End of MATLAB Function: '<S1>/MATLAB Function1' */
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Sum: '<S1>/Sum' */
    Blazer_MiL_Model_B.Sum = Blazer_MiL_Model_B.SafeDist -
      Blazer_MiL_Model_B.RelDist;
  }

  /* SignalConversion generated from: '<Root>/Bus Selector' */
  Blazer_MiL_Model_B.RefSpd_mph = Blazer_MiL_Model_B.Model1_o16.RefSpd_mph;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
  }

  /* Sum: '<S1>/Sum1' */
  Blazer_MiL_Model_B.Sum1 = Blazer_MiL_Model_B.RefSpd_mph -
    Blazer_MiL_Model_B.VehSpd_mph;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
  }

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.VehSpd_mph_g = Blazer_MiL_Model_B.Model1_o16.VehSpd_mph;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.RefSpd_mph_g = Blazer_MiL_Model_B.Model1_o16.RefSpd_mph;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.EngSpd_rpm = Blazer_MiL_Model_B.Model1_o16.EngSpd_rpm;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.MotSpd_rpm = Blazer_MiL_Model_B.Model1_o16.MotSpd_rpm;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.EngTrq_Nm = Blazer_MiL_Model_B.Model1_o16.EngTrq_Nm;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.MotTrq_Nm = Blazer_MiL_Model_B.Model1_o16.MotTrq_Nm;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.BattCurr_A = Blazer_MiL_Model_B.Model1_o16.BattCurr_A;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.BattSOC = Blazer_MiL_Model_B.Model1_o16.BattSOC;

  /* SignalConversion generated from: '<S6>/Bus Selector2' */
  Blazer_MiL_Model_B.FuelEcon_mpge = Blazer_MiL_Model_B.Model1_o16.FuelEcon_mpge;
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Switch: '<S5>/Switch8' incorporates:
     *  Constant: '<S5>/Constant32'
     *  Constant: '<S6>/CAVPCM ACC Enable'
     */
    if (Blazer_MiL_Model_P.CAVPCMACCEnable_Value >
        Blazer_MiL_Model_P.Switch8_Threshold_o) {
      Blazer_MiL_Model_B.Switch8 = Blazer_MiL_Model_P.Constant32_Value;
    } else {
      Blazer_MiL_Model_B.Switch8 = 0.0;
    }

    /* End of Switch: '<S5>/Switch8' */

    /* Switch: '<S5>/Switch9' incorporates:
     *  Constant: '<S5>/Constant33'
     *  Constant: '<S6>/CAVPCM ACC Enable'
     */
    if (Blazer_MiL_Model_P.CAVPCMACCEnable_Value >
        Blazer_MiL_Model_P.Switch9_Threshold_m) {
      Blazer_MiL_Model_B.BPP_k = Blazer_MiL_Model_P.Constant33_Value;
    } else {
      Blazer_MiL_Model_B.BPP_k = 0.0;
    }

    /* End of Switch: '<S5>/Switch9' */

    /* SignalConversion generated from: '<S1>/Bus Selector1' */
    Blazer_MiL_Model_B.ACCPIDOut = Blazer_MiL_Model_B.Memory1.ACCPIDOut;

    /* SignalConversion generated from: '<S1>/Bus Selector1' */
    Blazer_MiL_Model_B.DistError = Blazer_MiL_Model_B.Memory1.DistError;

    /* UnaryMinus: '<S1>/Unary Minus3' */
    Blazer_MiL_Model_B.DistError_m = -Blazer_MiL_Model_B.DistError;

    /* Sum: '<S6>/Add' */
    Blazer_MiL_Model_B.Add = Blazer_MiL_Model_B.Memory1.EngAxleTrqDmd +
      Blazer_MiL_Model_B.Memory1.McuTorqueCommand;

    /* SignalConversion generated from: '<S6>/Bus Selector1' */
    Blazer_MiL_Model_B.TrqDmdPedalMap =
      Blazer_MiL_Model_B.Memory1.TrqDmdPedalMap;

    /* Sum: '<S20>/FixPt Sum1' incorporates:
     *  Constant: '<S20>/FixPt Constant'
     */
    Blazer_MiL_Model_B.FixPtSum1_c = (uint8_T)((uint32_T)
      Blazer_MiL_Model_B.Output + Blazer_MiL_Model_P.FixPtConstant_Value_i);

    /* Switch: '<S21>/FixPt Switch' incorporates:
     *  Constant: '<S21>/Constant'
     */
    if (Blazer_MiL_Model_B.FixPtSum1_c >
        Blazer_MiL_Model_P.LimitedCounter_uplimit_l) {
      Blazer_MiL_Model_B.FixPtSwitch_g = Blazer_MiL_Model_P.Constant_Value_b;
    } else {
      Blazer_MiL_Model_B.FixPtSwitch_g = Blazer_MiL_Model_B.FixPtSum1_c;
    }

    /* End of Switch: '<S21>/FixPt Switch' */
  }

  /* Clock: '<S13>/Clock5' */
  Blazer_MiL_Model_B.Clock5_g = Blazer_MiL_Model_M->Timing.t[0];

  /* MultiPortSwitch: '<S13>/Multiport Switch5' incorporates:
   *  Constant: '<S13>/GFD leakage Fault Switch'
   *  Constant: '<S5>/HV_leakage_ena'
   *  Switch: '<S13>/Switch6'
   */
  if ((int32_T)Blazer_MiL_Model_P.GFDleakageFaultSwitch_Value == 1) {
    Blazer_MiL_Model_B.MultiportSwitch5 =
      Blazer_MiL_Model_P.HV_leakage_ena_Value;
  } else {
    if (Blazer_MiL_Model_B.Clock5_g > Blazer_MiL_Model_P.Switch6_Threshold_l) {
      /* Switch: '<S13>/Switch6' incorporates:
       *  Constant: '<S13>/leakageEna'
       */
      Blazer_MiL_Model_B.Switch6 = Blazer_MiL_Model_P.leakageEna_Value;
    } else {
      /* Switch: '<S13>/Switch6' incorporates:
       *  Constant: '<S5>/HV_leakage_ena'
       */
      Blazer_MiL_Model_B.Switch6 = Blazer_MiL_Model_P.HV_leakage_ena_Value;
    }

    Blazer_MiL_Model_B.MultiportSwitch5 = Blazer_MiL_Model_B.Switch6;
  }

  /* End of MultiPortSwitch: '<S13>/Multiport Switch5' */
  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
      Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
    /* Constant: '<S6>/A123Relay' */
    Blazer_MiL_Model_B.A123Relay = Blazer_MiL_Model_P.A123Relay_Value;

    /* Constant: '<S6>/BMS12VRelay' */
    Blazer_MiL_Model_B.BMS12VRelay = Blazer_MiL_Model_P.BMS12VRelay_Value;

    /* Constant: '<S6>/HVPumpRelay' */
    Blazer_MiL_Model_B.HVPumpRelay = Blazer_MiL_Model_P.HVPumpRelay_Value;

    /* Constant: '<S6>/MCURelay' */
    Blazer_MiL_Model_B.MCURelay = Blazer_MiL_Model_P.MCURelay_Value;
  }

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M)) {
    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
      /* Update for UnitDelay: '<S19>/Output' */
      Blazer_MiL_Model_DW.Output_DSTATE = Blazer_MiL_Model_B.FixPtSwitch_g;

      /* Update for Memory: '<Root>/Memory1' */
      Blazer_MiL_Model_DW.Memory1_PreviousInput = Blazer_MiL_Model_B.Model;
    }

    /* Update for ModelReference generated from: '<Root>/Model1' */
    Blazer_Plant_Model_Update(&(Blazer_MiL_Model_DW.Model1_InstanceData.rtm),
      &Blazer_MiL_Model_B.VehSpdAvgDrvn,
      &(Blazer_MiL_Model_DW.Model1_InstanceData.rtb),
      &(Blazer_MiL_Model_DW.Model1_InstanceData.rtdw));
    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[1] == 0) {
      /* Update for Memory: '<Root>/Memory' */
      Blazer_MiL_Model_DW.Memory_PreviousInput = Blazer_MiL_Model_B.BusCreator;

      /* Update for UnitDelay: '<S16>/Output' */
      Blazer_MiL_Model_DW.Output_DSTATE_n = Blazer_MiL_Model_B.FixPtSwitch;
    }

    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
      /* Update for UnitDelay: '<S7>/UD' */
      Blazer_MiL_Model_DW.UD_DSTATE = Blazer_MiL_Model_B.TSamp;
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(Blazer_MiL_Model_M)) {
    rt_ertODEUpdateContinuousStates(&Blazer_MiL_Model_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++Blazer_MiL_Model_M->Timing.clockTick0;
    Blazer_MiL_Model_M->Timing.t[0] = rtsiGetSolverStopTime
      (&Blazer_MiL_Model_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.0005s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.0005, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      Blazer_MiL_Model_M->Timing.clockTick1++;
    }

    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[2] == 0) {
      /* Update absolute timer for sample time: [0.5s, 0.0s] */
      /* The "clockTick2" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.5, which is the step size
       * of the task. Size of "clockTick2" ensures timer will not overflow during the
       * application lifespan selected.
       */
      Blazer_MiL_Model_M->Timing.clockTick2++;
    }

    if (rtmIsMajorTimeStep(Blazer_MiL_Model_M) &&
        Blazer_MiL_Model_M->Timing.TaskCounters.TID[3] == 0) {
      /* Update absolute timer for sample time: [1.0s, 0.0s] */
      /* The "clockTick3" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 1.0, which is the step size
       * of the task. Size of "clockTick3" ensures timer will not overflow during the
       * application lifespan selected.
       */
      Blazer_MiL_Model_M->Timing.clockTick3++;
    }

    rate_scheduler();
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Blazer_MiL_Model_derivatives(void)
{
  /* Derivatives for ModelReference generated from: '<Root>/Model1' */
  Blazer_Plant_Model_Deriv(&Blazer_MiL_Model_B.xdotref,
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtb),
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtdw),
    &(Blazer_MiL_Model_X.Model1_CSTATE), &(((XDot_Blazer_MiL_Model_T *)
    Blazer_MiL_Model_M->derivs)->Model1_CSTATE));
}

/* Model initialize function */
void Blazer_MiL_Model_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)Blazer_MiL_Model_M, 0,
                sizeof(RT_MODEL_Blazer_MiL_Model_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Blazer_MiL_Model_M->solverInfo,
                          &Blazer_MiL_Model_M->Timing.simTimeStep);
    rtsiSetTPtr(&Blazer_MiL_Model_M->solverInfo, &rtmGetTPtr(Blazer_MiL_Model_M));
    rtsiSetStepSizePtr(&Blazer_MiL_Model_M->solverInfo,
                       &Blazer_MiL_Model_M->Timing.stepSize0);
    rtsiSetdXPtr(&Blazer_MiL_Model_M->solverInfo, &Blazer_MiL_Model_M->derivs);
    rtsiSetContStatesPtr(&Blazer_MiL_Model_M->solverInfo, (real_T **)
                         &Blazer_MiL_Model_M->contStates);
    rtsiSetNumContStatesPtr(&Blazer_MiL_Model_M->solverInfo,
      &Blazer_MiL_Model_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Blazer_MiL_Model_M->solverInfo,
      &Blazer_MiL_Model_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Blazer_MiL_Model_M->solverInfo,
      &Blazer_MiL_Model_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Blazer_MiL_Model_M->solverInfo,
      &Blazer_MiL_Model_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Blazer_MiL_Model_M->solverInfo, (&rtmGetErrorStatus
      (Blazer_MiL_Model_M)));
    rtsiSetRTModelPtr(&Blazer_MiL_Model_M->solverInfo, Blazer_MiL_Model_M);
  }

  rtsiSetSimTimeStep(&Blazer_MiL_Model_M->solverInfo, MAJOR_TIME_STEP);
  Blazer_MiL_Model_M->intgData.y = Blazer_MiL_Model_M->odeY;
  Blazer_MiL_Model_M->intgData.f[0] = Blazer_MiL_Model_M->odeF[0];
  Blazer_MiL_Model_M->intgData.f[1] = Blazer_MiL_Model_M->odeF[1];
  Blazer_MiL_Model_M->intgData.f[2] = Blazer_MiL_Model_M->odeF[2];
  Blazer_MiL_Model_M->intgData.f[3] = Blazer_MiL_Model_M->odeF[3];
  Blazer_MiL_Model_M->contStates = ((X_Blazer_MiL_Model_T *) &Blazer_MiL_Model_X);
  Blazer_MiL_Model_M->periodicContStateIndices = ((int_T*)
    Blazer_MiL_Model_PeriodicIndX);
  Blazer_MiL_Model_M->periodicContStateRanges = ((real_T*)
    Blazer_MiL_Model_PeriodicRngX);
  rtsiSetSolverData(&Blazer_MiL_Model_M->solverInfo, (void *)
                    &Blazer_MiL_Model_M->intgData);
  rtsiSetSolverName(&Blazer_MiL_Model_M->solverInfo,"ode4");
  rtmSetTPtr(Blazer_MiL_Model_M, &Blazer_MiL_Model_M->Timing.tArray[0]);
  Blazer_MiL_Model_M->Timing.stepSize0 = 0.0005;
  rtmSetFirstInitCond(Blazer_MiL_Model_M, 1);

  /* block I/O */
  (void) memset(((void *) &Blazer_MiL_Model_B), 0,
                sizeof(B_Blazer_MiL_Model_T));

  /* states (continuous) */
  {
    (void) memset((void *)&Blazer_MiL_Model_X, 0,
                  sizeof(X_Blazer_MiL_Model_T));
  }

  /* Periodic continuous states */
  {
    (void) memset((void*) Blazer_MiL_Model_PeriodicIndX, 0,
                  1*sizeof(int_T));
    (void) memset((void*) Blazer_MiL_Model_PeriodicRngX, 0,
                  2*sizeof(real_T));
  }

  /* states (dwork) */
  (void) memset((void *)&Blazer_MiL_Model_DW, 0,
                sizeof(DW_Blazer_MiL_Model_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  Blazer_MiL_Model_InitializeDataMapInfo();

  {
    static uint32_T *clockTickPtrs[4];
    static real_T *taskTimePtrs[4];
    static uint32_T *taskCounterPtrs;
    Blazer_MiL_Model_TimingBrdg.nTasks = 4;
    clockTickPtrs[0] = &(Blazer_MiL_Model_M->Timing.clockTick0);
    clockTickPtrs[1] = &(Blazer_MiL_Model_M->Timing.clockTick1);
    clockTickPtrs[2] = &(Blazer_MiL_Model_M->Timing.clockTick2);
    clockTickPtrs[3] = &(Blazer_MiL_Model_M->Timing.clockTick3);
    Blazer_MiL_Model_TimingBrdg.clockTick = clockTickPtrs;
    Blazer_MiL_Model_TimingBrdg.clockTickH = (NULL);
    taskCounterPtrs = &(Blazer_MiL_Model_M->Timing.TaskCounters.TID[0]);
    Blazer_MiL_Model_TimingBrdg.taskCounter = taskCounterPtrs;
    taskTimePtrs[0] = &(Blazer_MiL_Model_M->Timing.t[0]);
    taskTimePtrs[1] = (NULL);
    taskTimePtrs[2] = (NULL);
    taskTimePtrs[3] = (NULL);
    Blazer_MiL_Model_TimingBrdg.taskTime = taskTimePtrs;
    Blazer_MiL_Model_TimingBrdg.firstInitCond = &rtmIsFirstInitCond
      (Blazer_MiL_Model_M);
  }

  /* Model Initialize function for ModelReference Block: '<Root>/Model' */
  HSC_Model_initialize(rtmGetErrorStatusPointer(Blazer_MiL_Model_M),
                       &Blazer_MiL_Model_TimingBrdg, 1, 3,
                       &(Blazer_MiL_Model_DW.Model_InstanceData.rtm),
                       &(Blazer_MiL_Model_DW.Model_InstanceData.rtb),
                       &(Blazer_MiL_Model_DW.Model_InstanceData.rtdw),
                       &(Blazer_MiL_Model_M->DataMapInfo.mmi),
                       "Blazer_MiL_Model/Model", 0, -1);

  /* Model Initialize function for ModelReference Block: '<Root>/Model1' */
  Blazer_Plant_Model_initialize(rtmGetErrorStatusPointer(Blazer_MiL_Model_M),
    rtmGetStopRequestedPtr(Blazer_MiL_Model_M), &(Blazer_MiL_Model_M->solverInfo),
    &Blazer_MiL_Model_TimingBrdg, 0, 1, 2,
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtm),
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtb),
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtdw),
    &(Blazer_MiL_Model_X.Model1_CSTATE), &(Blazer_MiL_Model_M->DataMapInfo.mmi),
    "Blazer_MiL_Model/Model1", 1, 0);

  /* Start for FromWorkspace: '<S22>/FromWs' */
  {
    static real_T pTimeValues0[] = { 0.0, 1.0, 1.0, 20.0, 20.0, 50.0, 50.0, 60.0
    } ;

    static real_T pDataValues0[] = { 0.0, 0.0, 22.352, 22.352, 31.2928, 31.2928,
      0.0, 0.0 } ;

    Blazer_MiL_Model_DW.FromWs_PWORK.TimePtr = (void *) pTimeValues0;
    Blazer_MiL_Model_DW.FromWs_PWORK.DataPtr = (void *) pDataValues0;
    Blazer_MiL_Model_DW.FromWs_IWORK.PrevIndex = 0;
  }

  /* InitializeConditions for UnitDelay: '<S19>/Output' */
  Blazer_MiL_Model_DW.Output_DSTATE = Blazer_MiL_Model_P.Output_InitialCondition;

  /* InitializeConditions for Memory: '<Root>/Memory1' */
  Blazer_MiL_Model_DW.Memory1_PreviousInput =
    Blazer_MiL_Model_P.Memory1_InitialCondition;

  /* InitializeConditions for Memory: '<Root>/Memory' */
  Blazer_MiL_Model_DW.Memory_PreviousInput =
    Blazer_MiL_Model_P.Memory_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S16>/Output' */
  Blazer_MiL_Model_DW.Output_DSTATE_n =
    Blazer_MiL_Model_P.Output_InitialCondition_d;

  /* InitializeConditions for UnitDelay: '<S7>/UD' */
  Blazer_MiL_Model_DW.UD_DSTATE =
    Blazer_MiL_Model_P.DiscreteDerivative3_ICPrevScaledInput;

  /* SystemInitialize for ModelReference generated from: '<Root>/Model1' */
  Blazer_Plant_Model_Init(&Blazer_MiL_Model_B.Gear,
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtb),
    &(Blazer_MiL_Model_DW.Model1_InstanceData.rtdw),
    &(Blazer_MiL_Model_X.Model1_CSTATE));

  /* SystemInitialize for ModelReference generated from: '<Root>/Model' */
  HSC_Model_Init(&(Blazer_MiL_Model_DW.Model_InstanceData.rtb),
                 &(Blazer_MiL_Model_DW.Model_InstanceData.rtdw));

  /* SystemInitialize for Chart: '<S5>/Chart' */
  Blazer_MiL_Model_DW.temporalCounter_i1 = 0U;
  Blazer_MiL_Model_DW.is_active_c1_Blazer_MiL_Model = 0U;

  /* InitializeConditions for root-level periodic continuous states */
  {
    int_T rootPeriodicContStateIndices[1] = { 3 };

    real_T rootPeriodicContStateRanges[2] = { 0.0, 720.0 };

    (void) memcpy((void*)Blazer_MiL_Model_PeriodicIndX,
                  rootPeriodicContStateIndices,
                  1*sizeof(int_T));
    (void) memcpy((void*)Blazer_MiL_Model_PeriodicRngX,
                  rootPeriodicContStateRanges,
                  2*sizeof(real_T));
  }

  /* set "at time zero" to false */
  if (rtmIsFirstInitCond(Blazer_MiL_Model_M)) {
    rtmSetFirstInitCond(Blazer_MiL_Model_M, 0);
  }
}

/* Model terminate function */
void Blazer_MiL_Model_terminate(void)
{
  /* Terminate for ModelReference generated from: '<Root>/Model' */
  HSC_Model_Term(&(Blazer_MiL_Model_DW.Model_InstanceData.rtdw));
}
