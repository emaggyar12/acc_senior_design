/*
 * look1_pbinlca.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_Plant_Model".
 *
 * Model version              : 1.1068
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:30:39 2022
 * Created for block: Blazer_Plant_Model
 */

#ifndef SHARE_look1_pbinlca
#define SHARE_look1_pbinlca
#include "rtwtypes.h"

extern real_T look1_pbinlca(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T prevIndex[], uint32_T maxIndex);

#endif
