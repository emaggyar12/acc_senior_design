/*
 * binsearch_u32d_prevIdx.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 1.983
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:10:46 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef SHARE_binsearch_u32d_prevIdx
#define SHARE_binsearch_u32d_prevIdx
#include "rtwtypes.h"

extern uint32_T binsearch_u32d_prevIdx(real_T u, const real_T bp[], uint32_T
  startIndex, uint32_T maxIndex);

#endif
