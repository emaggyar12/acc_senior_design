/*
 * PadeApproximantOfDegree_ljwalVOO.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_Plant_Model".
 *
 * Model version              : 1.1068
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:12:37 2022
 * Created for block: Blazer_Plant_Model
 */

#ifndef SHARE_PadeApproximantOfDegree_ljwalVOO
#define SHARE_PadeApproximantOfDegree_ljwalVOO
#include "rtwtypes.h"

extern void PadeApproximantOfDegree_ljwalVOO(const real_T A[4], uint8_T m,
  real_T F[4]);

#endif
