/*
 * look1_binlc.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 1.983
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:28:35 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef SHARE_look1_binlc
#define SHARE_look1_binlc
#include "rtwtypes.h"

extern real_T look1_binlc(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif
