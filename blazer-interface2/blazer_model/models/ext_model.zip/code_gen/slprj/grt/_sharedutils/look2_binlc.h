/*
 * look2_binlc.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiEngineController".
 *
 * Model version              : 1.667
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:29:00 2022
 * Created for block: SiEngineController
 */

#ifndef SHARE_look2_binlc
#define SHARE_look2_binlc
#include "rtwtypes.h"

extern real_T look2_binlc(real_T u0, real_T u1, const real_T bp0[], const real_T
  bp1[], const real_T table[], const uint32_T maxIndex[], uint32_T stride);

#endif
