/*
 * LookUp_real_T_real_T.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HSC_Model".
 *
 * Model version              : 1.266
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:12:00 2022
 * Created for block: <S123>/Dynamic PSOC Table1
 */

#ifndef SHARE_LookUp_real_T_real_T
#define SHARE_LookUp_real_T_real_T
#include "rtwtypes.h"

void LookUp_real_T_real_T(real_T *pY, const real_T *pYData, real_T u, const
  real_T *pUData, uint32_T iHi);

#endif
