/*
 * rt_atan2d_snf.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "DrivetrainHevP4".
 *
 * Model version              : 1.983
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Mon Oct 31 15:10:46 2022
 * Created for block: DrivetrainHevP4
 */

#ifndef SHARE_rt_atan2d_snf
#define SHARE_rt_atan2d_snf
#include "rtwtypes.h"

extern real_T rt_atan2d_snf(real_T u0, real_T u1);

#endif
