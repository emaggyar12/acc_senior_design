/*
 * HSC_Model_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "HSC_Model".
 *
 * Model version              : 1.270
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:36:19 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_HSC_Model_capi_h
#define RTW_HEADER_HSC_Model_capi_h
#include "HSC_Model.h"

extern void HSC_Model_InitializeDataMapInfo(RT_MODEL_HSC_Model_T *const
  HSC_Model_M, B_HSC_Model_c_T *localB, DW_HSC_Model_f_T *localDW);

#endif                                 /* RTW_HEADER_HSC_Model_capi_h */

/* EOF: HSC_Model_capi.h */
