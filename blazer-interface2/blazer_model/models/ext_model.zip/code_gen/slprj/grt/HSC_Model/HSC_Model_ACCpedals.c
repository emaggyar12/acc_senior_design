/*
 * Code generation for system system '<S12>/ACC pedals'
 *
 * Model                      : HSC_Model
 * Model version              : 1.270
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:36:19 2022
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "HSC_Model_ACCpedals.h"

/* Include model header file for global data */
#include "HSC_Model.h"
#include "HSC_Model_private.h"
#include "look2_binlg.h"

/* System initialize for atomic system: '<S12>/ACC pedals' */
void HSC_Model_ACCpedals_Init(DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP)
{
  /* InitializeConditions for UnitDelay: '<S24>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition[0];
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition[1];

  /* InitializeConditions for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE = localP->DiscreteTimeIntegrator_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = localP->DiscreteTimeIntegrator1_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator2' */
  localDW->DiscreteTimeIntegrator2_DSTATE = localP->DiscreteTimeIntegrator2_IC;
}

/* System reset for atomic system: '<S12>/ACC pedals' */
void HSC_Model_ACCpedals_Reset(DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP)
{
  /* InitializeConditions for UnitDelay: '<S24>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localP->UnitDelay_InitialCondition[0];
  localDW->UnitDelay_DSTATE[1] = localP->UnitDelay_InitialCondition[1];

  /* InitializeConditions for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE = localP->DiscreteTimeIntegrator_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = localP->DiscreteTimeIntegrator1_IC;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator2' */
  localDW->DiscreteTimeIntegrator2_DSTATE = localP->DiscreteTimeIntegrator2_IC;
}

/* Output and update for atomic system: '<S12>/ACC pedals' */
void HSC_Model_ACCpedals(RT_MODEL_HSC_Model_T * const HSC_Model_M, real_T
  rtu_EgoSpd, real_T rtu_TargetRelPos, real_T rtu_TargetRelSpd, real_T rtu_Info,
  real_T rtu_Info_b, real_T rtu_Info_d, real_T rtu_Info_e, real_T rtu_DistInfo,
  real_T rtu_DistInfo_e, real_T rtu_DistInfo_p, real_T rtu_DistInfo_l, real_T
  rtu_DistInfo_m, real_T rtu_DistInfo_f, real_T rtu_DistInfo_g,
  B_ACCpedals_HSC_Model_T *localB, DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP)
{
  /* Inport: '<S23>/DistInfo' */
  localB->DistInfo[0] = rtu_DistInfo;
  localB->DistInfo[1] = rtu_DistInfo_e;
  localB->DistInfo[2] = rtu_DistInfo_p;
  localB->DistInfo[3] = rtu_DistInfo_l;
  localB->DistInfo[4] = rtu_DistInfo_m;
  localB->DistInfo[5] = rtu_DistInfo_f;
  localB->DistInfo[6] = rtu_DistInfo_g;

  /* UnaryMinus: '<S23>/Unary Minus' */
  localB->DistErrFLipped = -localB->DistInfo[2];

  /* Gain: '<S23>/Gain4' */
  localB->EgoSpd = localP->Gain4_Gain * rtu_EgoSpd;

  /* Gain: '<S23>/Gain5' */
  localB->Gain5 = localP->Gain5_Gain * localB->EgoSpd;

  /* Lookup_n-D: '<S23>/2-D Lookup Table1' */
  localB->uDLookupTable1 = look2_binlg(localB->DistErrFLipped, localB->Gain5,
    localP->uDLookupTable1_bp01Data, localP->uDLookupTable1_bp02Data,
    HSC_Model_P.ACC_Distance_Lookup, localP->uDLookupTable1_maxIndex, 17U);

  /* UnitDelay: '<S24>/Unit Delay' */
  localB->UnitDelay[0] = localDW->UnitDelay_DSTATE[0];
  localB->UnitDelay[1] = localDW->UnitDelay_DSTATE[1];

  /* RelationalOperator: '<S24>/Relational Operator' */
  localB->VectorConcatenate[0] = (rtu_TargetRelSpd > localB->UnitDelay[0]);

  /* RelationalOperator: '<S24>/Relational Operator1' */
  localB->VectorConcatenate[1] = (rtu_TargetRelSpd < localB->UnitDelay[1]);

  /* SignalConversion generated from: '<S24>/Vector Concatenate1' */
  localB->VectorConcatenate1[0] = rtu_TargetRelSpd;

  /* SignalConversion generated from: '<S24>/Vector Concatenate1' */
  localB->VectorConcatenate1[1] = rtu_TargetRelSpd;

  /* Switch: '<S24>/Switch' */
  if (localB->VectorConcatenate[0]) {
    localB->Switch[0] = localB->VectorConcatenate1[0];
  } else {
    localB->Switch[0] = localB->UnitDelay[0];
  }

  if (localB->VectorConcatenate[1]) {
    localB->Switch[1] = localB->VectorConcatenate1[1];
  } else {
    localB->Switch[1] = localB->UnitDelay[1];
  }

  /* End of Switch: '<S24>/Switch' */

  /* Constant: '<S23>/APP' */
  localB->APP = localP->APP_Value;

  /* Constant: '<S23>/BPP' */
  localB->BPP = localP->BPP_Value;

  /* DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */
  localB->DiscreteTimeIntegrator = localDW->DiscreteTimeIntegrator_DSTATE;

  /* Product: '<S24>/Product' */
  localB->Product = rtu_TargetRelSpd * rtu_TargetRelSpd;

  /* Constant: '<S23>/BRAKE_PWR' */
  localB->BRAKE_PWR = localP->BRAKE_PWR_Value;

  /* Constant: '<S23>/ENG_PWR' */
  localB->ENG_PWR = localP->ENG_PWR_Value;

  /* Constant: '<S23>/MOTOR_PWR' */
  localB->MOTOR_PWR = localP->MOTOR_PWR_Value;

  /* Sum: '<S23>/Sum' */
  localB->ACCRewPwr = (localB->ENG_PWR + localB->MOTOR_PWR) + localB->BRAKE_PWR;

  /* Constant: '<S23>/Constant1' */
  localB->BrakeHoldActive = localP->Constant1_Value;

  /* Constant: '<S23>/Constant2' */
  localB->Constant2 = localP->Constant2_Value;

  /* RateTransition: '<S23>/Rate Transition2' */
  if (rtmIsSampleHit(HSC_Model_M, 1, 0)) {
    /* DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
    localB->EgoPosition = localDW->DiscreteTimeIntegrator1_DSTATE;

    /* DiscreteIntegrator: '<S23>/Discrete-Time Integrator2' */
    localB->xdotPosition = localDW->DiscreteTimeIntegrator2_DSTATE;
    localDW->RateTransition2_Buffer = rtu_EgoSpd;
    localB->RateTransition2 = localDW->RateTransition2_Buffer;

    /* RateTransition: '<S23>/Rate Transition3' */
    localDW->RateTransition3_Buffer = rtu_Info_e;
    localB->RateTransition3 = localDW->RateTransition3_Buffer;
  }

  /* End of RateTransition: '<S23>/Rate Transition2' */

  /* Gain: '<S23>/Gain' */
  localB->ACCBrakeTime = localP->Gain_Gain * rtu_Info;

  /* Gain: '<S23>/Gain1' */
  localB->grade = localP->Gain1_Gain * rtu_Info_b;

  /* Gain: '<S23>/Gain3' */
  localB->TargetRelPos = localP->Gain3_Gain * rtu_TargetRelPos;

  /* Gain: '<S23>/kph2m//s1' */
  localB->SetSpd = localP->kph2ms1_Gain * rtu_Info_d;

  /* Update for UnitDelay: '<S24>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localB->Switch[0];
  localDW->UnitDelay_DSTATE[1] = localB->Switch[1];

  /* Update for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE +=
    localP->DiscreteTimeIntegrator_gainval * localB->Product;
  if (rtmIsSampleHit(HSC_Model_M, 1, 0)) {
    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator1' */
    localDW->DiscreteTimeIntegrator1_DSTATE +=
      localP->DiscreteTimeIntegrator1_gainval * localB->RateTransition2;

    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator2' */
    localDW->DiscreteTimeIntegrator2_DSTATE +=
      localP->DiscreteTimeIntegrator2_gainval * localB->RateTransition3;
  }
}
