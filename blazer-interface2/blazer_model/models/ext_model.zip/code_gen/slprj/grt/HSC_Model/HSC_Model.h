/*
 * Code generation for system model 'HSC_Model'
 * For more details, see corresponding source file HSC_Model.c
 *
 */

#ifndef RTW_HEADER_HSC_Model_h_
#define RTW_HEADER_HSC_Model_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef HSC_Model_COMMON_INCLUDES_
# define HSC_Model_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* HSC_Model_COMMON_INCLUDES_ */

#include "HSC_Model_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "model_reference_types.h"

/* Child system includes */
#include "HSC_Model_ACCpedals.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"

/* Block signals for system '<S2>/Chart' */
typedef struct {
  real_T timer;                        /* '<S2>/Chart' */
} B_Chart_HSC_Model_T;

/* Block states (default storage) for system '<S2>/Chart' */
typedef struct {
  real_T currtime;                     /* '<S2>/Chart' */
  real_T orig;                         /* '<S2>/Chart' */
  uint32_T temporalCounter_i1;         /* '<S2>/Chart' */
  uint8_T is_active_c16_HSC_Model;     /* '<S2>/Chart' */
  uint8_T is_c16_HSC_Model;            /* '<S2>/Chart' */
} DW_Chart_HSC_Model_T;

/* Block signals for system '<S38>/ABSRegenOff' */
typedef struct {
  boolean_T Fault_Out;                 /* '<S38>/ABSRegenOff' */
} B_ABSRegenOff_HSC_Model_T;

/* Block states (default storage) for system '<S38>/ABSRegenOff' */
typedef struct {
  real_T error_time;                   /* '<S38>/ABSRegenOff' */
  real_T t;                            /* '<S38>/ABSRegenOff' */
  real_T t1;                           /* '<S38>/ABSRegenOff' */
  uint32_T temporalCounter_i1;         /* '<S38>/ABSRegenOff' */
  uint8_T is_active_c31_HSC_Model;     /* '<S38>/ABSRegenOff' */
  uint8_T is_c31_HSC_Model;            /* '<S38>/ABSRegenOff' */
  uint8_T is_Check;                    /* '<S38>/ABSRegenOff' */
} DW_ABSRegenOff_HSC_Model_T;

/* Block signals for system '<S43>/OverVoltage' */
typedef struct {
  boolean_T Fault_Out;                 /* '<S43>/OverVoltage' */
} B_OverVoltage_HSC_Model_T;

/* Block states (default storage) for system '<S43>/OverVoltage' */
typedef struct {
  real_T error_time;                   /* '<S43>/OverVoltage' */
  real_T t;                            /* '<S43>/OverVoltage' */
  real_T t1;                           /* '<S43>/OverVoltage' */
  uint32_T temporalCounter_i1;         /* '<S43>/OverVoltage' */
  uint8_T is_active_c27_HSC_Model;     /* '<S43>/OverVoltage' */
  uint8_T is_c27_HSC_Model;            /* '<S43>/OverVoltage' */
  uint8_T is_Check;                    /* '<S43>/OverVoltage' */
} DW_OverVoltage_HSC_Model_T;

/* Block signals for system '<S46>/Fault counter1' */
typedef struct {
  real_T fail_flag;                    /* '<S46>/Fault counter1' */
} B_Faultcounter1_HSC_Model_T;

/* Block states (default storage) for system '<S46>/Fault counter1' */
typedef struct {
  real_T count;                        /* '<S46>/Fault counter1' */
  real_T flag;                         /* '<S46>/Fault counter1' */
  uint8_T is_active_c24_HSC_Model;     /* '<S46>/Fault counter1' */
  uint8_T is_c24_HSC_Model;            /* '<S46>/Fault counter1' */
  uint8_T is_Normal;                   /* '<S46>/Fault counter1' */
} DW_Faultcounter1_HSC_Model_T;

/* Block signals for model 'HSC_Model' */
typedef struct {
  real_T CastToBoolean25;              /* '<S6>/Cast To Boolean25' */
  real_T CastToBoolean40;              /* '<S6>/Cast To Boolean40' */
  real_T Switch2;                      /* '<S1>/Switch2' */
  real_T VehSpdms;                     /* '<S1>/km//h2m//s1' */
  real_T EgoSpd;                       /* '<S21>/Data Type Conversion' */
  real_T TargetPos;                    /* '<S21>/Discrete-Time Integrator' */
  real_T EgoPos;                       /* '<S21>/Discrete-Time Integrator1' */
  real_T Add;                          /* '<S21>/Add' */
  real_T Switch1;                      /* '<S21>/Switch1' */
  real_T xdotref;                      /* '<S6>/Cast To Boolean10' */
  real_T TargetRelSpd;                 /* '<S21>/Switch' */
  real_T ACCBrakeTime;                 /* '<S6>/Cast To Boolean11' */
  real_T grade;                        /* '<S6>/Cast To Boolean15' */
  real_T ctDist;                       /* '<S22>/Product' */
  real_T ACCHdwySTG;                   /* '<S19>/Memory' */
  real_T Gain;                         /* '<S22>/Gain' */
  real_T SafeDist;                     /* '<S22>/Multiport Switch' */
  real_T DelayOneStep1;                /* '<S22>/Delay One Step1' */
  real_T DelayOneStep;                 /* '<S22>/Delay One Step' */
  real_T DistErr;                      /* '<S22>/Sum1' */
  real_T Minus;                        /* '<S22>/Minus' */
  real_T LeadVehicleSpeedmph;          /* '<S22>/Gain1' */
  real_T DistanceValidity;             /* '<S22>/Cast To Double' */
  real_T VehSpd_ms;                    /* '<S3>/kph to mps' */
  real_T DataTypeConversion;           /* '<S46>/Data Type Conversion' */
  real_T IC;                           /* '<S46>/IC' */
  real_T Gain_b;                       /* '<S46>/Gain' */
  real_T DataTypeConversion1;          /* '<S48>/Data Type Conversion1' */
  real_T Memory1;                      /* '<S10>/Memory1' */
  real_T CastToBoolean32;              /* '<S6>/Cast To Boolean32' */
  real_T DataTypeConversion7;          /* '<S45>/Data Type Conversion7' */
  real_T CastToBoolean48;              /* '<S6>/Cast To Boolean48' */
  real_T CastToBoolean46;              /* '<S6>/Cast To Boolean46' */
  real_T APP;                          /* '<S6>/Cast To Boolean23' */
  real_T CastToBoolean41;              /* '<S6>/Cast To Boolean41' */
  real_T DataTypeConversion2;          /* '<S45>/Data Type Conversion2' */
  real_T Memory7;                      /* '<S41>/Memory7' */
  real_T CastToBoolean31;              /* '<S6>/Cast To Boolean31' */
  real_T kohmstoohms;                  /* '<S41>/kohms to ohms' */
  real_T closedcontactorbatteryrange;
                                    /* '<S41>/closed contactor battery range' */
  real_T Divide;                       /* '<S41>/Divide' */
  real_T DataTypeConversion1_k;        /* '<S45>/Data Type Conversion1' */
  real_T DataTypeConversion3;          /* '<S45>/Data Type Conversion3' */
  real_T Gain_k;                       /* '<S19>/Gain' */
  real_T Gain1;                        /* '<S19>/Gain1' */
  real_T Memory;                       /* '<S2>/Memory' */
  real_T CastToBoolean35;              /* '<S6>/Cast To Boolean35' */
  real_T Product7;                     /* '<S2>/Product7' */
  real_T gear;                         /* '<S6>/Cast To Boolean28' */
  real_T Memory1_n;                    /* '<S2>/Memory1' */
  real_T Switch2_g;                    /* '<S2>/Switch2' */
  real_T Product6;                     /* '<S2>/Product6' */
  real_T TotDrvrDmdTrq;                /* '<S4>/Mass 2550' */
  real_T TotDrvrDmdTrq_g;              /* '<S4>/Saturation2' */
  real_T Switch;                       /* '<S10>/Switch' */
  real_T kphtomph;                     /* '<S10>/kph to mph' */
  real_T Switch_j;                     /* '<S35>/Switch' */
  real_T MatrixConcatenate1[5];        /* '<S35>/Matrix Concatenate1' */
  real_T MatrixConcatenate[5];         /* '<S35>/Matrix Concatenate' */
  real_T DynamicPSOCTable1;            /* '<S35>/Dynamic PSOC Table1' */
  real_T Product;                      /* '<S35>/Product' */
  real_T Switch_l;                     /* '<S36>/Switch' */
  real_T Switch2_p;                    /* '<S36>/Switch2' */
  real_T CastToBoolean34;              /* '<S6>/Cast To Boolean34' */
  real_T Switch_o;                     /* '<S130>/Switch' */
  real_T Switch2_c;                    /* '<S130>/Switch2' */
  real_T Product_a;                    /* '<S4>/Product' */
  real_T kphtomps;                     /* '<S4>/kph to mps' */
  real_T mpstorads;                    /* '<S4>/mps to rad//s' */
  real_T preventszeroingPwrDmdat0kph;
                                  /* '<S4>/prevents zeroing Pwr Dmd at 0 kph' */
  real_T map;                          /* '<S4>/Multiply' */
  real_T Switch_jp;                    /* '<S4>/Switch' */
  real_T kphtomph_o;                   /* '<S9>/kph to mph' */
  real_T CastToBoolean37;              /* '<S6>/Cast To Boolean37' */
  real_T SteeringWheelAngleFadeOut;   /* '<S9>/Steering Wheel Angle Fade Out' */
  real_T rbcp_brake_power_demand_W;    /* '<S9>/Multiport Switch' */
  real_T total;                        /* '<S4>/Sum' */
  real_T FixPtGatewayIn;               /* '<S93>/FixPt Gateway In' */
  real_T FixPtSum1;                    /* '<S93>/FixPt Sum1' */
  real_T kphtomph_c;                   /* '<S5>/kph to mph' */
  real_T Switch_i;                     /* '<S5>/Switch' */
  real_T Saturation1;                  /* '<S5>/Saturation1' */
  real_T Gain_m;                       /* '<S5>/Gain' */
  real_T Product_d;                    /* '<S5>/Product' */
  real_T ACC_Correc_Mot;               /* '<S91>/Switch4' */
  real_T Switch_l1;                    /* '<S2>/Switch' */
  real_T ContinuousCurrentLimit;       /* '<S2>/2-D Lookup Table' */
  real_T IC6;                          /* '<S2>/IC6' */
  real_T CurrentDemanded;              /* '<S2>/Divide' */
  real_T IC_m;                         /* '<S2>/IC' */
  real_T CurrentDemanded_k;            /* '<S2>/Divide1' */
  real_T ContinuousDischageLimit;      /* '<S2>/ContinuousDischageLimit' */
  real_T CastToBoolean33;              /* '<S6>/Cast To Boolean33' */
  real_T IC5;                          /* '<S2>/IC5' */
  real_T ContinuousMotorPowerLimit;    /* '<S2>/ContinuousMotorPowerLimit' */
  real_T IC2;                          /* '<S2>/IC2' */
  real_T IC1;                          /* '<S2>/IC1' */
  real_T ContinuousMotorPowerLimit2;   /* '<S2>/ContinuousMotorPowerLimit2' */
  real_T VehSpdMPH;                    /* '<S89>/Gain19' */
  real_T StartTorqueTime;              /* '<S89>/T1 (start of compensation)' */
  real_T FullTorqueTime;         /* '<S89>/T2 (time after t1 to full torque)' */
  real_T LowerTorqueAtTime;    /* '<S89>/T3 (time before t4 to lower torque)' */
  real_T EndTorqueTime;       /* '<S89>/T4 (direct time to end compensation)' */
  real_T Saturation;                   /* '<S89>/Saturation' */
  real_T TorqueAdditionTable;          /* '<S89>/TorqueAdditionTable' */
  real_T uDLookupTable;                /* '<S5>/1-D Lookup Table' */
  real_T kphtomps_m;                   /* '<S5>/kph to mps' */
  real_T Switch1_i;                    /* '<S112>/Switch1' */
  real_T Abs1;                         /* '<S109>/Abs1' */
  real_T Switch2_a;                    /* '<S109>/Switch2' */
  real_T Gain1_i;                      /* '<S5>/Gain1' */
  real_T Switch_g;                     /* '<S111>/Switch' */
  real_T Switch2_m;                    /* '<S111>/Switch2' */
  real_T DelayOneStep_b;               /* '<S110>/Delay One Step' */
  real_T Switch_e;                     /* '<S89>/Switch' */
  real_T motor_trq_demand_Nm;          /* '<S89>/Switch1' */
  real_T Switch_gm;                    /* '<S129>/Switch' */
  real_T Switch2_cx;                   /* '<S129>/Switch2' */
  real_T ACC_Correc_Eng;               /* '<S90>/Switch3' */
  real_T kphtomps1;                    /* '<S5>/kph to mps1' */
  real_T whlspd;                       /* '<S88>/m//s2rad//s' */
  real_T preventsdividingbyzero;       /* '<S88>/prevents dividing by zero' */
  real_T Divide_g;                     /* '<S88>/Divide' */
  real_T Product_f;                    /* '<S88>/Product' */
  real_T Switch2_d;                    /* '<S88>/Switch2' */
  real_T Saturation_n;                 /* '<S88>/Saturation' */
  real_T diff;                         /* '<S5>/Add6' */
  real_T eng_mot;                      /* '<S5>/Add1' */
  real_T diff_f;                       /* '<S5>/Add2' */
  real_T Abs1_a;                       /* '<S5>/Abs1' */
  real_T totaloutputpower;             /* '<S5>/Add' */
  real_T Product2;                     /* '<S50>/Product2' */
  real_T Abs1_d;                       /* '<S50>/Abs1' */
  real_T Abs2;                         /* '<S50>/Abs2' */
  real_T Add_m;                        /* '<S50>/Add' */
  real_T Abs3;                         /* '<S50>/Abs3' */
  real_T DataTypeConversion4;          /* '<S50>/Data Type Conversion4' */
  real_T IC_d;                         /* '<S50>/IC' */
  real_T Abs;                          /* '<S5>/Abs' */
  real_T diff_d;                       /* '<S5>/Add7' */
  real_T Tanh_Exponent;                /* '<S6>/Cast To Double' */
  real_T Product1;                     /* '<S110>/Product1' */
  real_T Tanh;                         /* '<S110>/Tanh' */
  real_T Tanh_multiplier;              /* '<S6>/Cast To Double1' */
  real_T Product_n;                    /* '<S110>/Product' */
  real_T Abs_g;                        /* '<S110>/Abs' */
  real_T IC3;                          /* '<S2>/IC3' */
  real_T IC4;                          /* '<S2>/IC4' */
  real_T Switch3;                      /* '<S2>/Switch3' */
  real_T CurrentLimit;                 /* '<S2>/2-D Lookup Table5' */
  real_T Battery_Pwr_Limit_Charge;     /* '<S2>/Product5' */
  real_T DischargeLimit;               /* '<S2>/Min1' */
  real_T IC8;                          /* '<S2>/IC8' */
  real_T IC7;                          /* '<S2>/IC7' */
  real_T Switch1_m;                    /* '<S2>/Switch1' */
  real_T CurrentLimit_n;               /* '<S2>/2-D Lookup Table2' */
  real_T Battery_Pwr_Limit_Charge_o;   /* '<S2>/Product4' */
  real_T ChargeLimit;                  /* '<S2>/Min' */
  real_T ChargeLimit_l;                /* '<S2>/Gain1' */
  real_T DataTypeConversion_g;         /* '<S9>/Data Type Conversion' */
  real_T Product2_a;                   /* '<S9>/Product2' */
  real_T TSamp;                        /* '<S26>/TSamp' */
  real_T Uk1;                          /* '<S26>/UD' */
  real_T Diff;                         /* '<S26>/Diff' */
  real_T TSamp_c;                      /* '<S27>/TSamp' */
  real_T Uk1_k;                        /* '<S27>/UD' */
  real_T Diff_i;                       /* '<S27>/Diff' */
  real_T HoldCancelDecel;              /* '<S1>/Constant10' */
  real_T Memory2;                      /* '<S3>/Memory2' */
  real_T DrvIntndAxlTrqMin;            /* '<S6>/Cast To Boolean8' */
  real_T CurrentState;                 /* '<S6>/Cast To Double2' */
  real_T DistanceToIntersection;       /* '<S6>/Cast To Double3' */
  real_T TimeToIntersection;           /* '<S6>/Cast To Double4' */
  real_T Decel_Division_Value;         /* '<S6>/Cast To Double5' */
  real_T hsc_bms_enable;               /* '<S10>/VMCP' */
  real_T hsc_bms_leakage_ena;          /* '<S10>/VMCP' */
  real_T hsc_bms_mainc_close;          /* '<S10>/VMCP' */
  real_T hsc_brusa_enable;             /* '<S10>/VMCP' */
  real_T Eng_Start;                    /* '<S10>/VMCP' */
  real_T hsc_mpdm_R1_bmsIgn;           /* '<S10>/VMCP' */
  real_T hsc_mpdm_R2_mcuIgn;           /* '<S10>/VMCP' */
  real_T VMU_Cmd1_OpReq;               /* '<S10>/VMCP' */
  real_T VMU_Cmd2_OpMdCmd;             /* '<S10>/VMCP' */
  real_T vmcp_StartupSt;               /* '<S10>/VMCP' */
  real_T vmcp_operating_mode;          /* '<S10>/VMCP' */
  real_T hsc_mpdm_R8_bmsPwr;           /* '<S10>/VMCP' */
  real_T hsc_mpdm_HVpump;              /* '<S10>/VMCP' */
  real_T VMU_Kickout;                  /* '<S10>/VMCP' */
  real_T VMU_Cmd2_CommandMd;           /* '<S10>/VMCP' */
  real_T PowerOut;            /* '<S9>/LockInPowerDemandToGetRidOfTorqueJerk' */
  real_T Switch1_d;                    /* '<S9>/Switch1' */
  real_T Switch_n;                     /* '<S9>/Switch' */
  real_T RegenPowerW;                  /* '<S9>/Product1' */
  real_T Saturation1_g;                /* '<S9>/Saturation1' */
  real_T rbcp_regen_enable;            /* '<S9>/rbcp_regen_enable' */
  real_T Gain_g;                       /* '<S9>/Gain' */
  real_T Product_fl;                   /* '<S9>/Product' */
  real_T Add1;                         /* '<S9>/Add1' */
  real_T BPPFadeOut;                   /* '<S9>/BPP Fade Out' */
  real_T Product3;                     /* '<S9>/Product3' */
  real_T Add_k;                        /* '<S9>/Add' */
  real_T MultiportSwitch1;             /* '<S9>/Multiport Switch1' */
  real_T uDLookupTable_g;              /* '<S9>/1-D Lookup Table' */
  real_T uDLookupTable1;               /* '<S9>/1-D Lookup Table1' */
  real_T uDLookupTable2;               /* '<S9>/1-D Lookup Table2' */
  real_T rbcp_brake_motor_fade_out;    /* '<S9>/Vehicle Speed Fade Out' */
  real_T emcp_p_eng_des_W;             /* '<S5>/Energy Management Strategy' */
  real_T emcp_ptot_W;                  /* '<S5>/Energy Management Strategy' */
  real_T emcp_p_elec_des_W;            /* '<S5>/Energy Management Strategy' */
  real_T emcp_mode;                    /* '<S5>/Energy Management Strategy' */
  real_T RPM_to_rads;                  /* '<S89>/RPM_to_rad//s' */
  real_T preventsdividingbyzero_h;     /* '<S89>/prevents dividing by zero' */
  real_T Switch3_j;                    /* '<S89>/Switch3' */
  real_T Add_g;                        /* '<S89>/Add' */
  real_T Motor_Trq_Req_Raw_Nm;         /* '<S89>/Divide1' */
  real_T Product1_e;                   /* '<S89>/Product1' */
  real_T Gain1_l;                      /* '<S89>/Gain1' */
  real_T PowerLossBetweenShifts;       /* '<S89>/Product' */
  real_T TorqueOut;                    /* '<S110>/Chart' */
  real_T DeltaTime;                    /* '<S110>/Chart' */
  real_T TorqueReversed;               /* '<S110>/Chart' */
  real_T Switch_c;                     /* '<S109>/Switch' */
  real_T uDLookupCreepTrq_Nm;          /* '<S109>/1-D Lookup Creep Trq_Nm' */
  real_T Multiplier;                   /* '<S89>/Chart2' */
  real_T GearTo;                       /* '<S89>/Chart1' */
  real_T GearChangeDuration;           /* '<S89>/Chart1' */
  real_T MotorCompCancel;              /* '<S89>/Chart' */
  real_T MovingAverage;                /* '<S89>/Moving Average' */
  real_T Switch_oa;                    /* '<S110>/Switch' */
  real_T MultiportSwitch;              /* '<S115>/Multiport Switch' */
  real_T Product3_f;                   /* '<S89>/Product3' */
  real_T uDLookupTable1_g;             /* '<S110>/1-D Lookup Table1' */
  real_T Product2_i;                   /* '<S110>/Product2' */
  real_T Gain_h;                       /* '<S89>/Gain' */
  real_T MinMax1;                      /* '<S88>/MinMax1' */
  real_T Gain2;                        /* '<S5>/Gain2' */
  real_T DirectLookupTablenD;          /* '<S5>/Direct Lookup Table (n-D)' */
  real_T FinalDrive;                   /* '<S5>/FinalDrive' */
  real_T Product1_m;                   /* '<S5>/Product1' */
  real_T Saturation_h;                 /* '<S5>/Saturation' */
  real_T Gain4;                        /* '<S5>/Gain4' */
  real_T uDLookupTable1_p;             /* '<S5>/1-D Lookup Table1' */
  real_T Engine_Axle_Torque;           /* '<S5>/Product2' */
  real_T DrvIntndAxlTrqMax;            /* '<S6>/Cast To Boolean7' */
  real_T Fault;                        /* '<S45>/fault Counter3' */
  real_T Fault_g;                      /* '<S45>/fault Counter2' */
  real_T Fault_o;                      /* '<S45>/fault Counter1' */
  real_T GFDLightOn;                   /* '<S41>/Chart' */
  real_T kphtomph_f;                   /* '<S2>/kph to mph' */
  real_T VehicleSpeedMultiplier;       /* '<S35>/Vehicle Speed Multiplier' */
  real_T SOC_Multiplier;               /* '<S2>/Chart4' */
  real_T timer;                        /* '<S2>/Chart3' */
  real_T timer_g;                      /* '<S2>/Chart1' */
  real_T bcm_coolan_temp_C;            /* '<S6>/Cast To Double6' */
  real_T ContinuousMotorPowerLimit1;   /* '<S2>/ContinuousMotorPowerLimit1' */
  real_T DiscreteMotorPowerLimit;      /* '<S2>/DiscreteMotorPowerLimit' */
  real_T ContinuousMotorPowerLimit3;   /* '<S2>/ContinuousMotorPowerLimit3' */
  real_T DiscreteMotorPowerLimit1;     /* '<S2>/DiscreteMotorPowerLimit1' */
  real_T LastSpeed;                    /* '<S22>/Chart2' */
  real_T LastDistance;                 /* '<S22>/Chart2' */
  real_T KeepTrackValidity;            /* '<S22>/Chart2' */
  real_T NearDistanceTarget;           /* '<S22>/NearDistanceTarget' */
  real_T MediumDistanceTarget;         /* '<S22>/MediumDistanceTarget' */
  real_T FarDistanceTarget;            /* '<S22>/FarDistanceTarget' */
  real_T Add1_i;                       /* '<S21>/Add1' */
  real_T CAVtrgVel;                    /* '<S6>/Cast To Boolean13' */
  real_T CAVtrgDist;                   /* '<S6>/Cast To Boolean14' */
  real_T ACCSetSpd;                    /* '<S1>/Generate SetSpd' */
  real_T ACCHdwyStg;                   /* '<S19>/Chart' */
  real_T ACCDrvrSeltdSpd;              /* '<S19>/Chart' */
  real_T AutoMdSpdLmtStat;             /* '<S1>/Chart' */
  real_T ACCAct370;                    /* '<S1>/Chart' */
  real_T AdapCrsCntVDA;                /* '<S1>/Chart' */
  real_T ACCDrvrSeltdSpd_i;            /* '<S1>/Chart' */
  real_T CAVACCRequest;                /* '<S1>/CAVPCM_ACCMd_Request' */
  real_T CastToBoolean27;              /* '<S6>/Cast To Boolean27' */
  real_T Gain_bx;                      /* '<S1>/Gain' */
  int16_T lvrpos;                      /* '<S6>/Cast To Boolean39' */
  int16_T CastToBoolean3;              /* '<S6>/Cast To Boolean3' */
  uint8_T CastToBoolean30;             /* '<S6>/Cast To Boolean30' */
  uint8_T Memory1_m;                   /* '<S3>/Memory1' */
  uint8_T BPPTrqCancel;                /* '<S39>/Gain' */
  int8_T TrqReqStat;                   /* '<S6>/Cast To Boolean9' */
  int8_T CastToBoolean47;              /* '<S6>/Cast To Boolean47' */
  int8_T CastToBoolean36;              /* '<S6>/Cast To Boolean36' */
  int8_T CastToBoolean29;              /* '<S6>/Cast To Boolean29' */
  int8_T CastToBoolean6;               /* '<S6>/Cast To Boolean6' */
  boolean_T CastToBoolean26;           /* '<S6>/Cast To Boolean26' */
  boolean_T CastToBoolean16;           /* '<S6>/Cast To Boolean16' */
  boolean_T DistanceValidity_d;        /* '<S22>/OR' */
  boolean_T CastToBoolean4;            /* '<S6>/Cast To Boolean4' */
  boolean_T Compare;                   /* '<S75>/Compare' */
  boolean_T Compare_l;                 /* '<S71>/Compare' */
  boolean_T LogicalOperator6;          /* '<S46>/Logical Operator6' */
  boolean_T Compare_f;                 /* '<S72>/Compare' */
  boolean_T Compare_i;                 /* '<S74>/Compare' */
  boolean_T LogicalOperator7;          /* '<S46>/Logical Operator7' */
  boolean_T LogicalOperator8;          /* '<S46>/Logical Operator8' */
  boolean_T powerdirectionfault;       /* '<S3>/Cast To Boolean' */
  boolean_T Compare_k;                 /* '<S76>/Compare' */
  boolean_T Compare_a;                 /* '<S79>/Compare' */
  boolean_T LogicalOperator1;          /* '<S48>/Logical Operator1' */
  boolean_T Compare_h;                 /* '<S80>/Compare' */
  boolean_T Compare_fb;                /* '<S82>/Compare' */
  boolean_T Compare_lt;                /* '<S83>/Compare' */
  boolean_T RecieveDrive;              /* '<S48>/Logical Operator' */
  boolean_T LogicalOperator2;          /* '<S48>/Logical Operator2' */
  boolean_T Compare_j;                 /* '<S78>/Compare' */
  boolean_T LogicalOperator4;          /* '<S48>/Logical Operator4' */
  boolean_T LogicalOperator3;          /* '<S48>/Logical Operator3' */
  boolean_T Compare_n;                 /* '<S77>/Compare' */
  boolean_T LogicalOperator6_k;        /* '<S48>/Logical Operator6' */
  boolean_T LogicalOperator5;          /* '<S48>/Logical Operator5' */
  boolean_T LogicalOperator7_c;        /* '<S48>/Logical Operator7' */
  boolean_T IC_e;                      /* '<S48>/IC' */
  boolean_T LogicalOperator1_i;        /* '<S49>/Logical Operator1' */
  boolean_T Compare_b;                 /* '<S67>/Compare' */
  boolean_T Compare_e;                 /* '<S58>/Compare' */
  boolean_T Compare_nx;                /* '<S59>/Compare' */
  boolean_T Compare_jl;                /* '<S62>/Compare' */
  boolean_T CastToBoolean22;           /* '<S6>/Cast To Boolean22' */
  boolean_T LogicalOperator1_c;        /* '<S42>/Logical Operator1' */
  boolean_T Compare_ej;                /* '<S65>/Compare' */
  boolean_T Compare_m;                 /* '<S57>/Compare' */
  boolean_T gfd;                       /* '<S41>/Logical Operator11' */
  boolean_T FirstTimeFlag;             /* '<S41>/Data Type Conversion2' */
  boolean_T DataTypeConversion3_k;     /* '<S41>/Data Type Conversion3' */
  boolean_T Compare_c;                 /* '<S64>/Compare' */
  boolean_T Compare_jlm;               /* '<S66>/Compare' */
  boolean_T LogicalOperator;           /* '<S45>/Logical Operator' */
  boolean_T LogicalOperator1_a;        /* '<S47>/Logical Operator1' */
  boolean_T CAVPCM_ACCMdActive;        /* '<S1>/Switch1' */
  boolean_T TrafficLightPresent;       /* '<S6>/Cast To Boolean12' */
  boolean_T CastToBoolean51;           /* '<S6>/Cast To Boolean51' */
  boolean_T CastToBoolean49;           /* '<S6>/Cast To Boolean49' */
  boolean_T CastToBoolean45;           /* '<S6>/Cast To Boolean45' */
  boolean_T CastToBoolean43;           /* '<S6>/Cast To Boolean43' */
  boolean_T CastToBoolean44;           /* '<S6>/Cast To Boolean44' */
  boolean_T CastToBoolean42;           /* '<S6>/Cast To Boolean42' */
  boolean_T Compare_kf;                /* '<S37>/Compare' */
  boolean_T LowerRelop1;               /* '<S36>/LowerRelop1' */
  boolean_T UpperRelop;                /* '<S36>/UpperRelop' */
  boolean_T DiagnosticFaults;          /* '<S89>/Diagnostic Faults' */
  boolean_T LowerRelop1_e;             /* '<S130>/LowerRelop1' */
  boolean_T UpperRelop_l;              /* '<S130>/UpperRelop' */
  boolean_T AND;                       /* '<S91>/AND' */
  boolean_T NOT;                       /* '<S4>/NOT' */
  boolean_T Compare_o;                 /* '<S87>/Compare' */
  boolean_T Compare_oe;                /* '<S134>/Compare' */
  boolean_T Compare_kp;                /* '<S135>/Compare' */
  boolean_T Compare_oa;                /* '<S139>/Compare' */
  boolean_T LogicalOperator_l;         /* '<S9>/Logical Operator' */
  boolean_T Compare_nf;                /* '<S55>/Compare' */
  boolean_T Compare_jg;                /* '<S118>/Compare' */
  boolean_T Compare_nu;                /* '<S116>/Compare' */
  boolean_T LowerRelop1_h;             /* '<S111>/LowerRelop1' */
  boolean_T UpperRelop_l5;             /* '<S111>/UpperRelop' */
  boolean_T Compare_m2;                /* '<S114>/Compare' */
  boolean_T LowerRelop1_n;             /* '<S129>/LowerRelop1' */
  boolean_T UpperRelop_e;              /* '<S129>/UpperRelop' */
  boolean_T AND_f;                     /* '<S90>/AND' */
  boolean_T Compare_ha;                /* '<S94>/Compare' */
  boolean_T Compare_nm;                /* '<S96>/Compare' */
  boolean_T Compare_g;                 /* '<S98>/Compare' */
  boolean_T LogicalOperator_f;         /* '<S95>/Logical Operator' */
  boolean_T Compare_lf;                /* '<S97>/Compare' */
  boolean_T LogicalOperator1_d;        /* '<S95>/Logical Operator1' */
  boolean_T CAVPCM_ACCAct;             /* '<S1>/Cast To Boolean1' */
  boolean_T CAVACCReq;                 /* '<S1>/Cast To Boolean' */
  boolean_T Compare_p;                 /* '<S85>/Compare' */
  boolean_T Compare_nq;                /* '<S84>/Compare' */
  boolean_T AND_a;                     /* '<S50>/AND' */
  boolean_T CastToBoolean38;           /* '<S6>/Cast To Boolean38' */
  boolean_T Compare_o0;                /* '<S137>/Compare' */
  boolean_T Compare_j2;                /* '<S53>/Compare' */
  boolean_T Compare_j1;                /* '<S52>/Compare' */
  boolean_T LogicalOperator3_d;        /* '<S39>/Logical Operator3' */
  boolean_T BPPTrqCancel_h;            /* '<S39>/IC' */
  boolean_T Compare_nj;                /* '<S136>/Compare' */
  boolean_T Constant3;                 /* '<S3>/Constant3' */
  boolean_T dist_is_valid;             /* '<S6>/Cast To Boolean' */
  boolean_T CastToBoolean1;            /* '<S6>/Cast To Boolean1' */
  boolean_T CastToBoolean2;            /* '<S6>/Cast To Boolean2' */
  boolean_T CastToBoolean24;           /* '<S6>/Cast To Boolean24' */
  boolean_T Compare_fd;                /* '<S108>/Compare' */
  boolean_T Compare_f4;                /* '<S107>/Compare' */
  boolean_T OR;                        /* '<S89>/OR' */
  boolean_T Compare_bz;                /* '<S119>/Compare' */
  boolean_T Compare_lv;                /* '<S120>/Compare' */
  boolean_T Compare_lz;                /* '<S121>/Compare' */
  boolean_T allowsbrakingtorqueifineithercruisechangingmodes;
        /* '<S113>/allows braking torque if in  either cruise changing modes' */
  boolean_T Compare_ni;                /* '<S124>/Compare' */
  boolean_T Compare_nz;                /* '<S122>/Compare' */
  boolean_T LogicalOperator1_a1;       /* '<S113>/Logical Operator1' */
  boolean_T Compare_me;                /* '<S123>/Compare' */
  boolean_T OR_n;                      /* '<S113>/OR' */
  boolean_T CastToBoolean50;           /* '<S6>/Cast To Boolean50' */
  boolean_T Compare_nw;                /* '<S106>/Compare' */
  boolean_T Compare_o5;                /* '<S104>/Compare' */
  boolean_T Compare_mq;                /* '<S105>/Compare' */
  boolean_T Compare_ib;                /* '<S103>/Compare' */
  boolean_T LogicalOperator_d;         /* '<S89>/Logical Operator' */
  boolean_T LogicalOperator1_e;        /* '<S89>/Logical Operator1' */
  boolean_T Compare_bf;                /* '<S102>/Compare' */
  boolean_T Compare_ns;                /* '<S128>/Compare' */
  boolean_T Compare_el;                /* '<S127>/Compare' */
  boolean_T LogicalOperator1_d1;       /* '<S115>/Logical Operator1' */
  boolean_T Compare_d;                 /* '<S126>/Compare' */
  boolean_T Compare_fi;                /* '<S125>/Compare' */
  boolean_T LogicalOperator_fc;        /* '<S115>/Logical Operator' */
  boolean_T LogicalOperator2_m;        /* '<S115>/Logical Operator2' */
  boolean_T fail_flag;                 /* '<S48>/Fault Counter' */
  boolean_T Compare_is;                /* '<S34>/Compare' */
  boolean_T ACCAct370_f;               /* '<S19>/Chart' */
  boolean_T HoldCancelDecel_o;         /* '<S1>/Chart3' */
  boolean_T Compare_pq;                /* '<S17>/Compare' */
  boolean_T Compare_av;                /* '<S16>/Compare' */
  boolean_T Compare_mu;                /* '<S18>/Compare' */
  boolean_T CastToBoolean5;            /* '<S6>/Cast To Boolean5' */
  boolean_T OR1;                       /* '<S1>/OR1' */
  boolean_T Switch_ja;                 /* '<S1>/Switch' */
  boolean_T OR_i;                      /* '<S1>/OR' */
  B_Faultcounter1_HSC_Model_T sf_Faultcounter1_f;/* '<S50>/Fault counter1' */
  B_Faultcounter1_HSC_Model_T sf_Faultcounter1;/* '<S46>/Fault counter1' */
  B_OverVoltage_HSC_Model_T sf_OverDischarge;/* '<S44>/OverDischarge' */
  B_OverVoltage_HSC_Model_T sf_UnderVoltage;/* '<S43>/UnderVoltage' */
  B_OverVoltage_HSC_Model_T sf_OverVoltage;/* '<S43>/OverVoltage' */
  B_ABSRegenOff_HSC_Model_T sf_ABSRegenOff_f;/* '<S40>/ABSRegenOff' */
  B_ABSRegenOff_HSC_Model_T sf_ABSRegenOff;/* '<S38>/ABSRegenOff' */
  B_Chart_HSC_Model_T sf_Chart2_m;     /* '<S2>/Chart2' */
  B_Chart_HSC_Model_T sf_Chart_g;      /* '<S2>/Chart' */
  B_ACCpedals_HSC_Model_T ACCpedals;   /* '<S12>/ACC pedals' */
} B_HSC_Model_c_T;

/* Block states (default storage) for model 'HSC_Model' */
typedef struct {
  c_dsp_private_SlidingWindowAverageCG_HSC_Model_T gobj_1;/* '<S89>/Moving Average' */
  c_dsp_private_SlidingWindowAverageCG_HSC_Model_T gobj_2;/* '<S89>/Moving Average' */
  dsp_simulink_MovingAverage_HSC_Model_T obj;/* '<S89>/Moving Average' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S21>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTATE;/* '<S21>/Discrete-Time Integrator1' */
  real_T DelayOneStep1_DSTATE;         /* '<S22>/Delay One Step1' */
  real_T DelayOneStep_DSTATE;          /* '<S22>/Delay One Step' */
  real_T DelayOneStep_DSTATE_b;        /* '<S110>/Delay One Step' */
  real_T UD_DSTATE;                    /* '<S26>/UD' */
  real_T UD_DSTATE_j;                  /* '<S27>/UD' */
  real_T Memory_PreviousInput;         /* '<S19>/Memory' */
  real_T Memory1_PreviousInput;        /* '<S10>/Memory1' */
  real_T Memory7_PreviousInput;        /* '<S41>/Memory7' */
  real_T Memory_PreviousInput_p;       /* '<S2>/Memory' */
  real_T Memory1_PreviousInput_d;      /* '<S2>/Memory1' */
  real_T m_bpLambda[3];                /* '<S2>/2-D Lookup Table5' */
  real_T m_bpLambda_m[3];              /* '<S2>/2-D Lookup Table2' */
  real_T Memory2_PreviousInput;        /* '<S3>/Memory2' */
  real_T Regen_Active;                 /* '<S10>/VMCP' */
  real_T Full_Power_Active;            /* '<S10>/VMCP' */
  real_T Cruise_Charge_Available;      /* '<S10>/VMCP' */
  real_T Launch_Mode;                  /* '<S10>/VMCP' */
  real_T Low_Speed_Cruise_Charge;      /* '<S10>/VMCP' */
  real_T BPPLock;             /* '<S9>/LockInPowerDemandToGetRidOfTorqueJerk' */
  real_T emcp_psoc_W;                  /* '<S5>/Energy Management Strategy' */
  real_T APPLatch;                     /* '<S89>/Chart' */
  real_T count;                        /* '<S48>/Fault Counter' */
  real_T flag;                         /* '<S48>/Fault Counter' */
  real_T fail_flag;                    /* '<S45>/fault Counter3' */
  real_T count_g;                      /* '<S45>/fault Counter3' */
  real_T fail_flag_b;                  /* '<S45>/fault Counter2' */
  real_T count_f;                      /* '<S45>/fault Counter2' */
  real_T fail_flag_p;                  /* '<S45>/fault Counter1' */
  real_T count_o;                      /* '<S45>/fault Counter1' */
  real_T currtime;                     /* '<S2>/Chart3' */
  real_T orig;                         /* '<S2>/Chart3' */
  real_T currtime_g;                   /* '<S2>/Chart1' */
  real_T orig_c;                       /* '<S2>/Chart1' */
  uint32_T m_bpIndex[3];               /* '<S2>/2-D Lookup Table5' */
  uint32_T m_bpIndex_n[3];             /* '<S2>/2-D Lookup Table2' */
  uint32_T temporalCounter_i1;         /* '<S110>/Chart' */
  uint32_T temporalCounter_i1_d;       /* '<S89>/Chart2' */
  uint32_T temporalCounter_i1_g;       /* '<S89>/Chart1' */
  uint32_T temporalCounter_i1_o;       /* '<S2>/Chart3' */
  uint32_T temporalCounter_i1_df;      /* '<S2>/Chart1' */
  uint16_T temporalCounter_i1_c;       /* '<S89>/Chart' */
  uint16_T temporalCounter_i1_e;       /* '<S22>/Chart2' */
  uint16_T temporalCounter_i1_b;       /* '<S1>/Generate SetSpd' */
  uint16_T temporalCounter_i1_g3;      /* '<S19>/Chart' */
  uint16_T temporalCounter_i1_ce;      /* '<S1>/Chart3' */
  uint8_T is_active_c3_HSC_Model;      /* '<S10>/VMCP' */
  uint8_T is_Startup_Shutdown_Sequence;/* '<S10>/VMCP' */
  uint8_T is_HV_Start_Up;              /* '<S10>/VMCP' */
  uint8_T is_Brusa_Charging;           /* '<S10>/VMCP' */
  uint8_T is_Shutdown;                 /* '<S10>/VMCP' */
  uint8_T is_ON_State;                 /* '<S10>/VMCP' */
  uint8_T is_Operating_Mode;           /* '<S10>/VMCP' */
  uint8_T is_active_c39_HSC_Model;
                              /* '<S9>/LockInPowerDemandToGetRidOfTorqueJerk' */
  uint8_T is_c39_HSC_Model;   /* '<S9>/LockInPowerDemandToGetRidOfTorqueJerk' */
  uint8_T is_active_c1_HSC_Model;      /* '<S5>/Energy Management Strategy' */
  uint8_T is_SOC_Maintenance;          /* '<S5>/Energy Management Strategy' */
  uint8_T is_active_c22_HSC_Model;     /* '<S110>/Chart' */
  uint8_T is_c22_HSC_Model;            /* '<S110>/Chart' */
  uint8_T is_active_c35_HSC_Model;     /* '<S89>/Chart2' */
  uint8_T is_c35_HSC_Model;            /* '<S89>/Chart2' */
  uint8_T is_active_c33_HSC_Model;     /* '<S89>/Chart1' */
  uint8_T is_c33_HSC_Model;            /* '<S89>/Chart1' */
  uint8_T is_active_c12_HSC_Model;     /* '<S89>/Chart' */
  uint8_T is_c12_HSC_Model;            /* '<S89>/Chart' */
  uint8_T is_active_c18_HSC_Model;     /* '<S48>/Fault Counter' */
  uint8_T is_c18_HSC_Model;            /* '<S48>/Fault Counter' */
  uint8_T is_Normal;                   /* '<S48>/Fault Counter' */
  uint8_T is_active_c11_HSC_Model;     /* '<S45>/fault Counter3' */
  uint8_T is_c11_HSC_Model;            /* '<S45>/fault Counter3' */
  uint8_T is_Normal_Operation;         /* '<S45>/fault Counter3' */
  uint8_T is_active_c10_HSC_Model;     /* '<S45>/fault Counter2' */
  uint8_T is_c10_HSC_Model;            /* '<S45>/fault Counter2' */
  uint8_T is_Normal_Operation_i;       /* '<S45>/fault Counter2' */
  uint8_T is_active_c9_HSC_Model;      /* '<S45>/fault Counter1' */
  uint8_T is_c9_HSC_Model;             /* '<S45>/fault Counter1' */
  uint8_T is_Normal_Operation_g;       /* '<S45>/fault Counter1' */
  uint8_T is_active_c5_HSC_Model;      /* '<S41>/Chart' */
  uint8_T is_c5_HSC_Model;             /* '<S41>/Chart' */
  uint8_T is_active_c25_HSC_Model;     /* '<S2>/Chart4' */
  uint8_T is_c25_HSC_Model;            /* '<S2>/Chart4' */
  uint8_T is_active_c20_HSC_Model;     /* '<S2>/Chart3' */
  uint8_T is_c20_HSC_Model;            /* '<S2>/Chart3' */
  uint8_T is_active_c17_HSC_Model;     /* '<S2>/Chart1' */
  uint8_T is_c17_HSC_Model;            /* '<S2>/Chart1' */
  uint8_T is_active_c28_HSC_Model;     /* '<S22>/Chart2' */
  uint8_T is_c28_HSC_Model;            /* '<S22>/Chart2' */
  uint8_T is_active_c15_HSC_Model;     /* '<S1>/Generate SetSpd' */
  uint8_T is_c15_HSC_Model;            /* '<S1>/Generate SetSpd' */
  uint8_T is_active_c44_HSC_Model;     /* '<S19>/Chart' */
  uint8_T is_c44_HSC_Model;            /* '<S19>/Chart' */
  uint8_T is_active_c34_HSC_Model;     /* '<S1>/Chart3' */
  uint8_T is_c34_HSC_Model;            /* '<S1>/Chart3' */
  uint8_T is_active_c21_HSC_Model;     /* '<S1>/Chart' */
  uint8_T is_c21_HSC_Model;            /* '<S1>/Chart' */
  uint8_T is_CruiseSet;                /* '<S1>/Chart' */
  uint8_T temporalCounter_i1_on;       /* '<S1>/Chart' */
  uint8_T is_active_c4_HSC_Model;      /* '<S1>/CAVPCM_ACCMd_Request' */
  uint8_T is_c4_HSC_Model;             /* '<S1>/CAVPCM_ACCMd_Request' */
  uint8_T is_active_c2_HSC_Model;      /* '<S1>/ACC Auto Engage Controller' */
  uint8_T is_c2_HSC_Model;             /* '<S1>/ACC Auto Engage Controller' */
  uint8_T is_CruiseOn;                 /* '<S1>/ACC Auto Engage Controller' */
  uint8_T is_Turn_Cruise_Control_Off;  /* '<S1>/ACC Auto Engage Controller' */
  uint8_T is_CruiseControlAutomation;  /* '<S1>/ACC Auto Engage Controller' */
  uint8_T temporalCounter_i1_j;        /* '<S1>/ACC Auto Engage Controller' */
  uint8_T temporalCounter_i2;          /* '<S1>/ACC Auto Engage Controller' */
  boolean_T IC_FirstOutputTime;        /* '<S46>/IC' */
  boolean_T IC_FirstOutputTime_j;      /* '<S48>/IC' */
  boolean_T IC6_FirstOutputTime;       /* '<S2>/IC6' */
  boolean_T IC_FirstOutputTime_b;      /* '<S2>/IC' */
  boolean_T IC5_FirstOutputTime;       /* '<S2>/IC5' */
  boolean_T IC2_FirstOutputTime;       /* '<S2>/IC2' */
  boolean_T IC1_FirstOutputTime;       /* '<S2>/IC1' */
  boolean_T IC_FirstOutputTime_d;      /* '<S50>/IC' */
  boolean_T IC3_FirstOutputTime;       /* '<S2>/IC3' */
  boolean_T IC4_FirstOutputTime;       /* '<S2>/IC4' */
  boolean_T IC8_FirstOutputTime;       /* '<S2>/IC8' */
  boolean_T IC7_FirstOutputTime;       /* '<S2>/IC7' */
  boolean_T IC_FirstOutputTime_m;      /* '<S39>/IC' */
  boolean_T objisempty;                /* '<S89>/Moving Average' */
  uint8_T Memory1_PreviousInput_l;     /* '<S3>/Memory1' */
  DW_Faultcounter1_HSC_Model_T sf_Faultcounter1_f;/* '<S50>/Fault counter1' */
  DW_Faultcounter1_HSC_Model_T sf_Faultcounter1;/* '<S46>/Fault counter1' */
  DW_OverVoltage_HSC_Model_T sf_OverDischarge;/* '<S44>/OverDischarge' */
  DW_OverVoltage_HSC_Model_T sf_UnderVoltage;/* '<S43>/UnderVoltage' */
  DW_OverVoltage_HSC_Model_T sf_OverVoltage;/* '<S43>/OverVoltage' */
  DW_ABSRegenOff_HSC_Model_T sf_ABSRegenOff_f;/* '<S40>/ABSRegenOff' */
  DW_ABSRegenOff_HSC_Model_T sf_ABSRegenOff;/* '<S38>/ABSRegenOff' */
  DW_Chart_HSC_Model_T sf_Chart2_m;    /* '<S2>/Chart2' */
  DW_Chart_HSC_Model_T sf_Chart_g;     /* '<S2>/Chart' */
  DW_ACCpedals_HSC_Model_T ACCpedals;  /* '<S12>/ACC pedals' */
} DW_HSC_Model_f_T;

/* Parameters (default storage) */
struct P_HSC_Model_T_ {
  real_T ACC_Distance_Lookup[289];     /* Variable: ACC_Distance_Lookup
                                        * Referenced by: '<S23>/2-D Lookup Table1'
                                        */
  real_T Breakpoint1MotorCompensation[35];/* Variable: Breakpoint1MotorCompensation
                                           * Referenced by: '<S89>/T1 (start of compensation)'
                                           */
  real_T Breakpoint2MotorCompensation[35];/* Variable: Breakpoint2MotorCompensation
                                           * Referenced by: '<S89>/T2 (time after t1 to full torque)'
                                           */
  real_T Breakpoint3MotorCompensation[35];/* Variable: Breakpoint3MotorCompensation
                                           * Referenced by: '<S89>/T3 (time before t4 to lower torque)'
                                           */
  real_T Breakpoint4MotorCompensation[35];/* Variable: Breakpoint4MotorCompensation
                                           * Referenced by: '<S89>/T4 (direct time to end compensation)'
                                           */
  real_T ContinuousBatteryCharge[110]; /* Variable: ContinuousBatteryCharge
                                        * Referenced by: '<S2>/2-D Lookup Table'
                                        */
  real_T ContinuousBatteryDischarge[110];/* Variable: ContinuousBatteryDischarge
                                          * Referenced by: '<S2>/ContinuousDischageLimit'
                                          */
  real_T InterpBatteryCharge[220];     /* Variable: InterpBatteryCharge
                                        * Referenced by: '<S2>/2-D Lookup Table2'
                                        */
  real_T InterpBatteryDischarge[220];  /* Variable: InterpBatteryDischarge
                                        * Referenced by: '<S2>/2-D Lookup Table5'
                                        */
  real_T Mass2550TorqueMap[136];       /* Variable: Mass2550TorqueMap
                                        * Referenced by: '<S4>/Mass 2550'
                                        */
  real_T MotorCompensationAxlTorque[35];/* Variable: MotorCompensationAxlTorque
                                         * Referenced by: '<S89>/TorqueAdditionTable'
                                         */
  real_T N[10];                        /* Variable: N
                                        * Referenced by: '<S5>/Direct Lookup Table (n-D)'
                                        */
  real_T Re;                           /* Variable: Re
                                        * Referenced by:
                                        *   '<S4>/mps to rad//s'
                                        *   '<S5>/Gain'
                                        *   '<S5>/Gain2'
                                        *   '<S88>/m//s2rad//s'
                                        *   '<S89>/Gain1'
                                        */
  real_T bppRegenLookup[23];           /* Variable: bppRegenLookup
                                        * Referenced by: '<S9>/BPP Fade Out'
                                        */
  real_T bppRegenMap[23];              /* Variable: bppRegenMap
                                        * Referenced by: '<S9>/BPP Fade Out'
                                        */
  real_T f_tbrake_n_bpt[40];           /* Variable: f_tbrake_n_bpt
                                        * Referenced by: '<S5>/1-D Lookup Table1'
                                        */
  real_T motor_speed_bkp_rpm[33];      /* Variable: motor_speed_bkp_rpm
                                        * Referenced by: '<S5>/1-D Lookup Table'
                                        */
  real_T peak_trq_curve[33];           /* Variable: peak_trq_curve
                                        * Referenced by: '<S5>/1-D Lookup Table'
                                        */
  real_T tandivide[1001];              /* Variable: tandivide
                                        * Referenced by: '<S110>/1-D Lookup Table1'
                                        */
  real_T DiscreteDerivative_ICPrevScaledInput;
                         /* Mask Parameter: DiscreteDerivative_ICPrevScaledInput
                          * Referenced by: '<S26>/UD'
                          */
  real_T jerkDeriv_ICPrevScaledInput;
                                  /* Mask Parameter: jerkDeriv_ICPrevScaledInput
                                   * Referenced by: '<S27>/UD'
                                   */
  real_T ReverseMotionCheck_const;   /* Mask Parameter: ReverseMotionCheck_const
                                      * Referenced by: '<S75>/Constant'
                                      */
  real_T ForwardMotionCheck_const;   /* Mask Parameter: ForwardMotionCheck_const
                                      * Referenced by: '<S74>/Constant'
                                      */
  real_T CheckForReverse_const;        /* Mask Parameter: CheckForReverse_const
                                        * Referenced by: '<S79>/Constant'
                                        */
  real_T FirstGearOrGreater_const;   /* Mask Parameter: FirstGearOrGreater_const
                                      * Referenced by: '<S82>/Constant'
                                      */
  real_T NinethGearOrless_const;       /* Mask Parameter: NinethGearOrless_const
                                        * Referenced by: '<S83>/Constant'
                                        */
  real_T CompareToConstant6_const;   /* Mask Parameter: CompareToConstant6_const
                                      * Referenced by: '<S67>/Constant'
                                      */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S58>/Constant'
                                       */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S59>/Constant'
                                      */
  real_T CompareToConstant_const_c; /* Mask Parameter: CompareToConstant_const_c
                                     * Referenced by: '<S62>/Constant'
                                     */
  real_T CompareToConstant3_const;   /* Mask Parameter: CompareToConstant3_const
                                      * Referenced by: '<S18>/Constant'
                                      */
  real_T CompareToConstant2_const;   /* Mask Parameter: CompareToConstant2_const
                                      * Referenced by: '<S65>/Constant'
                                      */
  real_T CompetitionRequirement500ohmspervolt_const;
                   /* Mask Parameter: CompetitionRequirement500ohmspervolt_const
                    * Referenced by: '<S57>/Constant'
                    */
  real_T CompareToConstant1_const_f;
                                   /* Mask Parameter: CompareToConstant1_const_f
                                    * Referenced by: '<S64>/Constant'
                                    */
  real_T CompareToConstant3_const_n;
                                   /* Mask Parameter: CompareToConstant3_const_n
                                    * Referenced by: '<S66>/Constant'
                                    */
  real_T CompareToConstant_const_i; /* Mask Parameter: CompareToConstant_const_i
                                     * Referenced by: '<S34>/Constant'
                                     */
  real_T checksforLowSpeedCruiseChargeMode_const;
                      /* Mask Parameter: checksforLowSpeedCruiseChargeMode_const
                       * Referenced by: '<S37>/Constant'
                       */
  real_T CompareToConstant_const_p; /* Mask Parameter: CompareToConstant_const_p
                                     * Referenced by: '<S87>/Constant'
                                     */
  real_T CompareToConstant_const_l; /* Mask Parameter: CompareToConstant_const_l
                                     * Referenced by: '<S134>/Constant'
                                     */
  real_T SOCChargeLimit_const;         /* Mask Parameter: SOCChargeLimit_const
                                        * Referenced by: '<S139>/Constant'
                                        */
  real_T CompareToConstant_const_pi;
                                   /* Mask Parameter: CompareToConstant_const_pi
                                    * Referenced by: '<S55>/Constant'
                                    */
  real_T CheckForLaunchMode_const;   /* Mask Parameter: CheckForLaunchMode_const
                                      * Referenced by: '<S118>/Constant'
                                      */
  real_T CompareToConstant1_const_l;
                                   /* Mask Parameter: CompareToConstant1_const_l
                                    * Referenced by: '<S107>/Constant'
                                    */
  real_T CompareToConstant2_const_k;
                                   /* Mask Parameter: CompareToConstant2_const_k
                                    * Referenced by: '<S108>/Constant'
                                    */
  real_T CreepTorqueThreshold_Nm_const;
                                /* Mask Parameter: CreepTorqueThreshold_Nm_const
                                 * Referenced by: '<S116>/Constant'
                                 */
  real_T ChargeSOCLimit_const;         /* Mask Parameter: ChargeSOCLimit_const
                                        * Referenced by: '<S125>/Constant'
                                        */
  real_T DischargingSOCLimit_const; /* Mask Parameter: DischargingSOCLimit_const
                                     * Referenced by: '<S128>/Constant'
                                     */
  real_T checksifregenmode_const;     /* Mask Parameter: checksifregenmode_const
                                       * Referenced by: '<S121>/Constant'
                                       */
  real_T checksiflowspeedCruiseChargingmode_const;
                     /* Mask Parameter: checksiflowspeedCruiseChargingmode_const
                      * Referenced by: '<S120>/Constant'
                      */
  real_T checksifcruisechargingmode_const;
                             /* Mask Parameter: checksifcruisechargingmode_const
                              * Referenced by: '<S119>/Constant'
                              */
  real_T CompareToConstant_const_m; /* Mask Parameter: CompareToConstant_const_m
                                     * Referenced by: '<S84>/Constant'
                                     */
  real_T LaunchModeCheck_const;        /* Mask Parameter: LaunchModeCheck_const
                                        * Referenced by: '<S53>/Constant'
                                        */
  real_T BPPCheck_const;               /* Mask Parameter: BPPCheck_const
                                        * Referenced by: '<S52>/Constant'
                                        */
  real_T CompareToConstant2_const_g;
                                   /* Mask Parameter: CompareToConstant2_const_g
                                    * Referenced by: '<S136>/Constant'
                                    */
  int16_T CheckForDrive_const;         /* Mask Parameter: CheckForDrive_const
                                        * Referenced by: '<S71>/Constant'
                                        */
  int16_T CheckForReverse_const_b;    /* Mask Parameter: CheckForReverse_const_b
                                       * Referenced by: '<S72>/Constant'
                                       */
  int16_T CheckForDrive1_const;        /* Mask Parameter: CheckForDrive1_const
                                        * Referenced by: '<S76>/Constant'
                                        */
  int16_T CheckForReverse2_const;      /* Mask Parameter: CheckForReverse2_const
                                        * Referenced by: '<S80>/Constant'
                                        */
  int16_T CheckForPark1_const;         /* Mask Parameter: CheckForPark1_const
                                        * Referenced by: '<S78>/Constant'
                                        */
  int16_T CheckForNeutral_const;       /* Mask Parameter: CheckForNeutral_const
                                        * Referenced by: '<S77>/Constant'
                                        */
  int16_T CompareToConstant1_const_c;
                                   /* Mask Parameter: CompareToConstant1_const_c
                                    * Referenced by: '<S16>/Constant'
                                    */
  int16_T CompareToConstant2_const_a;
                                   /* Mask Parameter: CompareToConstant2_const_a
                                    * Referenced by: '<S17>/Constant'
                                    */
  int16_T ChecksforDrive_const;        /* Mask Parameter: ChecksforDrive_const
                                        * Referenced by: '<S103>/Constant'
                                        */
  int16_T ChecksforShftLvrPosUnknown_const;
                             /* Mask Parameter: ChecksforShftLvrPosUnknown_const
                              * Referenced by: '<S105>/Constant'
                              */
  int16_T ChecksforShftLvrPosReverse_const;
                             /* Mask Parameter: ChecksforShftLvrPosReverse_const
                              * Referenced by: '<S104>/Constant'
                              */
  int16_T Reverse_const;               /* Mask Parameter: Reverse_const
                                        * Referenced by: '<S114>/Constant'
                                        */
  int16_T ChecksforDrive_const_p;      /* Mask Parameter: ChecksforDrive_const_p
                                        * Referenced by: '<S96>/Constant'
                                        */
  int16_T ChecksforShftLvrPosUnknown_const_a;
                           /* Mask Parameter: ChecksforShftLvrPosUnknown_const_a
                            * Referenced by: '<S98>/Constant'
                            */
  int16_T ChecksforReverse_const;      /* Mask Parameter: ChecksforReverse_const
                                        * Referenced by: '<S97>/Constant'
                                        */
  boolean_T CompareToConstant1_const_g;
                                   /* Mask Parameter: CompareToConstant1_const_g
                                    * Referenced by: '<S135>/Constant'
                                    */
  boolean_T CompareToConstant_const_ph;
                                   /* Mask Parameter: CompareToConstant_const_ph
                                    * Referenced by: '<S106>/Constant'
                                    */
  boolean_T CompareToConstant3_const_p;
                                   /* Mask Parameter: CompareToConstant3_const_p
                                    * Referenced by: '<S137>/Constant'
                                    */
  uint8_T CheckforkeyinRun_const;      /* Mask Parameter: CheckforkeyinRun_const
                                        * Referenced by: '<S102>/Constant'
                                        */
  uint8_T CompareToConstant_const_f;/* Mask Parameter: CompareToConstant_const_f
                                     * Referenced by: '<S94>/Constant'
                                     */
  real_T SetSpdMPS_Value;              /* Expression: 30
                                        * Referenced by: '<S1>/SetSpdMPS'
                                        */
  real_T Gain_Gain;                    /* Expression: 3.6
                                        * Referenced by: '<S1>/Gain'
                                        */
  real_T FarDistanceTarget_tableData[17];/* Expression: [16.25
                                            44.56317707
                                            64.06838293
                                            75.8825254
                                            80.10002454
                                            80.50669961
                                            80.87066587
                                            81.20256997
                                            81.50928852
                                            81.79556284
                                            82.06482303
                                            82.31964387
                                            82.56201559
                                            82.79351362
                                            83.01540995
                                            83.22874884
                                            83.43439983
                                            ]
                                          * Referenced by: '<S22>/FarDistanceTarget'
                                          */
  real_T FarDistanceTarget_bp01Data[17];/* Expression: [0:5:80]
                                         * Referenced by: '<S22>/FarDistanceTarget'
                                         */
  real_T MediumDistanceTarget_tableData[17];
  /* Expression: [12.5	34.12635414	48.13676586	56.7650508	60.20004909	61.01339923	61.74133173	62.40513994	63.01857703	63.59112569	64.12964606	64.63928775	65.12403117	65.58702723	66.03081991	66.45749768	66.86879967
     ]
   * Referenced by: '<S22>/MediumDistanceTarget'
   */
  real_T MediumDistanceTarget_bp01Data[17];/* Expression: [0:5:80]
                                            * Referenced by: '<S22>/MediumDistanceTarget'
                                            */
  real_T NearDistanceTarget_tableData[17];/* Expression: [8.75
                                             23.6895312
                                             32.20514879
                                             37.6475762
                                             40.30007363
                                             41.52009884
                                             42.6119976
                                             43.60770991
                                             44.52786555
                                             45.38668853
                                             46.1944691
                                             46.95893162
                                             47.68604676
                                             48.38054085
                                             49.04622986
                                             49.68624651
                                             50.3031995
                                             ]
                                           * Referenced by: '<S22>/NearDistanceTarget'
                                           */
  real_T NearDistanceTarget_bp01Data[17];/* Expression: [0:5:80]
                                          * Referenced by: '<S22>/NearDistanceTarget'
                                          */
  real_T DiscreteMotorPowerLimit1_tableData[22];/* Expression: [0
                                                   7800
                                                   24079
                                                   44373
                                                   64324
                                                   81523
                                                   85995
                                                   84275
                                                   82211
                                                   79803
                                                   79459
                                                   78428
                                                   77740
                                                   77740
                                                   76020
                                                   76708
                                                   60197
                                                   42654
                                                   29926
                                                   18575
                                                   10319
                                                   688]
                                                 * Referenced by: '<S2>/DiscreteMotorPowerLimit1'
                                                 */
  real_T DiscreteMotorPowerLimit1_bp01Data[22];/* Expression: [0
                                                  290.9
                                                  916.4
                                                  1643.6
                                                  2385.5
                                                  3040
                                                  3461.8
                                                  3898.2
                                                  4392.7
                                                  5018.2
                                                  5861.8
                                                  6574.5
                                                  7941.8
                                                  8640
                                                  9309.1
                                                  10050.9
                                                  10181.8
                                                  10283.6
                                                  10341.8
                                                  10429.1
                                                  10458.2
                                                  10538.2]
                                                * Referenced by: '<S2>/DiscreteMotorPowerLimit1'
                                                */
  real_T ContinuousMotorPowerLimit3_tableData[22];/* Expression: [0
                                                     4138
                                                     7586
                                                     14138
                                                     20000
                                                     26552
                                                     32069
                                                     35862
                                                     39655
                                                     41034
                                                     44138
                                                     45862
                                                     44828
                                                     43793
                                                     41034
                                                     38276
                                                     34483
                                                     30690
                                                     28276
                                                     18966
                                                     10000
                                                     1379]
                                                   * Referenced by: '<S2>/ContinuousMotorPowerLimit3'
                                                   */
  real_T ContinuousMotorPowerLimit3_bp01Data[22];/* Expression: [0
                                                    363.6
                                                    829.1
                                                    1483.6
                                                    2254.5
                                                    2981.8
                                                    3709.1
                                                    4363.6
                                                    4945.5
                                                    5367.3
                                                    5905.5
                                                    6865.5
                                                    7403.6
                                                    8029.1
                                                    8625.5
                                                    9221.8
                                                    9803.6
                                                    10109.1
                                                    10370.9
                                                    10429.1
                                                    10472.7
                                                    10538.2]
                                                  * Referenced by: '<S2>/ContinuousMotorPowerLimit3'
                                                  */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S2>/Constant1'
                                        */
  real_T DiscreteMotorPowerLimit_tableData[22];/* Expression: [0
                                                  8943
                                                  24079
                                                  44373
                                                  64324
                                                  81523
                                                  85995
                                                  84275
                                                  82211
                                                  79803
                                                  79459
                                                  78428
                                                  77740
                                                  77740
                                                  76020
                                                  76708
                                                  60197
                                                  42654
                                                  29926
                                                  18575
                                                  10319
                                                  688]
                                                * Referenced by: '<S2>/DiscreteMotorPowerLimit'
                                                */
  real_T DiscreteMotorPowerLimit_bp01Data[22];/* Expression: [0
                                                 290.9
                                                 916.4
                                                 1643.6
                                                 2385.5
                                                 3040
                                                 3461.8
                                                 3898.2
                                                 4392.7
                                                 5018.2
                                                 5861.8
                                                 6574.5
                                                 7941.8
                                                 8640
                                                 9309.1
                                                 10050.9
                                                 10181.8
                                                 10283.6
                                                 10341.8
                                                 10429.1
                                                 10458.2
                                                 10538.2]
                                               * Referenced by: '<S2>/DiscreteMotorPowerLimit'
                                               */
  real_T ContinuousMotorPowerLimit1_tableData[22];/* Expression: [0
                                                     4138
                                                     7586
                                                     14138
                                                     20000
                                                     26552
                                                     32069
                                                     35862
                                                     39655
                                                     41034
                                                     44138
                                                     45862
                                                     44828
                                                     43793
                                                     41034
                                                     38276
                                                     34483
                                                     30690
                                                     28276
                                                     18966
                                                     10000
                                                     1379]
                                                   * Referenced by: '<S2>/ContinuousMotorPowerLimit1'
                                                   */
  real_T ContinuousMotorPowerLimit1_bp01Data[22];/* Expression: [0
                                                    363.6
                                                    829.1
                                                    1483.6
                                                    2254.5
                                                    2981.8
                                                    3709.1
                                                    4363.6
                                                    4945.5
                                                    5367.3
                                                    5905.5
                                                    6865.5
                                                    7403.6
                                                    8029.1
                                                    8625.5
                                                    9221.8
                                                    9803.6
                                                    10109.1
                                                    10370.9
                                                    10429.1
                                                    10472.7
                                                    10538.2]
                                                  * Referenced by: '<S2>/ContinuousMotorPowerLimit1'
                                                  */
  real_T Constant_Value;               /* Expression: 20
                                        * Referenced by: '<S2>/Constant'
                                        */
  real_T Constant_Value_i;             /* Expression: 1
                                        * Referenced by: '<S35>/Constant'
                                        */
  real_T kphtomph_Gain;                /* Expression: 0.621371
                                        * Referenced by: '<S2>/kph to mph'
                                        */
  real_T VehicleSpeedMultiplier_tableData[6];
                                     /* Expression: [0 0.05 0.10 0.15 0.20 0.20]
                                      * Referenced by: '<S35>/Vehicle Speed Multiplier'
                                      */
  real_T VehicleSpeedMultiplier_bp01Data[6];/* Expression: [7 10 15 20 25 30]
                                             * Referenced by: '<S35>/Vehicle Speed Multiplier'
                                             */
  real_T FinalDrive_Gain;              /* Expression: 3.8
                                        * Referenced by: '<S5>/FinalDrive'
                                        */
  real_T Saturation_UpperSat;          /* Expression: inf
                                        * Referenced by: '<S5>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 52
                                        * Referenced by: '<S5>/Saturation'
                                        */
  real_T Gain4_Gain;                   /* Expression: 30/pi
                                        * Referenced by: '<S5>/Gain4'
                                        */
  real_T uDLookupTable1_tableData[40]; /* Expression: [0 max(f_tbrake(:,2:end))]
                                        * Referenced by: '<S5>/1-D Lookup Table1'
                                        */
  real_T Gain_Gain_i;                  /* Expression: -1
                                        * Referenced by: '<S89>/Gain'
                                        */
  real_T uDLookupTable1_bp01Data[1001];/* Expression: [0:0.0005:0.5]
                                        * Referenced by: '<S110>/1-D Lookup Table1'
                                        */
  real_T SOCOkay_Value;                /* Expression: 1
                                        * Referenced by: '<S115>/SOC Okay'
                                        */
  real_T Switch_Threshold;             /* Expression: 0.5
                                        * Referenced by: '<S110>/Switch'
                                        */
  real_T MotorEnable_Value;            /* Expression: 1
                                        * Referenced by: '<S5>/Motor Enable'
                                        */
  real_T uDLookupCreepTrq_Nm_tableData[2];/* Expression: [6
                                             9]
                                           * Referenced by: '<S109>/1-D Lookup Creep Trq_Nm'
                                           */
  real_T uDLookupCreepTrq_Nm_bp01Data[2];/* Expression: [0 7]
                                          * Referenced by: '<S109>/1-D Lookup Creep Trq_Nm'
                                          */
  real_T Constant_Value_ij;            /* Expression: 0
                                        * Referenced by: '<S109>/Constant'
                                        */
  real_T Constant1_Value_h;            /* Expression: 0
                                        * Referenced by: '<S89>/Constant1'
                                        */
  real_T RPM_to_rads_Gain;             /* Expression: pi/30
                                        * Referenced by: '<S89>/RPM_to_rad//s'
                                        */
  real_T preventsdividingbyzero_UpperSat;/* Expression: 3435
                                          * Referenced by: '<S89>/prevents dividing by zero'
                                          */
  real_T preventsdividingbyzero_LowerSat;/* Expression: 1
                                          * Referenced by: '<S89>/prevents dividing by zero'
                                          */
  real_T LoadTorqueNm_Value;           /* Expression: 30
                                        * Referenced by: '<S112>/Load Torque Nm'
                                        */
  real_T Constant1_Value_j;            /* Expression: 0
                                        * Referenced by: '<S9>/Constant1'
                                        */
  real_T VehicleSpeedFadeOut_tableData[3];/* Expression: [0 0 1]
                                           * Referenced by: '<S9>/Vehicle Speed Fade Out'
                                           */
  real_T VehicleSpeedFadeOut_bp01Data[3];/* Expression: [0 15 25]
                                          * Referenced by: '<S9>/Vehicle Speed Fade Out'
                                          */
  real_T uDLookupTable2_tableData[2];  /* Expression: [0 1]
                                        * Referenced by: '<S9>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp01Data[2];   /* Expression: [0 20]
                                        * Referenced by: '<S9>/1-D Lookup Table2'
                                        */
  real_T uDLookupTable1_tableData_b[3];/* Expression: [0 0 1]
                                        * Referenced by: '<S9>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp01Data_m[3]; /* Expression: [0 20 25]
                                        * Referenced by: '<S9>/1-D Lookup Table1'
                                        */
  real_T uDLookupTable_tableData[3];   /* Expression: [0 0.1 1]
                                        * Referenced by: '<S9>/1-D Lookup Table'
                                        */
  real_T uDLookupTable_bp01Data[3];    /* Expression: [0 20 25]
                                        * Referenced by: '<S9>/1-D Lookup Table'
                                        */
  real_T OffThrottleRegenPowerDemandW_Value;/* Expression: -5000
                                             * Referenced by: '<S9>/Off Throttle Regen Power Demand W'
                                             */
  real_T MaxBPPRegenW_Value;           /* Expression: -15000
                                        * Referenced by: '<S9>/Max BPP Regen W'
                                        */
  real_T Gain_Gain_c;                  /* Expression: 1/3.6
                                        * Referenced by: '<S9>/Gain'
                                        */
  real_T VehicleMass_Value;            /* Expression: 2400
                                        * Referenced by: '<S9>/Vehicle Mass'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 0
                                        * Referenced by: '<S9>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -20000
                                        * Referenced by: '<S9>/Saturation1'
                                        */
  real_T rbcp_regen_enable_Gain;       /* Expression: 1
                                        * Referenced by: '<S9>/rbcp_regen_enable'
                                        */
  real_T Constant_Value_b;             /* Expression: 0
                                        * Referenced by: '<S85>/Constant'
                                        */
  real_T Constant_Value_n;             /* Expression: 0
                                        * Referenced by: '<S122>/Constant'
                                        */
  real_T Constant_Value_o;             /* Expression: 0
                                        * Referenced by: '<S123>/Constant'
                                        */
  real_T Constant_Value_f;             /* Expression: 0
                                        * Referenced by: '<S126>/Constant'
                                        */
  real_T Constant_Value_o5;            /* Expression: 0
                                        * Referenced by: '<S127>/Constant'
                                        */
  real_T ActivateMILHILVersion_Value;  /* Expression: 1
                                        * Referenced by: '<S6>/Activate MIL//HIL Version'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S1>/Switch2'
                                        */
  real_T Gain5_Gain;                   /* Expression: 0.621371
                                        * Referenced by: '<S1>/Gain5'
                                        */
  real_T kmh2ms1_Gain;                 /* Expression: 0.277778
                                        * Referenced by: '<S1>/km//h2m//s1'
                                        */
  real_T DiscreteTimeIntegrator_gainval;
                           /* Computed Parameter: DiscreteTimeIntegrator_gainval
                            * Referenced by: '<S21>/Discrete-Time Integrator'
                            */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S21>/Discrete-Time Integrator'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator1_gainval
                           * Referenced by: '<S21>/Discrete-Time Integrator1'
                           */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S21>/Discrete-Time Integrator1'
                                        */
  real_T TargetInitialPos_Value;       /* Expression: 3
                                        * Referenced by: '<S21>/TargetInitialPos'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S21>/Switch1'
                                        */
  real_T Switch_Threshold_g;           /* Expression: 0
                                        * Referenced by: '<S21>/Switch'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S19>/Memory'
                                        */
  real_T Gain_Gain_iu;                 /* Expression: 2.23694
                                        * Referenced by: '<S22>/Gain'
                                        */
  real_T DelayOneStep1_InitialCondition;/* Expression: 0.0
                                         * Referenced by: '<S22>/Delay One Step1'
                                         */
  real_T DelayOneStep_InitialCondition;/* Expression: 0.0
                                        * Referenced by: '<S22>/Delay One Step'
                                        */
  real_T Gain1_Gain;                   /* Expression: 2.23694
                                        * Referenced by: '<S22>/Gain1'
                                        */
  real_T kphtomps_Gain;                /* Expression: 0.277778
                                        * Referenced by: '<S3>/kph to mps'
                                        */
  real_T IC_Value;                     /* Expression: 0
                                        * Referenced by: '<S46>/IC'
                                        */
  real_T Gain_Gain_o;                  /* Expression: 0
                                        * Referenced by: '<S46>/Gain'
                                        */
  real_T Constant_Value_ok;            /* Expression: 0
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S10>/Memory1'
                                        */
  real_T Constant_Value_d;             /* Expression: 0
                                        * Referenced by: '<S42>/Constant'
                                        */
  real_T Memory7_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S41>/Memory7'
                                        */
  real_T kohmstoohms_Gain;             /* Expression: 1000
                                        * Referenced by: '<S41>/kohms to ohms'
                                        */
  real_T closedcontactorbatteryrange_UpperSat;/* Expression: 360
                                               * Referenced by: '<S41>/closed contactor battery range'
                                               */
  real_T closedcontactorbatteryrange_LowerSat;/* Expression: 200
                                               * Referenced by: '<S41>/closed contactor battery range'
                                               */
  real_T Constant_Value_p;             /* Expression: 0
                                        * Referenced by: '<S47>/Constant'
                                        */
  real_T Switch1_Threshold_j;          /* Expression: 0
                                        * Referenced by: '<S1>/Switch1'
                                        */
  real_T Gain_Gain_k;                  /* Expression: 3.6
                                        * Referenced by: '<S19>/Gain'
                                        */
  real_T Gain1_Gain_c;                 /* Expression: 2.23694
                                        * Referenced by: '<S19>/Gain1'
                                        */
  real_T Gain1_Gain_a;                 /* Expression: 100
                                        * Referenced by: '<S1>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: 100
                                        * Referenced by: '<S1>/Gain2'
                                        */
  real_T Memory_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S2>/Memory'
                                        */
  real_T Memory1_InitialCondition_m;   /* Expression: 0
                                        * Referenced by: '<S2>/Memory1'
                                        */
  real_T Mass2550_bp01Data[8];         /* Expression: [0:10:50,60,100]
                                        * Referenced by: '<S4>/Mass 2550'
                                        */
  real_T Mass2550_bp02Data[17];
              /* Expression: [0	2	4	6	10	20	30	40	50	60	70	80	90	100	120	140	180
                 ]
               * Referenced by: '<S4>/Mass 2550'
               */
  real_T Saturation2_UpperSat;         /* Expression: inf
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: 0
                                        * Referenced by: '<S4>/Saturation2'
                                        */
  real_T BrusaEnable_Value;            /* Expression: 0
                                        * Referenced by: '<S10>/Brusa Enable'
                                        */
  real_T kphtomph_Gain_i;              /* Expression: 0.621371
                                        * Referenced by: '<S10>/kph to mph'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S35>/Constant2'
                                        */
  real_T psoc_table_SOC_offset_Value;  /* Expression: 5
                                        * Referenced by: '<S35>/psoc_table_SOC_offset'
                                        */
  real_T TargetSOC_Value;              /* Expression: 70
                                        * Referenced by: '<S2>/Target SOC'
                                        */
  real_T Constant3_Value;              /* Expression: 100
                                        * Referenced by: '<S35>/Constant3'
                                        */
  real_T Constant4_Value;              /* Expression: -20000
                                        * Referenced by: '<S35>/Constant4'
                                        */
  real_T Constant1_Value_b;            /* Expression: 0
                                        * Referenced by: '<S35>/Constant1'
                                        */
  real_T Constant7_Value;              /* Expression: 20000
                                        * Referenced by: '<S35>/Constant7'
                                        */
  real_T kphtomps_Gain_g;              /* Expression: 1000/3600
                                        * Referenced by: '<S4>/kph to mps'
                                        */
  real_T preventszeroingPwrDmdat0kph_UpperSat;/* Expression: 250
                                               * Referenced by: '<S4>/prevents zeroing Pwr Dmd at 0 kph'
                                               */
  real_T preventszeroingPwrDmdat0kph_LowerSat;/* Expression: 1
                                               * Referenced by: '<S4>/prevents zeroing Pwr Dmd at 0 kph'
                                               */
  real_T Switch_Threshold_k;           /* Expression: 0.5
                                        * Referenced by: '<S4>/Switch'
                                        */
  real_T kphtomph_Gain_c;              /* Expression: 0.621371
                                        * Referenced by: '<S9>/kph to mph'
                                        */
  real_T SteeringWheelAngleFadeOut_tableData[4];/* Expression: [0 1 1 0]
                                                 * Referenced by: '<S9>/Steering Wheel Angle Fade Out'
                                                 */
  real_T SteeringWheelAngleFadeOut_bp01Data[4];/* Expression: [-100 -50 50 100]
                                                * Referenced by: '<S9>/Steering Wheel Angle Fade Out'
                                                */
  real_T FixPtConstant_Value;          /* Expression: 1
                                        * Referenced by: '<S93>/FixPt Constant'
                                        */
  real_T kphtomph_Gain_e;              /* Expression: 0.277778
                                        * Referenced by: '<S5>/kph to mph'
                                        */
  real_T Switch_Threshold_f;           /* Expression: 0
                                        * Referenced by: '<S5>/Switch'
                                        */
  real_T Saturation1_UpperSat_n;       /* Expression: inf
                                        * Referenced by: '<S5>/Saturation1'
                                        */
  real_T Saturation1_LowerSat_p;       /* Expression: 1
                                        * Referenced by: '<S5>/Saturation1'
                                        */
  real_T Switch_Threshold_n;           /* Expression: 0
                                        * Referenced by: '<S2>/Switch'
                                        */
  real_T uDLookupTable_bp01Data_m[10]; /* Expression: [-30:10:60]
                                        * Referenced by: '<S2>/2-D Lookup Table'
                                        */
  real_T uDLookupTable_bp02Data[11];   /* Expression: [0:10:100]
                                        * Referenced by: '<S2>/2-D Lookup Table'
                                        */
  real_T IC6_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC6'
                                        */
  real_T IC_Value_h;                   /* Expression: 0
                                        * Referenced by: '<S2>/IC'
                                        */
  real_T ContinuousDischageLimit_bp01Data[10];/* Expression: [-30:10:60]
                                               * Referenced by: '<S2>/ContinuousDischageLimit'
                                               */
  real_T ContinuousDischageLimit_bp02Data[11];/* Expression: [0:10:100]
                                               * Referenced by: '<S2>/ContinuousDischageLimit'
                                               */
  real_T IC5_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC5'
                                        */
  real_T ContinuousMotorPowerLimit_tableData[22];/* Expression: [0
                                                    4138
                                                    7586
                                                    14138
                                                    20000
                                                    26552
                                                    32069
                                                    35862
                                                    39655
                                                    41034
                                                    44138
                                                    45862
                                                    44828
                                                    43793
                                                    41034
                                                    38276
                                                    34483
                                                    30690
                                                    28276
                                                    18966
                                                    10000
                                                    1379]
                                                  * Referenced by: '<S2>/ContinuousMotorPowerLimit'
                                                  */
  real_T ContinuousMotorPowerLimit_bp01Data[22];/* Expression: [0
                                                   363.6
                                                   829.1
                                                   1483.6
                                                   2254.5
                                                   2981.8
                                                   3709.1
                                                   4363.6
                                                   4945.5
                                                   5367.3
                                                   5905.5
                                                   6865.5
                                                   7403.6
                                                   8029.1
                                                   8625.5
                                                   9221.8
                                                   9803.6
                                                   10109.1
                                                   10370.9
                                                   10429.1
                                                   10472.7
                                                   10538.2]
                                                 * Referenced by: '<S2>/ContinuousMotorPowerLimit'
                                                 */
  real_T IC2_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC2'
                                        */
  real_T IC1_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC1'
                                        */
  real_T ContinuousMotorPowerLimit2_tableData[22];/* Expression: [0
                                                     4138
                                                     7586
                                                     14138
                                                     20000
                                                     26552
                                                     32069
                                                     35862
                                                     39655
                                                     41034
                                                     44138
                                                     45862
                                                     44828
                                                     43793
                                                     41034
                                                     38276
                                                     34483
                                                     30690
                                                     28276
                                                     18966
                                                     10000
                                                     1379]
                                                   * Referenced by: '<S2>/ContinuousMotorPowerLimit2'
                                                   */
  real_T ContinuousMotorPowerLimit2_bp01Data[22];/* Expression: [0
                                                    363.6
                                                    829.1
                                                    1483.6
                                                    2254.5
                                                    2981.8
                                                    3709.1
                                                    4363.6
                                                    4945.5
                                                    5367.3
                                                    5905.5
                                                    6865.5
                                                    7403.6
                                                    8029.1
                                                    8625.5
                                                    9221.8
                                                    9803.6
                                                    10109.1
                                                    10370.9
                                                    10429.1
                                                    10472.7
                                                    10538.2]
                                                  * Referenced by: '<S2>/ContinuousMotorPowerLimit2'
                                                  */
  real_T Gain19_Gain;                  /* Expression: 0.621371
                                        * Referenced by: '<S89>/Gain19'
                                        */
  real_T T1startofcompensation_bp01Data[7];/* Expression: [1:1:7]
                                            * Referenced by: '<S89>/T1 (start of compensation)'
                                            */
  real_T T1startofcompensation_bp02Data[5];/* Expression: [10:10:50]
                                            * Referenced by: '<S89>/T1 (start of compensation)'
                                            */
  real_T T2timeaftert1tofulltorque_bp01Data[7];/* Expression: [1:1:7]
                                                * Referenced by: '<S89>/T2 (time after t1 to full torque)'
                                                */
  real_T T2timeaftert1tofulltorque_bp02Data[5];/* Expression: [10:10:50]
                                                * Referenced by: '<S89>/T2 (time after t1 to full torque)'
                                                */
  real_T T3timebeforet4tolowertorque_bp01Data[7];/* Expression: [1:1:7]
                                                  * Referenced by: '<S89>/T3 (time before t4 to lower torque)'
                                                  */
  real_T T3timebeforet4tolowertorque_bp02Data[5];/* Expression: [10:10:50]
                                                  * Referenced by: '<S89>/T3 (time before t4 to lower torque)'
                                                  */
  real_T T4directtimetoendcompensation_bp01Data[7];/* Expression: [1:1:7]
                                                    * Referenced by: '<S89>/T4 (direct time to end compensation)'
                                                    */
  real_T T4directtimetoendcompensation_bp02Data[5];/* Expression: [10:10:50]
                                                    * Referenced by: '<S89>/T4 (direct time to end compensation)'
                                                    */
  real_T Saturation_UpperSat_c;        /* Expression: 1
                                        * Referenced by: '<S89>/Saturation'
                                        */
  real_T Saturation_LowerSat_p;        /* Expression: 0
                                        * Referenced by: '<S89>/Saturation'
                                        */
  real_T TorqueAdditionTable_bp01Data[7];/* Expression: [1:1:7]
                                          * Referenced by: '<S89>/TorqueAdditionTable'
                                          */
  real_T TorqueAdditionTable_bp02Data[5];/* Expression: [10:10:50]
                                          * Referenced by: '<S89>/TorqueAdditionTable'
                                          */
  real_T kphtomps_Gain_i;              /* Expression: 0.277778
                                        * Referenced by: '<S5>/kph to mps'
                                        */
  real_T Gain1_Gain_k;                 /* Expression: -1
                                        * Referenced by: '<S5>/Gain1'
                                        */
  real_T DelayOneStep_InitialCondition_a;/* Expression: 0.0
                                          * Referenced by: '<S110>/Delay One Step'
                                          */
  real_T Constant_Value_ic;            /* Expression: 0
                                        * Referenced by: '<S90>/Constant'
                                        */
  real_T kphtomps1_Gain;               /* Expression: 0.277778
                                        * Referenced by: '<S5>/kph to mps1'
                                        */
  real_T preventsdividingbyzero_UpperSat_a;/* Expression: 1050
                                            * Referenced by: '<S88>/prevents dividing by zero'
                                            */
  real_T preventsdividingbyzero_LowerSat_n;/* Expression: 1
                                            * Referenced by: '<S88>/prevents dividing by zero'
                                            */
  real_T Saturation_UpperSat_a;        /* Expression: inf
                                        * Referenced by: '<S88>/Saturation'
                                        */
  real_T Saturation_LowerSat_pg;       /* Expression: 0
                                        * Referenced by: '<S88>/Saturation'
                                        */
  real_T Constant_Value_m;             /* Expression: 0
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T VMUmajorProt_Value;           /* Expression: 4
                                        * Referenced by: '<S10>/VMUmajorProt'
                                        */
  real_T VMUminorProt_Value;           /* Expression: 1
                                        * Referenced by: '<S10>/VMUminorProt'
                                        */
  real_T Gain2_Gain_p;                 /* Expression: 1
                                        * Referenced by: '<S7>/Gain2'
                                        */
  real_T Gain_Gain_f;                  /* Expression: 1
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Gain3_Gain;                   /* Expression: 1
                                        * Referenced by: '<S7>/Gain3'
                                        */
  real_T Gain1_Gain_i;                 /* Expression: 1
                                        * Referenced by: '<S7>/Gain1'
                                        */
  real_T IC_Value_b;                   /* Expression: 0
                                        * Referenced by: '<S50>/IC'
                                        */
  real_T IC3_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC3'
                                        */
  real_T IC4_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC4'
                                        */
  real_T Switch3_Threshold;            /* Expression: 10
                                        * Referenced by: '<S2>/Switch3'
                                        */
  real_T uDLookupTable5_bp01Data[10];  /* Expression: [-30:10:60]
                                        * Referenced by: '<S2>/2-D Lookup Table5'
                                        */
  real_T uDLookupTable5_bp02Data[11];  /* Expression: [0:10:100]
                                        * Referenced by: '<S2>/2-D Lookup Table5'
                                        */
  real_T uDLookupTable5_bp03Data[2];   /* Expression: [10,60]
                                        * Referenced by: '<S2>/2-D Lookup Table5'
                                        */
  real_T IC8_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC8'
                                        */
  real_T IC7_Value;                    /* Expression: 0
                                        * Referenced by: '<S2>/IC7'
                                        */
  real_T Switch1_Threshold_d;          /* Expression: 10
                                        * Referenced by: '<S2>/Switch1'
                                        */
  real_T uDLookupTable2_bp01Data_k[10];/* Expression: [-30:10:60]
                                        * Referenced by: '<S2>/2-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp02Data[11];  /* Expression: [0:10:100]
                                        * Referenced by: '<S2>/2-D Lookup Table2'
                                        */
  real_T uDLookupTable2_bp03Data[2];   /* Expression: [10,60]
                                        * Referenced by: '<S2>/2-D Lookup Table2'
                                        */
  real_T Gain1_Gain_o;                 /* Expression: -1
                                        * Referenced by: '<S2>/Gain1'
                                        */
  real_T TSamp_WtEt;                   /* Computed Parameter: TSamp_WtEt
                                        * Referenced by: '<S26>/TSamp'
                                        */
  real_T TSamp_WtEt_j;                 /* Computed Parameter: TSamp_WtEt_j
                                        * Referenced by: '<S27>/TSamp'
                                        */
  real_T Constant10_Value;             /* Expression: -2.94
                                        * Referenced by: '<S1>/Constant10'
                                        */
  real_T Memory2_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S3>/Memory2'
                                        */
  uint32_T Mass2550_maxIndex[2];       /* Computed Parameter: Mass2550_maxIndex
                                        * Referenced by: '<S4>/Mass 2550'
                                        */
  uint32_T uDLookupTable_maxIndex[2];
                                   /* Computed Parameter: uDLookupTable_maxIndex
                                    * Referenced by: '<S2>/2-D Lookup Table'
                                    */
  uint32_T ContinuousDischageLimit_maxIndex[2];
                         /* Computed Parameter: ContinuousDischageLimit_maxIndex
                          * Referenced by: '<S2>/ContinuousDischageLimit'
                          */
  uint32_T T1startofcompensation_maxIndex[2];
                           /* Computed Parameter: T1startofcompensation_maxIndex
                            * Referenced by: '<S89>/T1 (start of compensation)'
                            */
  uint32_T T2timeaftert1tofulltorque_maxIndex[2];
                       /* Computed Parameter: T2timeaftert1tofulltorque_maxIndex
                        * Referenced by: '<S89>/T2 (time after t1 to full torque)'
                        */
  uint32_T T3timebeforet4tolowertorque_maxIndex[2];
                     /* Computed Parameter: T3timebeforet4tolowertorque_maxIndex
                      * Referenced by: '<S89>/T3 (time before t4 to lower torque)'
                      */
  uint32_T T4directtimetoendcompensation_maxIndex[2];
                   /* Computed Parameter: T4directtimetoendcompensation_maxIndex
                    * Referenced by: '<S89>/T4 (direct time to end compensation)'
                    */
  uint32_T TorqueAdditionTable_maxIndex[2];
                             /* Computed Parameter: TorqueAdditionTable_maxIndex
                              * Referenced by: '<S89>/TorqueAdditionTable'
                              */
  uint32_T uDLookupTable5_maxIndex[3];
                                  /* Computed Parameter: uDLookupTable5_maxIndex
                                   * Referenced by: '<S2>/2-D Lookup Table5'
                                   */
  uint32_T uDLookupTable5_dimSizes[3];
                                  /* Computed Parameter: uDLookupTable5_dimSizes
                                   * Referenced by: '<S2>/2-D Lookup Table5'
                                   */
  uint32_T uDLookupTable2_maxIndex[3];
                                  /* Computed Parameter: uDLookupTable2_maxIndex
                                   * Referenced by: '<S2>/2-D Lookup Table2'
                                   */
  uint32_T uDLookupTable2_dimSizes[3];
                                  /* Computed Parameter: uDLookupTable2_dimSizes
                                   * Referenced by: '<S2>/2-D Lookup Table2'
                                   */
  boolean_T Denied_Value;              /* Computed Parameter: Denied_Value
                                        * Referenced by: '<S1>/Denied'
                                        */
  boolean_T Change_Value;              /* Computed Parameter: Change_Value
                                        * Referenced by: '<S1>/Change'
                                        */
  boolean_T Constant_Value_k;          /* Computed Parameter: Constant_Value_k
                                        * Referenced by: '<S124>/Constant'
                                        */
  boolean_T IC_Value_m;                /* Computed Parameter: IC_Value_m
                                        * Referenced by: '<S48>/IC'
                                        */
  boolean_T Constant_Value_c;          /* Computed Parameter: Constant_Value_c
                                        * Referenced by: '<S19>/Constant'
                                        */
  boolean_T Constant1_Value_c;         /* Computed Parameter: Constant1_Value_c
                                        * Referenced by: '<S19>/Constant1'
                                        */
  boolean_T Constant2_Value_p;         /* Computed Parameter: Constant2_Value_p
                                        * Referenced by: '<S19>/Constant2'
                                        */
  boolean_T Constant4_Value_c;         /* Computed Parameter: Constant4_Value_c
                                        * Referenced by: '<S19>/Constant4'
                                        */
  boolean_T Constant5_Value;           /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S19>/Constant5'
                                        */
  boolean_T Constant6_Value;           /* Computed Parameter: Constant6_Value
                                        * Referenced by: '<S19>/Constant6'
                                        */
  boolean_T Constant7_Value_i;         /* Computed Parameter: Constant7_Value_i
                                        * Referenced by: '<S19>/Constant7'
                                        */
  boolean_T IC_Value_c;                /* Computed Parameter: IC_Value_c
                                        * Referenced by: '<S39>/IC'
                                        */
  boolean_T Constant3_Value_i;         /* Computed Parameter: Constant3_Value_i
                                        * Referenced by: '<S3>/Constant3'
                                        */
  uint8_T Memory1_InitialCondition_d;
                               /* Computed Parameter: Memory1_InitialCondition_d
                                * Referenced by: '<S3>/Memory1'
                                */
  uint8_T Gain_Gain_g;                 /* Computed Parameter: Gain_Gain_g
                                        * Referenced by: '<S39>/Gain'
                                        */
  P_ACCpedals_HSC_Model_T ACCpedals;   /* '<S12>/ACC pedals' */
};

/* Real-time Model Data Structure */
struct tag_RTM_HSC_Model_T {
  const char_T **errorStatus;
  const rtTimingBridge *timingBridge;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[796];
    int32_T* vardimsAddress[796];
    RTWLoggingFcnPtr loggingPtrs[796];
  } DataMapInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    int_T mdlref_GlobalTID[2];
  } Timing;
};

typedef struct {
  B_HSC_Model_c_T rtb;
  DW_HSC_Model_f_T rtdw;
  RT_MODEL_HSC_Model_T rtm;
} MdlrefDW_HSC_Model_T;

/* Model reference registration function */
extern void HSC_Model_initialize(const char_T **rt_errorStatus, const
  rtTimingBridge *timingBridge, int_T mdlref_TID0, int_T mdlref_TID1,
  RT_MODEL_HSC_Model_T *const HSC_Model_M, B_HSC_Model_c_T *localB,
  DW_HSC_Model_f_T *localDW, rtwCAPI_ModelMappingInfo *rt_ParentMMI, const
  char_T *rt_ChildPath, int_T rt_ChildMMIIdx, int_T rt_CSTATEIdx);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  HSC_Model_GetCAPIStaticMap(void);
extern void HSC_Model_Chart_Init(DW_Chart_HSC_Model_T *localDW);
extern void HSC_Model_Chart_Reset(DW_Chart_HSC_Model_T *localDW);
extern void HSC_Model_Chart(real_T rtu_CurrentDemanded, real_T
  rtu_ContinuousCurrentLimit, B_Chart_HSC_Model_T *localB, DW_Chart_HSC_Model_T *
  localDW);
extern void HSC_Model_ABSRegenOff_Init(DW_ABSRegenOff_HSC_Model_T *localDW);
extern void HSC_Model_ABSRegenOff_Reset(DW_ABSRegenOff_HSC_Model_T *localDW);
extern void HSC_Model_ABSRegenOff(boolean_T rtu_Fault, B_ABSRegenOff_HSC_Model_T
  *localB, DW_ABSRegenOff_HSC_Model_T *localDW);
extern void HSC_Model_OverVoltage_Init(DW_OverVoltage_HSC_Model_T *localDW);
extern void HSC_Model_OverVoltage_Reset(DW_OverVoltage_HSC_Model_T *localDW);
extern void HSC_Model_OverVoltage(uint8_T rtu_key_status, boolean_T rtu_Fault,
  real_T rtu_Battery_Contactors, B_OverVoltage_HSC_Model_T *localB,
  DW_OverVoltage_HSC_Model_T *localDW);
extern void HSC_Model_Faultcounter1_Init(B_Faultcounter1_HSC_Model_T *localB,
  DW_Faultcounter1_HSC_Model_T *localDW);
extern void HSC_Model_Faultcounter1_Reset(B_Faultcounter1_HSC_Model_T *localB,
  DW_Faultcounter1_HSC_Model_T *localDW);
extern void HSC_Model_Faultcounter1(real_T rtu_err, uint8_T rtu_key_status,
  B_Faultcounter1_HSC_Model_T *localB, DW_Faultcounter1_HSC_Model_T *localDW);
extern void HSC_Model_Init(B_HSC_Model_c_T *localB, DW_HSC_Model_f_T *localDW);
extern void HSC_Model_Reset(B_HSC_Model_c_T *localB, DW_HSC_Model_f_T *localDW);
extern void HSC_Model(RT_MODEL_HSC_Model_T * const HSC_Model_M, const real_T
                      *rtu_In_ABSAtv, const real_T *rtu_In_APP, const real_T
                      *rtu_In_APPv, const real_T *rtu_In_BPP, const real_T
                      *rtu_In_EngRunAtv, const real_T *rtu_In_EngSpd, const
                      real_T *rtu_In_Gear, const real_T *rtu_In_HdSt, const
                      real_T *rtu_In_KeySt, const real_T *rtu_In_gfd, const
                      real_T *rtu_In_McuThermal, const real_T *rtu_In_MotorSpd,
                      const real_T *rtu_In_MotorTrqEst, const real_T *rtu_In_SOC,
                      const real_T *rtu_In_StateMcu, const real_T
                      *rtu_In_StrWhAng, const real_T *rtu_In_StrWhAngV, const
                      real_T *rtu_In_TrnsShftPos, const real_T *rtu_In_VehSpd,
                      const real_T *rtu_In_battTcoolant, const real_T
                      *rtu_In_bcmready, const real_T *rtu_In_cpwrcmd, const
                      real_T *rtu_In_cpwrmon, const real_T *rtu_In_hvilmon,
                      const real_T *rtu_In_ibat, const real_T *rtu_In_maincstat,
                      const real_T *rtu_In_vbat, const real_T *rtu_In_vehmon,
                      const real_T *rtu_In_ICESwitch, const real_T
                      *rtu_In_RegenSwitch, const real_T
                      *rtu_In_CAVsCrsLmtrSwStat, const real_T
                      *rtu_In_CAVsCrsCntrlSwStOnSwAct, const real_T
                      *rtu_In_CAVsCrsCntrlStSetSwAct, const real_T
                      *rtu_In_Long_Switch, const real_T *rtu_In_TCSysAtv, const
                      real_T *rtu_In_MotorRC, const real_T
                      *rtu_In_DrvIntndAxlTrqMax, const real_T
                      *rtu_In_DrvIntndAxlTrqMin, const real_T *rtu_In_TrqReqStat,
                      const real_T *rtu_In_xdotref, const real_T
                      *rtu_In_ACCBrakeTime, const real_T *rtu_In_CAVtrgVel,
                      const real_T *rtu_In_CAVtrgDist, const real_T
                      *rtu_In_grade, const real_T *rtu_In_Tanh_Exponent, const
                      real_T *rtu_In_Tanh_multiplier, const boolean_T
                      *rtu_In_dist_is_valid, const boolean_T
                      *rtu_In_TrafficLightPresent, const real_T
                      *rtu_In_DistanceToIntersection, const real_T
                      *rtu_In_TimeToNextState, const real_T *rtu_In_CurrentState,
                      const real_T *rtu_In_Decel_Division_Value, const real_T
                      *rtu_In_bcm_coolan_temp_C, const real_T
                      *rtu_In_DistanceObjValid, const real_T *rtu_In_TimeGap,
                      const real_T *rtu_In_TransEstGear, const real_T
                      *rtu_In_SwitchToLinearOnlyMotorFadeOut, const real_T
                      *rtu_In_CrsSecSwStat, HSCOutputs *rty_Out, B_HSC_Model_c_T
                      *localB, DW_HSC_Model_f_T *localDW);
extern void HSC_Model_Term(DW_HSC_Model_f_T *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'HSC_Model'
 * '<S1>'   : 'HSC_Model/ACC Controller'
 * '<S2>'   : 'HSC_Model/Battery_Management_Control_Process'
 * '<S3>'   : 'HSC_Model/Diagnostics'
 * '<S4>'   : 'HSC_Model/Driver_Arbitration'
 * '<S5>'   : 'HSC_Model/Energy_Management_Control_Process'
 * '<S6>'   : 'HSC_Model/Input_Wrapper'
 * '<S7>'   : 'HSC_Model/Output_Wrapper'
 * '<S8>'   : 'HSC_Model/RTI Data'
 * '<S9>'   : 'HSC_Model/Regenerative_Braking_Control_Process'
 * '<S10>'  : 'HSC_Model/Vehicle_Mode_Control_Process'
 * '<S11>'  : 'HSC_Model/ACC Controller/ACC Auto Engage Controller'
 * '<S12>'  : 'HSC_Model/ACC Controller/ACC Classical'
 * '<S13>'  : 'HSC_Model/ACC Controller/CAVPCM_ACCMd_Request'
 * '<S14>'  : 'HSC_Model/ACC Controller/Chart'
 * '<S15>'  : 'HSC_Model/ACC Controller/Chart3'
 * '<S16>'  : 'HSC_Model/ACC Controller/Compare To Constant1'
 * '<S17>'  : 'HSC_Model/ACC Controller/Compare To Constant2'
 * '<S18>'  : 'HSC_Model/ACC Controller/Compare To Constant3'
 * '<S19>'  : 'HSC_Model/ACC Controller/Dash'
 * '<S20>'  : 'HSC_Model/ACC Controller/Generate SetSpd'
 * '<S21>'  : 'HSC_Model/ACC Controller/HostPerceptionModel'
 * '<S22>'  : 'HSC_Model/ACC Controller/Subsystem'
 * '<S23>'  : 'HSC_Model/ACC Controller/ACC Classical/ACC pedals'
 * '<S24>'  : 'HSC_Model/ACC Controller/ACC Classical/ACC pedals/Error Metrics'
 * '<S25>'  : 'HSC_Model/ACC Controller/Dash/Chart'
 * '<S26>'  : 'HSC_Model/ACC Controller/HostPerceptionModel/Discrete Derivative'
 * '<S27>'  : 'HSC_Model/ACC Controller/HostPerceptionModel/jerkDeriv'
 * '<S28>'  : 'HSC_Model/ACC Controller/Subsystem/Chart2'
 * '<S29>'  : 'HSC_Model/Battery_Management_Control_Process/Chart'
 * '<S30>'  : 'HSC_Model/Battery_Management_Control_Process/Chart1'
 * '<S31>'  : 'HSC_Model/Battery_Management_Control_Process/Chart2'
 * '<S32>'  : 'HSC_Model/Battery_Management_Control_Process/Chart3'
 * '<S33>'  : 'HSC_Model/Battery_Management_Control_Process/Chart4'
 * '<S34>'  : 'HSC_Model/Battery_Management_Control_Process/Compare To Constant'
 * '<S35>'  : 'HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power'
 * '<S36>'  : 'HSC_Model/Battery_Management_Control_Process/Saturation Dynamic'
 * '<S37>'  : 'HSC_Model/Battery_Management_Control_Process/SOC Maintenance Power/checks for Low Speed Cruise Charge Mode'
 * '<S38>'  : 'HSC_Model/Diagnostics/ABSRegenOff'
 * '<S39>'  : 'HSC_Model/Diagnostics/Brake Torque Cancelation'
 * '<S40>'  : 'HSC_Model/Diagnostics/Electronics_Cooling'
 * '<S41>'  : 'HSC_Model/Diagnostics/Ground Fault Detection'
 * '<S42>'  : 'HSC_Model/Diagnostics/Motor Control Fault'
 * '<S43>'  : 'HSC_Model/Diagnostics/Over//UnderVoltage'
 * '<S44>'  : 'HSC_Model/Diagnostics/OverDischarge'
 * '<S45>'  : 'HSC_Model/Diagnostics/Overheat'
 * '<S46>'  : 'HSC_Model/Diagnostics/Powertrain direction fault'
 * '<S47>'  : 'HSC_Model/Diagnostics/Protect HV'
 * '<S48>'  : 'HSC_Model/Diagnostics/Shift Validity'
 * '<S49>'  : 'HSC_Model/Diagnostics/ZeroPwrTmTrq'
 * '<S50>'  : 'HSC_Model/Diagnostics/motor_torque direction fault'
 * '<S51>'  : 'HSC_Model/Diagnostics/ABSRegenOff/ABSRegenOff'
 * '<S52>'  : 'HSC_Model/Diagnostics/Brake Torque Cancelation/BPPCheck'
 * '<S53>'  : 'HSC_Model/Diagnostics/Brake Torque Cancelation/Launch Mode Check'
 * '<S54>'  : 'HSC_Model/Diagnostics/Electronics_Cooling/ABSRegenOff'
 * '<S55>'  : 'HSC_Model/Diagnostics/Electronics_Cooling/Compare To Constant'
 * '<S56>'  : 'HSC_Model/Diagnostics/Ground Fault Detection/Chart'
 * '<S57>'  : 'HSC_Model/Diagnostics/Ground Fault Detection/Competition Requirement 500 ohms per volt'
 * '<S58>'  : 'HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant'
 * '<S59>'  : 'HSC_Model/Diagnostics/Over//UnderVoltage/Compare To Constant1'
 * '<S60>'  : 'HSC_Model/Diagnostics/Over//UnderVoltage/OverVoltage'
 * '<S61>'  : 'HSC_Model/Diagnostics/Over//UnderVoltage/UnderVoltage'
 * '<S62>'  : 'HSC_Model/Diagnostics/OverDischarge/Compare To Constant'
 * '<S63>'  : 'HSC_Model/Diagnostics/OverDischarge/OverDischarge'
 * '<S64>'  : 'HSC_Model/Diagnostics/Overheat/Compare To Constant1'
 * '<S65>'  : 'HSC_Model/Diagnostics/Overheat/Compare To Constant2'
 * '<S66>'  : 'HSC_Model/Diagnostics/Overheat/Compare To Constant3'
 * '<S67>'  : 'HSC_Model/Diagnostics/Overheat/Compare To Constant6'
 * '<S68>'  : 'HSC_Model/Diagnostics/Overheat/fault Counter1'
 * '<S69>'  : 'HSC_Model/Diagnostics/Overheat/fault Counter2'
 * '<S70>'  : 'HSC_Model/Diagnostics/Overheat/fault Counter3'
 * '<S71>'  : 'HSC_Model/Diagnostics/Powertrain direction fault/CheckForDrive'
 * '<S72>'  : 'HSC_Model/Diagnostics/Powertrain direction fault/CheckForReverse'
 * '<S73>'  : 'HSC_Model/Diagnostics/Powertrain direction fault/Fault counter1'
 * '<S74>'  : 'HSC_Model/Diagnostics/Powertrain direction fault/ForwardMotionCheck'
 * '<S75>'  : 'HSC_Model/Diagnostics/Powertrain direction fault/ReverseMotionCheck'
 * '<S76>'  : 'HSC_Model/Diagnostics/Shift Validity/CheckForDrive1'
 * '<S77>'  : 'HSC_Model/Diagnostics/Shift Validity/CheckForNeutral'
 * '<S78>'  : 'HSC_Model/Diagnostics/Shift Validity/CheckForPark1'
 * '<S79>'  : 'HSC_Model/Diagnostics/Shift Validity/CheckForReverse '
 * '<S80>'  : 'HSC_Model/Diagnostics/Shift Validity/CheckForReverse2'
 * '<S81>'  : 'HSC_Model/Diagnostics/Shift Validity/Fault Counter'
 * '<S82>'  : 'HSC_Model/Diagnostics/Shift Validity/FirstGearOrGreater'
 * '<S83>'  : 'HSC_Model/Diagnostics/Shift Validity/NinethGearOrless'
 * '<S84>'  : 'HSC_Model/Diagnostics/motor_torque direction fault/Compare To Constant'
 * '<S85>'  : 'HSC_Model/Diagnostics/motor_torque direction fault/Compare To Zero'
 * '<S86>'  : 'HSC_Model/Diagnostics/motor_torque direction fault/Fault counter1'
 * '<S87>'  : 'HSC_Model/Driver_Arbitration/Compare To Constant'
 * '<S88>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque'
 * '<S89>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque'
 * '<S90>'  : 'HSC_Model/Energy_Management_Control_Process/Choosing the Engine source'
 * '<S91>'  : 'HSC_Model/Energy_Management_Control_Process/Choosing the Motor source'
 * '<S92>'  : 'HSC_Model/Energy_Management_Control_Process/Energy Management Strategy'
 * '<S93>'  : 'HSC_Model/Energy_Management_Control_Process/Increment Stored Integer'
 * '<S94>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Compare To Constant'
 * '<S95>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check'
 * '<S96>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Drive'
 * '<S97>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for Reverse'
 * '<S98>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Engine Torque/Shift Lever Position Check/Checks for ShftLvrPos Unknown'
 * '<S99>'  : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart'
 * '<S100>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart1'
 * '<S101>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Chart2'
 * '<S102>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Check for key in Run'
 * '<S103>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for Drive'
 * '<S104>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Reverse'
 * '<S105>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Checks for ShftLvrPos Unknown'
 * '<S106>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant'
 * '<S107>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant1'
 * '<S108>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Compare To Constant2'
 * '<S109>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque'
 * '<S110>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter'
 * '<S111>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Saturation Motor Limits'
 * '<S112>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode'
 * '<S113>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation'
 * '<S114>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Reverse'
 * '<S115>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation'
 * '<S116>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Creep Torque/Creep Torque Threshold_Nm'
 * '<S117>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Dynamic Motor Torque Rate Limiter/Chart'
 * '<S118>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Launch Mode/Check For  Launch Mode'
 * '<S119>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if cruise charging mode'
 * '<S120>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if low speed Cruise Charging mode'
 * '<S121>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks if regen mode'
 * '<S122>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks negative torque'
 * '<S123>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks positive torque'
 * '<S124>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/Regen Switch Torque Cancelation/checks regen switch is on'
 * '<S125>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charge SOC Limit'
 * '<S126>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Charging Motor Torque'
 * '<S127>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging Motor Torque'
 * '<S128>' : 'HSC_Model/Energy_Management_Control_Process/Calculate Motor Torque/SOC Limit Cancelation/Discharging SOC Limit'
 * '<S129>' : 'HSC_Model/Energy_Management_Control_Process/Choosing the Engine source/Saturation Dynamic'
 * '<S130>' : 'HSC_Model/Energy_Management_Control_Process/Choosing the Motor source/Saturation Dynamic1'
 * '<S131>' : 'HSC_Model/RTI Data/RTI Data Store'
 * '<S132>' : 'HSC_Model/RTI Data/RTI Data Store/RTI Data Store'
 * '<S133>' : 'HSC_Model/RTI Data/RTI Data Store/RTI Data Store/RTI Data Store'
 * '<S134>' : 'HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant'
 * '<S135>' : 'HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant1'
 * '<S136>' : 'HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant2'
 * '<S137>' : 'HSC_Model/Regenerative_Braking_Control_Process/Compare To Constant3'
 * '<S138>' : 'HSC_Model/Regenerative_Braking_Control_Process/LockInPowerDemandToGetRidOfTorqueJerk'
 * '<S139>' : 'HSC_Model/Regenerative_Braking_Control_Process/SOC Charge Limit'
 * '<S140>' : 'HSC_Model/Vehicle_Mode_Control_Process/VMCP'
 */
#endif                                 /* RTW_HEADER_HSC_Model_h_ */
