/*
 * Code generation for system system '<S12>/ACC pedals'
 * For more details, see corresponding source file HSC_Model_ACCpedals.c
 *
 */

#ifndef RTW_HEADER_HSC_Model_ACCpedals_h_
#define RTW_HEADER_HSC_Model_ACCpedals_h_
#ifndef HSC_Model_COMMON_INCLUDES_
# define HSC_Model_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* HSC_Model_COMMON_INCLUDES_ */

#include "HSC_Model_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Block signals for system '<S12>/ACC pedals' */
typedef struct {
  real_T DistInfo[7];                  /* '<S23>/DistInfo' */
  real_T DistErrFLipped;               /* '<S23>/Unary Minus' */
  real_T EgoSpd;                       /* '<S23>/Gain4' */
  real_T Gain5;                        /* '<S23>/Gain5' */
  real_T uDLookupTable1;               /* '<S23>/2-D Lookup Table1' */
  real_T UnitDelay[2];                 /* '<S24>/Unit Delay' */
  real_T VectorConcatenate1[2];        /* '<S24>/Vector Concatenate1' */
  real_T Switch[2];                    /* '<S24>/Switch' */
  real_T APP;                          /* '<S23>/APP' */
  real_T BPP;                          /* '<S23>/BPP' */
  real_T DiscreteTimeIntegrator;       /* '<S24>/Discrete-Time Integrator' */
  real_T Product;                      /* '<S24>/Product' */
  real_T BRAKE_PWR;                    /* '<S23>/BRAKE_PWR' */
  real_T ENG_PWR;                      /* '<S23>/ENG_PWR' */
  real_T MOTOR_PWR;                    /* '<S23>/MOTOR_PWR' */
  real_T ACCRewPwr;                    /* '<S23>/Sum' */
  real_T Constant2;                    /* '<S23>/Constant2' */
  real_T EgoPosition;                  /* '<S23>/Discrete-Time Integrator1' */
  real_T xdotPosition;                 /* '<S23>/Discrete-Time Integrator2' */
  real_T ACCBrakeTime;                 /* '<S23>/Gain' */
  real_T grade;                        /* '<S23>/Gain1' */
  real_T TargetRelPos;                 /* '<S23>/Gain3' */
  real_T SetSpd;                       /* '<S23>/kph2m//s1' */
  real_T RateTransition2;              /* '<S23>/Rate Transition2' */
  real_T RateTransition3;              /* '<S23>/Rate Transition3' */
  boolean_T VectorConcatenate[2];      /* '<S24>/Vector Concatenate' */
  boolean_T BrakeHoldActive;           /* '<S23>/Constant1' */
} B_ACCpedals_HSC_Model_T;

/* Block states (default storage) for system '<S12>/ACC pedals' */
typedef struct {
  real_T UnitDelay_DSTATE[2];          /* '<S24>/Unit Delay' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S24>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTATE;/* '<S23>/Discrete-Time Integrator1' */
  real_T DiscreteTimeIntegrator2_DSTATE;/* '<S23>/Discrete-Time Integrator2' */
  real_T RateTransition2_Buffer;       /* '<S23>/Rate Transition2' */
  real_T RateTransition3_Buffer;       /* '<S23>/Rate Transition3' */
} DW_ACCpedals_HSC_Model_T;

/* Parameters for system: '<S12>/ACC pedals' */
struct P_ACCpedals_HSC_Model_T_ {
  real_T Gain4_Gain;                   /* Expression: 1
                                        * Referenced by: '<S23>/Gain4'
                                        */
  real_T Gain5_Gain;                   /* Expression: 2.23694
                                        * Referenced by: '<S23>/Gain5'
                                        */
  real_T uDLookupTable1_bp01Data[17];  /* Expression: [-75:10:-5,0,5:10:75]
                                        * Referenced by: '<S23>/2-D Lookup Table1'
                                        */
  real_T uDLookupTable1_bp02Data[17];  /* Expression: [0:5:80]
                                        * Referenced by: '<S23>/2-D Lookup Table1'
                                        */
  real_T UnitDelay_InitialCondition[2];/* Expression: [0,0]
                                        * Referenced by: '<S24>/Unit Delay'
                                        */
  real_T APP_Value;                    /* Expression: 0
                                        * Referenced by: '<S23>/APP'
                                        */
  real_T BPP_Value;                    /* Expression: 0
                                        * Referenced by: '<S23>/BPP'
                                        */
  real_T DiscreteTimeIntegrator_gainval;
                           /* Computed Parameter: DiscreteTimeIntegrator_gainval
                            * Referenced by: '<S24>/Discrete-Time Integrator'
                            */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S24>/Discrete-Time Integrator'
                                        */
  real_T BRAKE_PWR_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/BRAKE_PWR'
                                        */
  real_T ENG_PWR_Value;                /* Expression: 0
                                        * Referenced by: '<S23>/ENG_PWR'
                                        */
  real_T MOTOR_PWR_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/MOTOR_PWR'
                                        */
  real_T Constant2_Value;              /* Expression: 0
                                        * Referenced by: '<S23>/Constant2'
                                        */
  real_T DiscreteTimeIntegrator1_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator1_gainval
                           * Referenced by: '<S23>/Discrete-Time Integrator1'
                           */
  real_T DiscreteTimeIntegrator1_IC;   /* Expression: 0
                                        * Referenced by: '<S23>/Discrete-Time Integrator1'
                                        */
  real_T DiscreteTimeIntegrator2_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator2_gainval
                           * Referenced by: '<S23>/Discrete-Time Integrator2'
                           */
  real_T DiscreteTimeIntegrator2_IC;   /* Expression: 0
                                        * Referenced by: '<S23>/Discrete-Time Integrator2'
                                        */
  real_T Gain_Gain;                    /* Expression: 1
                                        * Referenced by: '<S23>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1
                                        * Referenced by: '<S23>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: 1
                                        * Referenced by: '<S23>/Gain3'
                                        */
  real_T kph2ms1_Gain;                 /* Expression: 0.277778
                                        * Referenced by: '<S23>/kph2m//s1'
                                        */
  uint32_T uDLookupTable1_maxIndex[2];
                                  /* Computed Parameter: uDLookupTable1_maxIndex
                                   * Referenced by: '<S23>/2-D Lookup Table1'
                                   */
  boolean_T Constant1_Value;           /* Computed Parameter: Constant1_Value
                                        * Referenced by: '<S23>/Constant1'
                                        */
};

extern void HSC_Model_ACCpedals_Init(DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP);
extern void HSC_Model_ACCpedals_Reset(DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP);
extern void HSC_Model_ACCpedals(RT_MODEL_HSC_Model_T * const HSC_Model_M, real_T
  rtu_EgoSpd, real_T rtu_TargetRelPos, real_T rtu_TargetRelSpd, real_T rtu_Info,
  real_T rtu_Info_b, real_T rtu_Info_d, real_T rtu_Info_e, real_T rtu_DistInfo,
  real_T rtu_DistInfo_e, real_T rtu_DistInfo_p, real_T rtu_DistInfo_l, real_T
  rtu_DistInfo_m, real_T rtu_DistInfo_f, real_T rtu_DistInfo_g,
  B_ACCpedals_HSC_Model_T *localB, DW_ACCpedals_HSC_Model_T *localDW,
  P_ACCpedals_HSC_Model_T *localP);

#endif                                 /* RTW_HEADER_HSC_Model_ACCpedals_h_ */
