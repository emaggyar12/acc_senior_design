/*
 * TransmissionController_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "TransmissionController".
 *
 * Model version              : 1.240
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:35:55 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_TransmissionController_types_h_
#define RTW_HEADER_TransmissionController_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters for system: '<S6>/calc' */
typedef struct P_calc_TransmissionController_T_ P_calc_TransmissionController_T;

/* Parameters (default storage) */
typedef struct P_TransmissionController_T_ P_TransmissionController_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_TransmissionController_T
  RT_MODEL_TransmissionController_T;

#endif                          /* RTW_HEADER_TransmissionController_types_h_ */
