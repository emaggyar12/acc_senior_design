/*
 * SiEngineController_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiEngineController".
 *
 * Model version              : 1.669
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:35:27 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SiEngineController_capi_h
#define RTW_HEADER_SiEngineController_capi_h
#include "SiEngineController.h"

extern void SiEngineController_InitializeDataMapInfo
  (RT_MODEL_SiEngineController_T *const SiEngineController_M,
   B_SiEngineController_c_T *localB, DW_SiEngineController_f_T *localDW);

#endif                                /* RTW_HEADER_SiEngineController_capi_h */

/* EOF: SiEngineController_capi.h */
