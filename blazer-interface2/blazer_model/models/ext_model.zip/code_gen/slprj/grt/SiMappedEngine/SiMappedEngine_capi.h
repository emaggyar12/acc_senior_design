/*
 * SiMappedEngine_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "SiMappedEngine".
 *
 * Model version              : 1.443
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:35:39 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SiMappedEngine_capi_h
#define RTW_HEADER_SiMappedEngine_capi_h
#include "SiMappedEngine.h"

extern void SiMappedEngine_InitializeDataMapInfo(RT_MODEL_SiMappedEngine_T *
  const SiMappedEngine_M, B_SiMappedEngine_c_T *localB, X_SiMappedEngine_n_T
  *localX);

#endif                                 /* RTW_HEADER_SiMappedEngine_capi_h */

/* EOF: SiMappedEngine_capi.h */
