/*
 * Blazer_Plant_Model_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Blazer_Plant_Model".
 *
 * Model version              : 1.1070
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C source code generated on : Wed Nov  2 01:36:55 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Blazer_Plant_Model_types_h_
#define RTW_HEADER_Blazer_Plant_Model_types_h_
#include "rtwtypes.h"
#include "model_reference_types.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_CntrlDesk_
#define DEFINED_TYPEDEF_FOR_CntrlDesk_

typedef struct {
  real_T CAVsCrsCntrlSwStOnSwAct;
  real_T CAVsCrsCntrlStSetSwAct;
  real_T Long_Switch;
  real_T xdotref;
} CntrlDesk;

#endif

#ifndef DEFINED_TYPEDEF_FOR_HSCOutputs_
#define DEFINED_TYPEDEF_FOR_HSCOutputs_

typedef struct {
  real_T EngAxleTrqDmd;
  real_T McuTorqueCommand;
  real_T HSCbmsEnable;
  real_T MPDMBMSign;
  real_T HSCbmsLeakage;
  real_T MPDMBMSpwr;
  real_T HSCBrusaEnable;
  real_T HSCbmsMainCclose;
  real_T MPDMMCUign;
  real_T VMUCmd1OpRq;
  real_T VMUCmd2OpMd;
  real_T VMUmajorProt;
  real_T VMUminorProt;
  real_T MPDMHVpump;
  real_T VMU_Kickout;
  real_T vmcp_StartupSt;
  real_T CrsSpdLmtrSwStat;
  real_T CrsCntrlSwStOnSwAct;
  real_T ACCATC_ACCAct_SF;
  real_T CrsCntrlSwStSetSwAct;
  real_T VMU_Cmd2_CommandMd;
  real_T ACC_APP;
  real_T ACC_BPP;
  real_T ACCPIDOut;
  real_T DistError;
  real_T RelDist;
  real_T SafeDist;
  boolean_T CAVPCM_ACCMdAtv;
  boolean_T CAVPCM_ACCMdReq;
  boolean_T protectHV;
  boolean_T MotorCntrlFault;
  boolean_T ZeroPwrTrq;
  real_T MotorTrqEst;
  boolean_T MotorTrqDirFault;
  real_T TrackACCSt;
  real_T TrqDmdPedalMap;
  real_T DesEngPwr;
  real_T DesElecPwr;
  real_T PwrPMNoRegen;
  real_T TotPwrPedalMap;
  real_T EngTrqDmdRaw;
  real_T EBCM_Decel;
  boolean_T powertraindirectionfault;
  boolean_T VehicleShiftStateControlfault;
  real_T SetSpdACC;
  boolean_T MotorTrqCutFlag;
  boolean_T EngTrqCutFlag;
  boolean_T ReduceMotSwitch;
  boolean_T GFD;
  boolean_T Battery_Overheat;
  boolean_T Batt_Overheat_Susp;
  boolean_T BPPCancel;
  boolean_T ZeroPwrTmTrq;
  boolean_T MotorControlFault;
  boolean_T MtrCommFault;
  boolean_T AutoMdSpdLmtStat;
  boolean_T ACCAct370;
  boolean_T AdapCrsCntVDA;
  real_T ACCDrvrSeltdSpd;
  real_T SetSpeedCmd;
  real_T TotalAccelCommandBeforeRoadLoad;
  real_T TotalForceAfterRoadLoad;
  real_T ACCReqPwr;
  real_T BattPwrChrgLmt;
  real_T BattPwrDischrgLmt;
  real_T PSOC;
  real_T SetSpeedErrorMs;
  real_T SetSpeedMs;
  real_T LiveDistanceToIntersection;
  boolean_T MustStop;
  real_T StopLightAccelMs2;
  boolean_T battery_overvoltage_fault;
  boolean_T battery_undervoltage_fault;
  boolean_T battery_over_discharge_fault;
  real_T SafeDistance;
  real_T ActualAPP;
  real_T TorqueStartTime;
  real_T FullTorqueTime;
  real_T LowerTorqueTime;
  real_T TorqueEndTime;
  real_T TorqueGearDuration;
  real_T GearTo;
  real_T AxleTorqueAddition;
  real_T MotorCompMultiplier;
  real_T DistanceRCValidity;
  real_T StoplightRCValidity;
  boolean_T StoppingInProgress;
  real_T MotorCompCancel;
  boolean_T CreepTorqueCancel;
  boolean_T DistanceMustStop;
  boolean_T ACCAct3702;
  real_T ACCSysSltdMdDispIO;
  real_T ACCTmpUnavlbleIO;
  real_T FOAI_AlrtWrnIndRq;
  real_T ACCHdwySTG;
  real_T ACCDrvrSeltdSpd2;
  real_T FOAI_VehAhdIndRq;
  real_T DrvrThrtlOrvIO;
  boolean_T FwdClnAlrtPr;
  boolean_T ACCDrvrSltdspdIO;
  boolean_T ACCUnavlbleDTWthrIO;
  boolean_T ACCHdwayStngIO;
  boolean_T ACCSnsCldRqIO;
  boolean_T ServAdpCrsCtrlIndOn;
  boolean_T ACCSysSltdMD;
  boolean_T FOAI_AlrtChmIhbRq;
  boolean_T BrakeHoldActive;
  real_T DistanceState;
} HSCOutputs;

#endif

#ifndef DEFINED_TYPEDEF_FOR_CAN_to_Plant_
#define DEFINED_TYPEDEF_FOR_CAN_to_Plant_

typedef struct {
  real_T MotorTorque;
  real_T ACCATC_AxlTrqRq;
  real_T EngTrqActExtRng;
} CAN_to_Plant;

#endif

#ifndef DEFINED_TYPEDEF_FOR_Fuelout_
#define DEFINED_TYPEDEF_FOR_Fuelout_

typedef struct {
  real_T TotFuel;
  real_T BattFuel;
} Fuelout;

#endif

#ifndef DEFINED_TYPEDEF_FOR_Scope_
#define DEFINED_TYPEDEF_FOR_Scope_

typedef struct {
  real_T VehSpd_mph;
  real_T RefSpd_mph;
  real_T EngSpd_rpm;
  real_T MotSpd_rpm;
  real_T EngTrq_Nm;
  real_T MotTrq_Nm;
  real_T BattCurr_A;
  real_T BattSOC;
  real_T FuelEcon_mpge;
  real_T TPNOxMass;
  real_T TPCO2Mass;
  real_T TPCOMass;
  real_T TPHCMass;
  Fuelout Fuelout;
} Scope;

#endif

#ifndef DEFINED_TYPEDEF_FOR_PCM_to_HSC_
#define DEFINED_TYPEDEF_FOR_PCM_to_HSC_

typedef struct {
  real_T APP;
  real_T VehSpdAvgDrvn;
  real_T Gear;
  real_T Brake_Pa;
  real_T xdotref;
  real_T BPP;
} PCM_to_HSC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_ElectricPlant_to_HSC_
#define DEFINED_TYPEDEF_FOR_ElectricPlant_to_HSC_

typedef struct {
  real_T BattCurr;
  real_T BattPwr;
  real_T BattV;
  real_T MotTrq;
  real_T BattSoc;
  real_T MotPwrElec;
  real_T MotSpd;
  real_T EngSpd;
  real_T EngTrqOut;
} ElectricPlant_to_HSC;

#endif

#ifndef DEFINED_TYPEDEF_FOR_From_Plant_
#define DEFINED_TYPEDEF_FOR_From_Plant_

typedef struct {
  PCM_to_HSC PCM_to_HSC;
  ElectricPlant_to_HSC ElectricPlant_to_HSC;
} From_Plant;

#endif

/* Parameters (default storage) */
typedef struct P_Blazer_Plant_Model_T_ P_Blazer_Plant_Model_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Blazer_Plant_Model_T RT_MODEL_Blazer_Plant_Model_T;

#endif                              /* RTW_HEADER_Blazer_Plant_Model_types_h_ */
